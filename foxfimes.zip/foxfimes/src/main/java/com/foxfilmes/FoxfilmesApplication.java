package com.foxfilmes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoxfilmesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoxfilmesApplication.class, args);
	}

}
