package com.foxfilmes.sessao.rota;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class ConsultaSessaoRest extends RouteBuilder{
	
	public static final String REST_ROUTE = "/sessao/{id_sessao}";
	public static final String REST_ROUTE_ID = "get-sessao-rest";

	@Override
	public void configure() throws Exception {
		
		rest(REST_ROUTE)
		.get()
			.produces(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.route()
					.routeId(REST_ROUTE_ID)
					.routeDescription("Consulta de Sessões")
						.doTry()
							.to(ConsultaSessaoRota.ROUTE)
						.endDoTry()
						.doCatch(Exception.class)
		.end();
		
	}

}
