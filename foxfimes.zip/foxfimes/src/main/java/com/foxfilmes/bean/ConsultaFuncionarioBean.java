package com.foxfilmes.bean;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Funcionario;
import com.foxfilmes.model.FuncionarioJson;
import com.foxfilmes.repository.FuncionarioRepository;

public class ConsultaFuncionarioBean {
	
	@Autowired
	private FuncionarioRepository funcionarioRepository;
	
	public static final String FUNCIONARIO = "funcionario";
	public static final String ID_FUNCIONARIO = "id_funcionario";
	
	public void formatarEntrada(Exchange exchange) {
		
		Long idFuncionario = exchange.getIn().getHeader(ID_FUNCIONARIO, Long.class);
		
		Funcionario funcionario = funcionarioRepository.findByIdFuncionario(idFuncionario);
		
		exchange.setProperty(FUNCIONARIO, funcionario);
		exchange.getOut().setBody(funcionario);		
	}
	
	public void formatarSaida(Exchange exchange) {
		
		FuncionarioJson funcionarioJson = new FuncionarioJson(exchange.getProperty(FUNCIONARIO, Funcionario.class));
		
		exchange.getOut().setBody(funcionarioJson);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());		
	}

}
