package com.foxfilmes.bean;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Filmes;
import com.foxfilmes.entity.Sala;
import com.foxfilmes.entity.Sessao;
import com.foxfilmes.model.SessaoJson;
import com.foxfilmes.repository.FilmesRepository;
import com.foxfilmes.repository.SalaRepository;
import com.foxfilmes.repository.SessaoRepository;

public class ConsultaSessaoBean {
	
	@Autowired
	private SessaoRepository sessaoRepository;
	
	@Autowired
	private FilmesRepository filmesRepository;
	
	@Autowired
	private SalaRepository salaRepository;
	
	public static final String SESSAO = "sessao";
	public static final String ID_SESSAO = "id_sessao";
	
	public static final String FILME = "filmes";
	public static final String SALA = "salas";
	
	public void formatarEntrada(Exchange exchange) {
		
		Long idSessao = exchange.getIn().getHeader(ID_SESSAO, Long.class);
		
		Sessao sessao = sessaoRepository.findByIdSessao(idSessao);
		
		Filmes filme = filmesRepository.findByIdFilme(sessao.getFilmes().getIdFilme());
		Sala sala = salaRepository.findByIdSala(sessao.getSala().getIdSala());
		
		exchange.setProperty(FILME, filme);
		exchange.setProperty(SALA, sala);
		
		exchange.setProperty(SESSAO, sessao);
		exchange.getOut().setBody(sessao);		
	}
	
	public void formatarSaida(Exchange exchange) {
		
		SessaoJson sessaoJson = new SessaoJson(exchange.getProperty(SESSAO, Sessao.class), exchange.getProperty(SALA, Sala.class), exchange.getProperty(FILME, Filmes.class));
		
		exchange.getOut().setBody(sessaoJson);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());		
	}

}
