package com.foxfilmes.bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.foxfilmes.entity.Sala;
import com.foxfilmes.model.SalaJson;
import com.foxfilmes.repository.SalaRepository;
import com.foxfilmes.utils.CampoErro;
import com.foxfilmes.utils.UtilsFoxFilmes;

public class CriacaoSalaBean {
	
	@Autowired
	private SalaRepository salaRepository;
	
	public static final String SALA = "sala";
	
	public static final String NOME_SALA = "nome_sala";
	public static final String QTD_POLTRONA = "qtd_poltrona";
	public static final String QTD_POLTRONA_DISP = "qtd_poltrona_disp";
	public static final String QTD_POLTRONA_RESER = "qtd_poltrona_reser";
	public static final String QTD_POLTRONA_ESP = "qtd_poltrona_esp";
	
	public static final String ATRIBUTO_OBRIGATORIO = "O atributo é obrigatório";
	public static final String ATRIBUTO_INVALIDO = "O atributo não é válido. Tamanho Incorreto";
	
	private List<CampoErro> validarEntrada(SalaJson salaJsonEntrada) throws IOException{
		
		List<CampoErro> campoErro = new ArrayList<>();
		Map<String, Boolean> atributiVerificado = new HashMap<>();
				
		
		Integer qtdPoltronaEspecial = (salaJsonEntrada.getQtdPoltrona()/100)*5;
		Integer qtdPoltronaDisponivel = salaJsonEntrada.getQtdPoltrona() - qtdPoltronaEspecial;
		
		if(StringUtils.isBlank(salaJsonEntrada.getNomeSala()) && !atributiVerificado.containsKey(NOME_SALA)) {
			campoErro.add(new CampoErro(NOME_SALA, ATRIBUTO_OBRIGATORIO, salaJsonEntrada.getNomeSala()));
		}
		
		if(StringUtils.isEmpty(String.valueOf(salaJsonEntrada.getQtdPoltrona())) && !atributiVerificado.containsKey(QTD_POLTRONA)) {
			campoErro.add(new CampoErro(QTD_POLTRONA, ATRIBUTO_OBRIGATORIO, String.valueOf(salaJsonEntrada.getQtdPoltrona())));
		} else if(salaJsonEntrada.getQtdPoltrona() > 100) {
			campoErro.add(new CampoErro(QTD_POLTRONA, ATRIBUTO_INVALIDO, String.valueOf(salaJsonEntrada.getQtdPoltrona())));
		}
		
		if(StringUtils.isEmpty(String.valueOf(salaJsonEntrada.getQtdPoltronaDisp())) && !atributiVerificado.containsKey(QTD_POLTRONA_DISP)) {
			campoErro.add(new CampoErro(QTD_POLTRONA_DISP, ATRIBUTO_OBRIGATORIO, String.valueOf(salaJsonEntrada.getQtdPoltronaDisp())));
		} else if(salaJsonEntrada.getQtdPoltronaDisp() > qtdPoltronaDisponivel) {
			campoErro.add(new CampoErro(QTD_POLTRONA_DISP, ATRIBUTO_INVALIDO, String.valueOf(salaJsonEntrada.getQtdPoltronaDisp())));
		}
		
		if(StringUtils.isEmpty(String.valueOf(salaJsonEntrada.getQtdPoltronaReser())) && !atributiVerificado.containsKey(QTD_POLTRONA_RESER)) {
			campoErro.add(new CampoErro(QTD_POLTRONA_RESER, ATRIBUTO_OBRIGATORIO, String.valueOf(salaJsonEntrada.getQtdPoltronaReser())));
		} else if(salaJsonEntrada.getQtdPoltronaReser() > qtdPoltronaDisponivel) {
			campoErro.add(new CampoErro(QTD_POLTRONA_RESER, ATRIBUTO_INVALIDO, String.valueOf(salaJsonEntrada.getQtdPoltronaReser())));
		}
		
		if(StringUtils.isEmpty(String.valueOf(salaJsonEntrada.getQtdPoltronaEspecial())) && !atributiVerificado.containsKey(QTD_POLTRONA_ESP)) {
			campoErro.add(new CampoErro(QTD_POLTRONA_ESP, ATRIBUTO_OBRIGATORIO, String.valueOf(salaJsonEntrada.getQtdPoltronaEspecial())));
		} else if(salaJsonEntrada.getQtdPoltronaReser() < qtdPoltronaEspecial) {
			campoErro.add(new CampoErro(QTD_POLTRONA_ESP, ATRIBUTO_INVALIDO, String.valueOf(salaJsonEntrada.getQtdPoltronaEspecial())));
		}
		
		return campoErro;
	}
	
	public void formatarEntrada(Exchange exchange) throws IOException{
		
		SalaJson salaJsonEntrada = UtilsFoxFilmes.extrairJson(exchange.getIn().getBody(String.class), SalaJson.class);
		List<CampoErro> campoErro = this.validarEntrada(salaJsonEntrada);
		
		if(!campoErro.isEmpty()) {
			exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
			exchange.getOut().setHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8);
		}else {
			Sala sala = new Sala(salaJsonEntrada);
			salaRepository.save(sala);			
			exchange.setProperty(SALA, sala);
		}
	}
	
	public void formatarSaida(Exchange exchange) throws IOException{
		
		SalaJson salaJson = new SalaJson(exchange.getProperty(SALA, Sala.class));
		
//		exchange.getOut().setBody(UtilsFoxFilmes.serializar(salaJson));
		exchange.getOut().setBody(salaJson);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.CREATED.value());
		
		exchange.getOut().setBody("OK");
	}

}
