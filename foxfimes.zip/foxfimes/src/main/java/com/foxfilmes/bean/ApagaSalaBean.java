package com.foxfilmes.bean;

import java.io.IOException;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Sala;
import com.foxfilmes.model.SalaJson;
import com.foxfilmes.repository.SalaRepository;
import com.foxfilmes.utils.UtilsFoxFilmes;

public class ApagaSalaBean {
	
	@Autowired
	private SalaRepository salaRepository;
	
	public static final String ID_SALA = "id_sala";
	public static final String NAO_ENCONTRADO = "NOK";
	
	public void formatarEntrada(Exchange exchange) {
		
		Long idSala = exchange.getIn().getHeader(ID_SALA, Long.class);
		
		Sala sala = salaRepository.findByIdSala(idSala);
		
		if(sala == null) {
			exchange.setProperty(NAO_ENCONTRADO, sala);
		}else {
			salaRepository.deleteById(idSala);			
		}
				
	}
		
	public void formatarSaida(Exchange exchange) throws IOException {		
		
		if(exchange.getProperty(NAO_ENCONTRADO) == "NOK") {
			exchange.getOut().setBody(UtilsFoxFilmes.serializar(new SalaJson(new Sala())));
			exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.NO_CONTENT.value());					
		}else {
			exchange.getOut().setBody(UtilsFoxFilmes.serializar(new SalaJson(new Sala())));
			exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());
		}				
	}

}
