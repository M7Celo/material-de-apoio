package com.foxfilmes.filmes.rota;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class ConsultaFilmesRest extends RouteBuilder{
	
	public static final String REST_ROUTE = "/filmes/{id_filmes}";
	public static final String REST_ROUTE_ID = "get-filmes-rest";

	@Override
	public void configure() throws Exception {
		
		rest(REST_ROUTE)
		.get()
			.produces(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.route()
					.routeId(REST_ROUTE_ID)
					.routeDescription("Consulta de Filmes")
						.doTry()
							.to(ConsultaFilmesRota.ROUTE)
						.endDoTry()
						.doCatch(Exception.class)
		.end();
			
	}

}
