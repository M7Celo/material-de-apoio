package com.foxfilmes.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.foxfilmes.entity.Descontos;

@Repository
@Transactional
public interface DescontosRepository extends CrudRepository<Descontos, Long>{
	
	Descontos findByIdDescontos(Long idDescontos);

}
