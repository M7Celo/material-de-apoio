package com.foxfilmes.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "descontos")
public class Descontos implements Serializable{

	private static final long serialVersionUID = -3927896264299567898L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id_descontos")
	private Long idDescontos;
	
	@NotNull
	@NotEmpty
	@Column(name="nome_descontos")
	private String nomeDescontos;
	
	@NotNull
	@NotEmpty
	@Column(name="valor_descontos")
	private BigDecimal valorDescontos;

	public Descontos() {
		super();
	}

	public Descontos(Long idDescontos, String nomeDescontos, BigDecimal valorDescontos) {
		super();
		this.idDescontos = idDescontos;
		this.nomeDescontos = nomeDescontos;
		this.valorDescontos = valorDescontos;
	}

	public Long getIdDescontos() {
		return idDescontos;
	}

	public void setIdDescontos(Long idDescontos) {
		this.idDescontos = idDescontos;
	}

	public String getNomeDescontos() {
		return nomeDescontos;
	}

	public void setNomeDescontos(String nomeDescontos) {
		this.nomeDescontos = nomeDescontos;
	}

	public BigDecimal getValorDescontos() {
		return valorDescontos;
	}

	public void setValorDescontos(BigDecimal valorDescontos) {
		this.valorDescontos = valorDescontos;
	}

	@Override
	public String toString() {
		return "Descontos [idDescontos=" + idDescontos + ", nomeDescontos=" + nomeDescontos + ", valorDescontos="
				+ valorDescontos + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idDescontos == null) ? 0 : idDescontos.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Descontos other = (Descontos) obj;
		if (idDescontos == null) {
			if (other.idDescontos != null)
				return false;
		} else if (!idDescontos.equals(other.idDescontos))
			return false;
		return true;
	}

}
