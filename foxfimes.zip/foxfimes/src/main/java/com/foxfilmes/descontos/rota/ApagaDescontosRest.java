package com.foxfilmes.descontos.rota;

public class ApagaDescontosRest {

}
