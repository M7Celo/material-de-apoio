package com.foxfilmes.descontos.rota;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class ConsultaDescontosRest extends RouteBuilder{
	
	public static final String REST_ROUTE = "/descontos/{id_descontos}";
	public static final String REST_ROUTE_ID = "get-descontos-rest";

	@Override
	public void configure() throws Exception {
		
		rest(REST_ROUTE)
		.get()
			.produces(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.route()
					.routeId(REST_ROUTE_ID)
					.routeDescription("Consulta de Descontos")
						.doTry()
							.to(ConsultaDescontosRota.ROUTE)
						.endDoTry()
						.doCatch(Exception.class)
		.end();
		
	}

}
