package com.foxfilmes.sala.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.CriacaoSalaBean;

@Component
public class CriacaoSalaRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:post-sala-rota";
	public static final String ROUTE_ID = "direct-post-sala-rota";

	@Override
	public void configure() throws Exception {
		
		from(ROUTE)
			.routeId(ROUTE_ID)
			.doTry()
				.bean(CriacaoSalaBean.class, "formatarEntrada")
				.bean(CriacaoSalaBean.class, "formatarSaida")
				.marshal().json(JsonLibrary.Jackson)
			.endDoTry()
			.doCatch(Exception.class)
		.end();		
	}

}
