package com.foxfilmes.sala.rota;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.foxfilmes.utils.UtilsFoxFilmes;

@Component
public class CriacaoSalaRest extends RouteBuilder{
	
	public static final String REST_ROUTE = "/salas";
	public static final String REST_ROUTE_ID = "post-sala-rest";

	@Override
	public void configure() throws Exception {
		
		errorHandler(deadLetterChannel(UtilsFoxFilmes.REST_ERRO));
		
		rest(REST_ROUTE)
		.post()
			.consumes(MediaType.APPLICATION_JSON_UTF8_VALUE)
			.produces(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.route()
					.routeId(REST_ROUTE_ID)
					.routeDescription("Criação de Salas")
//						.doTry()
//						.bean(CriacaoSalaBean.class, "formatarEntrada")
							.to(CriacaoSalaRota.ROUTE)
//						.endDoTry()
//						.doCatch(Exception.class)
		.end();
	}

}
