package com.foxfilmes.funcionario.rota;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class ConsultaFuncionarioRest extends RouteBuilder{
	
	public static final String REST_ROUTE = "/funcionario/{id_funcionario}";
	public static final String REST_ROUTE_ID = "get-funcionario-rest";

	@Override
	public void configure() throws Exception {

		rest(REST_ROUTE)
		.get()
			.produces(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.route()
					.routeId(REST_ROUTE_ID)
					.routeDescription("Consulta de Funcionários")
						.doTry()
							.to(ConsultaFuncionarioRota.ROUTE)
						.endDoTry()
						.doCatch(Exception.class)
		.end();
		
	}

}
