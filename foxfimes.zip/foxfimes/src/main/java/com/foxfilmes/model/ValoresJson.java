package com.foxfilmes.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.foxfilmes.entity.Filmes;
import com.foxfilmes.entity.Valores;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id_valores", "filme", "valor_filme" })
public class ValoresJson implements Serializable{

	private static final long serialVersionUID = -3608840533114410078L;
	
	@JsonProperty("id_valores")
	private Long idValores;
	
	@JsonProperty("filme")
	private FilmesJson filmeJson;
	
	@JsonProperty("valor_filme")
	private BigDecimal valorFilme;

	public ValoresJson() {
		super();
	}
	
	public ValoresJson(Valores valores, Filmes filmes) {
		this.idValores = valores.getIdValores();
		this.filmeJson = new FilmesJson(filmes);
		this.valorFilme = valores.getValorFilme();
	}

	public ValoresJson(Long idValores, @NotNull @NotEmpty FilmesJson filmeJson, @NotNull @NotEmpty BigDecimal valorFilme) {
		super();
		this.idValores = idValores;
		this.filmeJson = filmeJson;
		this.valorFilme = valorFilme;
	}

	public Long getIdValores() {
		return idValores;
	}

	public void setIdValores(Long idValores) {
		this.idValores = idValores;
	}

	public FilmesJson getFilme() {
		return filmeJson;
	}

	public void setFilme(FilmesJson filmeJson) {
		this.filmeJson = filmeJson;
	}

	public BigDecimal getValorFilme() {
		return valorFilme;
	}

	public void setValorFilme(BigDecimal valorFilme) {
		this.valorFilme = valorFilme;
	}

}
