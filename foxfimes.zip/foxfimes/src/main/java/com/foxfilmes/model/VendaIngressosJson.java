package com.foxfilmes.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.foxfilmes.entity.Descontos;
import com.foxfilmes.entity.Filmes;
import com.foxfilmes.entity.Sala;
import com.foxfilmes.entity.Sessao;
import com.foxfilmes.entity.Valores;
import com.foxfilmes.entity.VendaIngressos;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id_venda", "numero_ingresso", "sessao", "filmes", "descontos", "sala", "valores", "valor_recebido", "troco", "valor_entregue" })
public class VendaIngressosJson implements Serializable{
	
	private static final long serialVersionUID = -5914567062065914206L;
	
	@JsonProperty("id_venda")
	private Long idVenda;
	
	@JsonProperty("numero_ingresso")
	private Integer numeroIngresso;
	
	@JsonProperty("sessao")
	private SessaoJson sessao;

	@JsonProperty("filmes")
	private FilmesJson filmes;
	
	@JsonProperty("descontos")
	private DescontosJson descontos;
	
	@JsonProperty("sala")
	private SalaJson sala;
	
	@JsonProperty("valores")
	private ValoresJson valores;

	@JsonProperty("valor_recebido")
	private BigDecimal valorRecebido;
	
	@JsonProperty("troco")
	private BigDecimal troco;

	@JsonProperty("valor_entregue")
	private BigDecimal valorTotal;
	

	@JsonProperty("data_hora_venda")
	private LocalDateTime dataHoraVenda;

	public VendaIngressosJson() {
		super();
	}

	public VendaIngressosJson(Long idVenda, Integer numeroIngresso, SessaoJson sessao, FilmesJson filmes,
			DescontosJson descontos, SalaJson sala, ValoresJson valores, BigDecimal valorRecebido, BigDecimal troco,
			BigDecimal valorTotal, LocalDateTime dataHoraVenda) {
		super();
		this.idVenda = idVenda;
		this.numeroIngresso = numeroIngresso;
		this.sessao = sessao;
		this.filmes = filmes;
		this.descontos = descontos;
		this.sala = sala;
		this.valores = valores;
		this.valorRecebido = valorRecebido;
		this.troco = troco;
		this.valorTotal = valorTotal;
		this.dataHoraVenda = dataHoraVenda;
	}

	public VendaIngressosJson(VendaIngressos vendaIngressos, Sessao sessao, Filmes filmes, Descontos descontos, Sala sala, Valores valores) {
		this.idVenda = vendaIngressos.getIdVenda();
		this.numeroIngresso = vendaIngressos.getNumeroIngresso();
		this.sessao = new SessaoJson(sessao, sala, filmes);
		this.filmes = new FilmesJson(filmes);
		this.descontos = new DescontosJson(descontos);
		this.sala = new SalaJson(sala);
		this.valores = new ValoresJson(valores, filmes);
		this.valorRecebido = vendaIngressos.getValorRecebido();
		this.troco = vendaIngressos.getTroco();
		this.valorTotal = vendaIngressos.getValorTotal();
		this.dataHoraVenda = vendaIngressos.getDataHoraVenda();
	}

	public Long getIdVenda() {
		return idVenda;
	}

	public void setIdVenda(Long idVenda) {
		this.idVenda = idVenda;
	}

	public Integer getNumeroIngresso() {
		return numeroIngresso;
	}

	public void setNumeroIngresso(Integer numeroIngresso) {
		this.numeroIngresso = numeroIngresso;
	}

	public SessaoJson getSessao() {
		return sessao;
	}

	public void setSessao(SessaoJson sessao) {
		this.sessao = sessao;
	}

	public FilmesJson getFilmes() {
		return filmes;
	}

	public void setFilmes(FilmesJson filmes) {
		this.filmes = filmes;
	}

	public DescontosJson getDescontos() {
		return descontos;
	}

	public void setDescontos(DescontosJson descontos) {
		this.descontos = descontos;
	}

	public SalaJson getSala() {
		return sala;
	}

	public void setSala(SalaJson sala) {
		this.sala = sala;
	}

	public ValoresJson getValores() {
		return valores;
	}

	public void setValores(ValoresJson valores) {
		this.valores = valores;
	}

	public BigDecimal getValorRecebido() {
		return valorRecebido;
	}

	public void setValorRecebido(BigDecimal valorRecebido) {
		this.valorRecebido = valorRecebido;
	}

	public BigDecimal getTroco() {
		return troco;
	}

	public void setTroco(BigDecimal troco) {
		this.troco = troco;
	}

	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

	public LocalDateTime getDataHoraVenda() {
		return dataHoraVenda;
	}

	public void setDataHoraVenda(LocalDateTime dataHoraVenda) {
		this.dataHoraVenda = dataHoraVenda;
	}
	
}
