package com.foxfilmes.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.foxfilmes.entity.Sala;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id_sala", "nome_sala", "qtd_poltrona", "qtd_poltrona_disp", "qtd_poltrona_reser", "qtd_poltrona_esp" })
public class SalaJson implements Serializable {

	private static final long serialVersionUID = -5566185806998459830L;

	@JsonProperty("id_sala")
	private Long idSala;

	@JsonProperty("nome_sala")
	private String nomeSala;

	@JsonProperty("qtd_poltrona")
	private Integer qtdPoltrona;

	@JsonProperty("qtd_poltrona_disp")
	private Integer qtdPoltronaDisp;

	@JsonProperty("qtd_poltrona_reser")
	private Integer qtdPoltronaReser;

	@JsonProperty("qtd_poltrona_esp")
	private Integer qtdPoltronaEspecial;

	public SalaJson() {
		super();
	}

	public SalaJson(Sala sala) {
		this.idSala = sala.getIdSala();
		this.nomeSala = sala.getNomeSala();
		this.qtdPoltrona = sala.getQtdPoltrona();
		this.qtdPoltronaDisp = sala.getQtdPoltronaDisp();
		this.qtdPoltronaReser = sala.getQtdPoltronaReser();
		this.qtdPoltronaEspecial = sala.getQtdPoltronaEspecial();
	}

	public Long getIdSala() {
		return idSala;
	}

	public void setIdSala(Long idSala) {
		this.idSala = idSala;
	}

	public String getNomeSala() {
		return nomeSala;
	}

	public void setNomeSala(String nomeSala) {
		this.nomeSala = nomeSala;
	}

	public Integer getQtdPoltrona() {
		return qtdPoltrona;
	}

	public void setQtdPoltrona(Integer qtdPoltrona) {
		this.qtdPoltrona = qtdPoltrona;
	}

	public Integer getQtdPoltronaDisp() {
		return qtdPoltronaDisp;
	}

	public void setQtdPoltronaDisp(Integer qtdPoltronaDisp) {
		this.qtdPoltronaDisp = qtdPoltronaDisp;
	}

	public Integer getQtdPoltronaReser() {
		return qtdPoltronaReser;
	}

	public void setQtdPoltronaReser(Integer qtdPoltronaReser) {
		this.qtdPoltronaReser = qtdPoltronaReser;
	}

	public Integer getQtdPoltronaEspecial() {
		return qtdPoltronaEspecial;
	}

	public void setQtdPoltronaEspecial(Integer qtdPoltronaEspecial) {
		this.qtdPoltronaEspecial = qtdPoltronaEspecial;
	}

}
