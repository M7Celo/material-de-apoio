package fox.apagar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Descontos;
import fox.bean.Funcionario;
import fox.dao.FuncionarioDao;
import fox.exception.DaoException;

public class ApagaFunc extends JFrame implements ActionListener{
	
	private JLabel lbcodFunc;
	private JTextField tfnomefunc;
	private JComboBox cbcodFuncio;
	private JButton btapagar;
	private JButton btcancelar;
	private FuncionarioDao funcionariodao;
	
	public ApagaFunc(){
		
		setTitle("Apagar Funcion�rio");
		lbcodFunc = new JLabel("C�digo Funcion�rio");
		cbcodFuncio = new JComboBox();
		tfnomefunc = new JTextField();
		btapagar = new JButton("Apagar");
		btcancelar = new JButton("Cancelar");
		
		setBounds( 0, 0, 300, 130);
		lbcodFunc.setBounds(20,10,200,20);
		tfnomefunc.setBounds(20, 40, 250, 20);
		cbcodFuncio.setBounds(130,10,80,20);
		btapagar.setBounds(20,70,90,20);
		btcancelar.setBounds(180,70,90,20);
		
		add(lbcodFunc);
		add(cbcodFuncio);
		add(tfnomefunc);
		add(btapagar);
		add(btcancelar);
		
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodFuncio.addActionListener(this);
		
		funcionariodao = new FuncionarioDao();
		
		try {
			List<Funcionario> lista = funcionariodao.buscarTodos();
		
			for (Funcionario func : lista) {
				cbcodFuncio.addItem(func.getCodFuncionario()); 
			}
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.cbcodFuncio) {
				String item = String.valueOf(cbcodFuncio.getSelectedItem());			
				int codFunc = Integer.parseInt(item);
				Funcionario funcionario = this.funcionariodao.buscarPorId(codFunc);
				
				this.tfnomefunc.setText(funcionario.getNomeFuncionario());
			}
				
			if(event.getSource() == this.btapagar){
				String item = String.valueOf(cbcodFuncio.getSelectedItem());
				int opcao = 
					JOptionPane.showConfirmDialog(
						this, "Deseja realmente apagar '" + this.tfnomefunc.getText() + "'?", 
						"Apagar Funcion�rio", 
						JOptionPane.YES_NO_OPTION);
				int codApagar = Integer.parseInt(item);
					if (opcao == JOptionPane.YES_OPTION) {
						funcionariodao.apagar(codApagar);
						tfnomefunc.setText("");
						JOptionPane.showMessageDialog(null, "Funcion�rio Apagado com Sucesso!");
					}
					if(event.getSource() == this.btcancelar){
						this.dispose();
					}
				} 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
}
