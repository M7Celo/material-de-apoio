package fox.apagar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Sala;
import fox.dao.SalaDao;
import fox.exception.DaoException;

public class ApagaSala extends JFrame implements ActionListener{
	
	private JLabel lbcodS;
	private JComboBox cbcodSala;
	private JLabel lbnumSala;
	private JTextField tfnumSala;
	private JButton btapagar;
	private JButton btcancelar;
	private SalaDao saladao;
	
	public ApagaSala(){
		
		setTitle("Apagar Sala");
		lbcodS = new JLabel("C�digo Sala");
		lbnumSala = new JLabel("N�mero Sala");
		cbcodSala = new JComboBox();
		tfnumSala = new JTextField();
		btapagar = new JButton("Apagar");
		btcancelar = new JButton("Cancelar");
		
		
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodSala.addActionListener(this);
		
		saladao = new SalaDao();
		
		try {
			List<Sala> lista = saladao.buscarTodos();
		
			for (Sala sala : lista) {
				cbcodSala.addItem(sala.getCodSala()); 
			}
		
		setBounds( 0, 0, 300, 130);
		lbcodS.setBounds(20,10,200,20);
		cbcodSala.setBounds(90,10,50,20);
		lbnumSala.setBounds(20, 40, 80, 20);
		tfnumSala.setBounds(110, 40, 50, 20);
		btapagar.setBounds(20,70,90,20);
		btcancelar.setBounds(180,70,90,20);
		
		add(lbcodS);
		add(lbnumSala);
		add(cbcodSala);
		add(tfnumSala);
		add(btapagar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.cbcodSala) {
				String item = String.valueOf(cbcodSala.getSelectedItem());			
				int codSala = Integer.parseInt(item);
				Sala sala = this.saladao.buscarPorId(codSala);
			
				this.tfnumSala.setText(String.valueOf(sala.getNumSala()));
			}
				
			if(event.getSource() == this.btapagar){
				String item = String.valueOf(cbcodSala.getSelectedItem());
				int opcao = 
					JOptionPane.showConfirmDialog(
						this, "Deseja realmente apagar '" + this.tfnumSala.getText() + "'?", 
						"Apagar Sala", 
						JOptionPane.YES_NO_OPTION);
				int codApagar = Integer.parseInt(item);
					if (opcao == JOptionPane.YES_OPTION) {
						saladao.apagar(codApagar);
						tfnumSala.setText("");
						JOptionPane.showMessageDialog(null, "Sala Apagada com Sucesso!");
					}
				} 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
}
