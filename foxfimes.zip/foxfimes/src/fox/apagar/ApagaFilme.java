package fox.apagar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Descontos;
import fox.bean.Filme;
import fox.dao.FilmeDao;
import fox.exception.DaoException;

public class ApagaFilme extends JFrame implements ActionListener{
	
	private JLabel lbcodFilme;
	private JComboBox cbcodFilme;
	private JTextField txtNomeFilme;
	private JButton btapagar;
	private JButton btcancelar;
	private FilmeDao filmeDao;
	
	public ApagaFilme(){
		
		setTitle("Apagar Filme");
		lbcodFilme = new JLabel("C�digo Filme");
		cbcodFilme = new JComboBox();
		txtNomeFilme = new JTextField();
		btapagar = new JButton("Apagar");
		btcancelar = new JButton("Cancelar");
		
		setBounds( 0, 0, 300, 130);
		lbcodFilme.setBounds(20,10,200,20);
		cbcodFilme.setBounds(100,10,80,20);
		txtNomeFilme.setBounds(10, 40, 260, 20);
		btapagar.setBounds(10,70,90,20);
		btcancelar.setBounds(180,70,90,20);
		
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodFilme.addActionListener(this);
		
		filmeDao = new FilmeDao();
		
		try {
			List<Filme> lista = filmeDao.buscarTodos();
		
			for (Filme f : lista) {
				cbcodFilme.addItem(f.getCodFilme()); 
			}
		
		add(lbcodFilme);
		add(cbcodFilme);
		add(txtNomeFilme);
		add(btapagar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.cbcodFilme) {
				String item = String.valueOf(cbcodFilme.getSelectedItem());
			
				int codFilme = Integer.parseInt(item);
				Filme filme = this.filmeDao.buscarPorId(codFilme);
				
				this.txtNomeFilme.setText(filme.getNomeFilme());
			}
				if(event.getSource() == this.btapagar){
					String item = String.valueOf(cbcodFilme.getSelectedItem());
					int opcao = 
						JOptionPane.showConfirmDialog(
							this, "Deseja realmente apagar '" + this.txtNomeFilme.getText() + "'?", 
							"Apagar Filme", 
							JOptionPane.YES_NO_OPTION);
					int codApagar = Integer.parseInt(item);
						if (opcao == JOptionPane.YES_OPTION) {
							filmeDao.apagar(codApagar);
							txtNomeFilme.setText("");
							JOptionPane.showMessageDialog(null, "Filme Apagado com Sucesso!");
						}
					}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
