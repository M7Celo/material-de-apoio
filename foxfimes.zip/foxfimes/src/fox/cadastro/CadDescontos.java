package fox.cadastro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;


import fox.bean.Descontos;
import fox.dao.DescontosDao;
import fox.exception.CampoObrigatorioException;
import fox.exception.DaoException;
 

public class CadDescontos extends JFrame implements ActionListener {
	
	
	private JLabel lbconv;
	private JTextField tfconv;
	private JLabel lbsind;
	private JTextField tfsind;
	private JLabel lbpromo;
	private JTextField tfpromo;
	private JLabel lbvaldescconv;
	private JComboBox lstconv;
	private JLabel lbvaldescsind;
	private JComboBox lstsind;
	private JLabel lbvaldescpromo;
	private JComboBox lstpromo;
	private JLabel lbdescfixo;
	private JComboBox lstdescfixo;
	private JButton btsalvar;
	private JButton btapagar;
	private JButton btcancelar;
	private JSeparator spconv;
	private JSeparator spsind;
	private JSeparator sppromo;
	
	public CadDescontos (){
		
		// Cria��o de Objetos
		setTitle("Cadastro de Descontos");
		lbconv = new JLabel("Conv�nios");
		tfconv = new JTextField ();
		lbsind = new JLabel("Sindicatos");
		tfsind = new JTextField (5);
		lbpromo = new JLabel("Promocional");
		tfpromo = new JTextField (5);
		lbvaldescconv = new JLabel("Valor de Descontos");
		String[] conv = {"5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%", "50%"};
		lstconv = new JComboBox(conv);
		spconv = new JSeparator();
		lbvaldescsind = new JLabel("Valor de Descontos");
		String[] sind = {"5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%", "50%"};
		lstsind = new JComboBox(sind);
		spsind = new JSeparator();
		lbvaldescpromo = new JLabel("Valor de Descontos");
		String[] promo = {"5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%", "50%"};
		lstpromo = new JComboBox(promo);
		sppromo = new JSeparator();
		lbdescfixo = new JLabel("Descontos Fixo");
		String[] descfixo = {"10%", "20%", "30%", "40%", "50%(Estudante)", "100%(Vip)"};
		lstdescfixo = new JComboBox(descfixo);
		btsalvar = new JButton("Salvar");
		btapagar = new JButton("Limpar");
		btcancelar = new JButton("Cancelar");
	
		
		/* Coordenadas */
		setBounds(0, 0, 400, 320);
		lbconv.setBounds(20, 10, 100, 25);
		tfconv.setBounds(85, 10, 300, 20);
		lbvaldescconv.setBounds(20, 30, 150, 25);
		lstconv.setBounds(135, 30, 80, 20);
		spconv.setBounds(20, 60, 360, 20);
		lbsind.setBounds(20, 70, 100, 25);
		tfsind.setBounds(85, 70, 300, 20);
		lbvaldescsind.setBounds(20, 90, 150, 25);
		lstsind.setBounds(135, 90, 80, 20);
		spsind.setBounds(20, 120, 360, 20);
		lbpromo.setBounds(20, 130, 100, 25);
		tfpromo.setBounds(95, 130, 290, 20);
		lbvaldescpromo.setBounds(20, 150, 150, 25);
		lstpromo.setBounds(135, 150, 80, 20);
		sppromo.setBounds(20, 180, 360, 20);
		lbdescfixo.setBounds(20, 190, 150, 25);
		lstdescfixo.setBounds(115, 190, 120, 20);
		btsalvar.setBounds(20, 230, 85, 25);
		btapagar.setBounds(150, 230, 85, 25);
		btcancelar.setBounds(280,  230, 85, 25);
		
		
		/* Execu��o da Tela */
		add(lbconv);
		add(tfconv);
		add(lbvaldescconv);
		add(lstconv);
		add(spconv);
		add(lbsind);
		add(tfsind);
		add(lbvaldescsind);
		add(lstsind);
		add(spsind);
		add(lbpromo);
		add(tfpromo);
		add(lbvaldescpromo);
		add(lstpromo);
		add(sppromo);
		add(lbdescfixo);
		add(lstdescfixo);
		add(btsalvar);
		add(btapagar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		btsalvar.addActionListener(this);
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);		

	}

	@Override
	public void actionPerformed(ActionEvent event) {	
		try {
			if (event.getSource() == this.btsalvar) {
				
				if ("".equals(tfconv.getText().trim())) {
					throw new CampoObrigatorioException("Nome Conv�nio");
				}
	
				else if ("".equals(tfsind.getText().trim())) {
					throw new CampoObrigatorioException("Nome Sindicato");
				}
				
				else if("".equals(tfpromo.getText().trim())) {
					throw new CampoObrigatorioException("Nome Promo��o");
				}
				
				DescontosDao descontosDao = new DescontosDao();
				Descontos descontos = new Descontos();
				descontos.setNomeConvenio(tfconv.getText());
				descontos.setValorConvenio(this.lstconv.getSelectedItem().toString());
				descontos.setNomeSind(tfsind.getText());
				descontos.setValorSind(this.lstsind.getSelectedItem().toString());
				descontos.setNomePromo(tfpromo.getText());
				descontos.setValorPromo(this.lstpromo.getSelectedItem().toString());
				descontos.setDescontosFixo(this.lstdescfixo.getSelectedItem().toString());
				descontosDao.criar(descontos);
			
				JOptionPane.showMessageDialog(this, "Descontos cadastrado com sucesso");
				
				setValoresIniciais();
				
			} else if (btapagar == event.getSource()) {
				setValoresIniciais();
			} else if (btcancelar == event.getSource()) {
				this.dispose();
			}
		} catch (CampoObrigatorioException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Erro de digita��o", JOptionPane.ERROR_MESSAGE);
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar a base, contactar o Marcelo ou o Vinicius", "Erro de banco de dados", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	private void setValoresIniciais() {
		tfconv.setText("");
		tfsind.setText("");
		tfpromo.setText("");
		}
}
