package fox.utilitarios.visual;

import java.awt.Cursor;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * @author ProfessorNpc
 *
 */
public class JanelaInicial extends JFrame {
	
    String temaW = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
    String temaM = "javax.swing.plaf.metal.MetalLookAndFeel";
    String temaL = "com.birosoft.liquid.LiquidLookAndFeel";
    String temaC = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
    String temaN = "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel";
    String temaP = temaW;

	private String meuIp;
	private int portaOuvida;
	
	private JLabel labelIPAmigo;
	private JTextField textIP;
	private JLabel labelPorta;
	private JTextField textPorta;
	private JButton conectarButton;
	private JButton ouvirButton;

	private ServerSocket serverSocket;
	private Socket socket;
	
	private OutputStream outputStream;
	private InputStream inputStream;
	
	public JanelaInicial() throws HeadlessException {
		tentaSetaTema();
		
		LeiouteCadastroBuilder leiaute = new LeiouteCadastroBuilder(this);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setSize(2584/6, 1597/8);
		String showInputDialog = JOptionPane.showInputDialog("Qual porta voc� quer ouvir?");
		if (showInputDialog!=null) {
			this.portaOuvida = Integer.parseInt(showInputDialog);
			this.meuIp = localhost();
			String titulo = "Meu ip : " + meuIp + "   Ouvindo a porta : " + portaOuvida;
			setTitle(titulo);
			
			labelIPAmigo = new JLabel("ip amigo:");
			textIP = new JTextField(15);
			labelPorta = new JLabel("porta:");
			textPorta = new JTextField(5);
			conectarButton = new JButton("Conectar");
			ouvirButton = new JButton("Ouvir");
			
			ouvirButton.addActionListener(new TratadorOuvirButton(this));
			conectarButton.addActionListener(new TratadorConectarButton(this));
			
			leiaute
				.inicio(2, 2)
					.add(labelIPAmigo, 1)
					.add(textIP, 1)
				.pulaLinha()
					.add(labelPorta, 1)
					.esq().add(textPorta, 1)
				.pulaLinha().dir()
					.add(conectarButton, 1)
					.add(ouvirButton, 1);
			
			setVisible(true);
		}
	}
	
	private class TratadorOuvirButton implements ActionListener {

		private JFrame janelaInicial;
		
		public TratadorOuvirButton(JFrame janelaInicial) {
			this.janelaInicial = janelaInicial;
		}

		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent e) {
			if (ouvirButton.getText().equals("Ouvir")) {
				textIP.disable();
				textPorta.disable();
				conectarButton.disable();
				ouvirButton.setText("Cancelar");
				setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				
				try {
					serverSocket = new ServerSocket(portaOuvida, 1);
					
					socket = serverSocket.accept();
					
					outputStream = socket.getOutputStream();
					ObjectOutputStream os = new ObjectOutputStream(outputStream);
					System.out.println("Enviando 'Ola'");
					os.writeObject("Ola");
					os.flush();
					
					inputStream = socket.getInputStream();
					ObjectInputStream is = new ObjectInputStream(inputStream);
					String msg = (String)is.readObject();
					
					new JanelaConversa(serverSocket, socket, os, is);
					
					
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(janelaInicial, e1.getMessage());
				} catch (ClassNotFoundException e2) {
					JOptionPane.showMessageDialog(janelaInicial, e2.getMessage());
				}
				
			} else {
				textIP.enable();
				textPorta.enable();
				conectarButton.enable();
				ouvirButton.setText("Ouvir");
				setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}

			
		}
		
	}
	
	private class TratadorConectarButton implements ActionListener {

		private JFrame janelaInicial;
		
		public TratadorConectarButton(JFrame janelaInicial) {
			this.janelaInicial = janelaInicial;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if (conectarButton.getText().equals("Conectar")) {
				textIP.disable();
				textPorta.disable();
				ouvirButton.disable();
				conectarButton.setText("Cancelar");
				setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				
				try {
					socket = new Socket(textIP.getText(), Integer.parseInt(textPorta.getText()));
					
					outputStream = socket.getOutputStream();
					inputStream = socket.getInputStream();
					
					ObjectInputStream is = new ObjectInputStream(inputStream);
					String msg = (String)is.readObject();
					System.out.println("Recebido pedido de confirmacao '" + msg + "'");

					ObjectOutputStream os = new ObjectOutputStream(outputStream);
					System.out.println("Enviando confirmacao 'Beleza'");
					os.writeObject("Beleza");					
					os.flush();
					
					new JanelaConversa(null, socket, os, is);
					
					
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(janelaInicial, e1.getMessage());
				} catch (ClassNotFoundException e2) {
					JOptionPane.showMessageDialog(janelaInicial, e2.getMessage());
				}
				
			} else {
				textIP.enable();
				textPorta.enable();
				ouvirButton.enable();
				conectarButton.setText("Conectar");
				setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
		}
		
	}

	public void tentaSetaTema() {
		UIManager.LookAndFeelInfo[] looks = UIManager.getInstalledLookAndFeels();
		for (UIManager.LookAndFeelInfo look :looks) {
			if (look.getClassName().matches("(?i).*nimbus.*")) {
				try {
					UIManager.setLookAndFeel(look.getClassName());
					SwingUtilities.updateComponentTreeUI(this);
					return;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * RETORNA O N�MERO DE IP
	 */
	public static String localhost() {
		try {
			return InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			return new String("127.0.0.1");
		}
	}
}
