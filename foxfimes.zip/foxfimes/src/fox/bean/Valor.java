package fox.bean;

public class Valor {
	
	private int codValor;
	private String nomeFilme;
	private String valorFilme;
	
	public int getCodValor() {
		return codValor;
	}
	public void setCodValor(int codValor) {
		this.codValor = codValor;
	}
	public String getNomeFilme() {
		return nomeFilme;
	}
	public void setNomeFilme(String nomeFilme) {
		this.nomeFilme = nomeFilme;
	}
	public String getValorFilme() {
		return valorFilme;
	}
	public void setValorFilme(String valorFilme) {
		this.valorFilme = valorFilme;
	}
	@Override
	public String toString() {
		return "Valor [codValor=" + codValor + ", nomeFilme=" + nomeFilme
				+ ", valorFilme=" + valorFilme + "]";
	}
	
	
}
