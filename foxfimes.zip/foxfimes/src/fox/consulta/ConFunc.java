package fox.consulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import fox.bean.Descontos;
import fox.bean.Funcionario;
import fox.dao.FuncionarioDao;
import fox.exception.DaoException;

public class ConFunc extends JFrame implements ActionListener {
	
	private JLabel lbcod_func;
	private JTextField tfnivelAcesso;
	private JLabel lbnomefunc;
	private JTextField tfnomefunc;
	private JLabel lbsenha_func;
	private JPasswordField pfsenha_func;
	private JLabel lbniv_acesso;
	private JComboBox cbcodFunc;
	private JButton btbuscar;
	private JButton btcancelar;
	private FuncionarioDao funcionariodao;
	private Funcionario funcionario;
	
	public ConFunc () {
		
		/* Cria��o de Objetos */
		setTitle("Consulta Funcion�rio");
		lbcod_func = new JLabel("C�digo Funcion�rio");
		tfnivelAcesso = new JTextField ();
		lbnomefunc = new JLabel("Nome Funcion�rio");
		tfnomefunc = new JTextField();
		lbsenha_func = new JLabel("Senha Funcion�rio");
		pfsenha_func = new JPasswordField();
		lbniv_acesso = new JLabel("N�vel de Acesso Funcion�rio");
		cbcodFunc = new JComboBox();
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");

		/* Coordenadas */
		setBounds(0, 0, 360, 210);
		lbcod_func.setBounds(20, 10, 150, 20);
		cbcodFunc.setBounds(130, 10, 80, 20);
		lbnomefunc.setBounds(20, 40, 130, 20);
		tfnomefunc.setBounds(125, 40, 200, 20);
		lbsenha_func.setBounds(20, 65, 200, 20);
		pfsenha_func.setBounds(125, 65, 200, 20);
		lbniv_acesso.setBounds(20, 90, 180, 20);
		tfnivelAcesso.setBounds(20, 110, 65, 20);
		btbuscar.setBounds(20, 140, 90, 25);
		btcancelar.setBounds(240, 140, 90, 25);
		
		btbuscar.addActionListener(this);
		cbcodFunc.addActionListener(this);
		btcancelar.addActionListener(this);
		
		funcionariodao = new FuncionarioDao();
		funcionario = new Funcionario();
		
		try {
			List<Funcionario> lista = funcionariodao.buscarTodos();
		
			for (Funcionario func : lista) {
				cbcodFunc.addItem(func.getCodFuncionario()); 
			}

		/* Execu��o na Tela */
		add(lbcod_func);
		add(tfnivelAcesso);
		add(lbnomefunc);
		add(tfnomefunc);
		add(lbsenha_func);
		add(pfsenha_func);
		add(lbniv_acesso);
		add(cbcodFunc);
		add(btbuscar);
		add(btcancelar);

		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodFunc.getSelectedItem());
				int codDesconto = Integer.parseInt(item);
				funcionario = funcionariodao.buscarPorId(codDesconto);	
				
				tfnomefunc.setText(funcionario.getNomeFuncionario());
				pfsenha_func.setText(funcionario.getSenha());
				tfnivelAcesso.setText(String.valueOf(funcionario.getNivelAcesso()));
					JOptionPane.showMessageDialog(null, "Funcion�rio Consultado com Sucesso!");
				}if (btcancelar == event.getSource()) {
					this.dispose();
				}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
