package fox.consulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Venda;
import fox.dao.VendaDao;
import fox.exception.DaoException;

public class ConVendas extends JFrame implements ActionListener {
	
	private JLabel lbnuming;
	private JComboBox cbnumIng;
	private JLabel lbnomesessao;
	private JTextField txtnomesessao;
	private JLabel lbnomefilme;
	private JTextField txtnomefilme;
	private JLabel lbnomedesc;
	private JTextField txtnomedesc;
	private JLabel lbvalordesc;
	private JTextField txtvalordesc;
	private JLabel lbvalorfilme;
	private JTextField txtvalorfilme;
	private JLabel lbvalorrec;
	private JTextField txtvalorrec;
	private JLabel lbtroco;
	private JTextField txttroco;
	private JLabel lbvalorfinal;
	private JTextField txtvalorfinal;
	private JButton btbuscar;
	private JButton btcancelar;
	private VendaDao vendadao;
	private Venda venda;

	public ConVendas () {
		
		/* Cria��o de Objetos */
		setTitle("Registro de Vendas");
		lbnuming = new JLabel("N�mero Ingresso");
		cbnumIng = new JComboBox();
		lbnomesessao = new JLabel("Sess�o");
		txtnomesessao = new JTextField();
		lbnomefilme = new JLabel("Filme");
		txtnomefilme = new JTextField();
		lbnomedesc= new JLabel("Descontos");
		txtnomedesc = new JTextField();
		lbvalordesc= new JLabel("Valor Descontos");
		txtvalordesc = new JTextField();
		lbvalorfilme = new JLabel("Valor Filme");
		txtvalorfilme = new JTextField();
		lbvalorrec = new JLabel("Valor Recebido");
		txtvalorrec = new JTextField();
		lbtroco = new JLabel("Troco");
		txttroco = new JTextField();
		lbvalorfinal= new JLabel("Valor Final");
		txtvalorfinal = new JTextField();
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		
		/*Coordenadas*/
		setBounds(0,0,400,340);
		lbnuming.setBounds(20,10,100,20);
		cbnumIng.setBounds(125,10, 80, 20);
		lbnomesessao.setBounds(20,40,80,20);
		txtnomesessao.setBounds(70,40,205,20);
		lbnomefilme.setBounds(20,65,80,20);
		txtnomefilme.setBounds(55,65,220,20);
		lbnomedesc.setBounds(20,90,80,20);
		txtnomedesc.setBounds(85,90,190,20);
		lbvalordesc.setBounds(20,110,100,20);
		txtvalordesc.setBounds(120,110,100,20);
		lbvalorfilme.setBounds(20,135,100,20);
		txtvalorfilme.setBounds(85,135,100,20);
		lbvalorrec.setBounds(20,160,100,20);
		txtvalorrec.setBounds(110,160,100,20);
		lbtroco.setBounds(20,185,100,20);
		txttroco.setBounds(60,185,100,20);
		lbvalorfinal.setBounds(20,210,100,20);
		txtvalorfinal.setBounds(85,210,100,20);
		btbuscar.setBounds(20, 250, 90, 25);
		btcancelar.setBounds(280, 250, 90 ,25);
		
		cbnumIng.addActionListener(this);
		btbuscar.addActionListener(this);
		btcancelar.addActionListener(this);
		
		
		vendadao = new VendaDao();
		venda = new Venda();
		
		try {
			List<Venda> lista =vendadao.buscarTodos();
		
			for (Venda v : lista) {
				cbnumIng.addItem(v.getNumIng()); 
			}
		
		/*Execu��o na Tela*/
		add(lbnuming);
		add(cbnumIng);
		add(lbnomesessao);
		add(txtnomesessao);
		add(lbnomefilme);
		add(txtnomefilme);
		add(lbnomedesc);
		add(txtnomedesc);
		add(lbvalordesc);
		add(txtvalordesc);
		add(lbvalorfilme);
		add(txtvalorfilme);
		add(lbvalorrec);
		add(txtvalorrec);
		add(lbtroco);
		add(txttroco);
		add(lbvalorfinal);
		add(txtvalorfinal);
		add(btbuscar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
	} catch (DaoException e) {
		JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
		this.dispose();
		e.printStackTrace();
	}

	}
	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbnumIng.getSelectedItem());
				int codValor = Integer.parseInt(item);
				venda = vendadao.buscarPorId(codValor);	
				
				txtnomesessao.setText(venda.getNomesessao());
				txtnomefilme.setText(venda.getNomefilme());
				txtnomedesc.setText(venda.getNomedesc());
				txtvalordesc.setText(venda.getValordesc());
				txtvalorfilme.setText(venda.getValorfilme());
				txtvalorrec.setText(venda.getValorrec());
				txttroco.setText(venda.getTroco());
				txtvalorfinal.setText(venda.getValorfinal());
				
					JOptionPane.showMessageDialog(null, "Venda Consultada com Sucesso!");
				}if (btcancelar == event.getSource()) {
					this.dispose();
				}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
