package fox.consulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Descontos;
import fox.bean.Valor;
import fox.dao.DescontosDao;
import fox.dao.ValorDao;
import fox.exception.DaoException;

public class ConValores extends JFrame implements ActionListener {
	
	private JLabel lbcod_valor;
	private JComboBox cbcodValor;
	private JLabel lbnomef;
	private JTextField tfnomef;
	private JButton btbuscar;
	private JButton btcancelar;
	private JLabel lbvalorPre�o;
	private JTextField tfvalorPre�o;
	private ValorDao valordao;
	private Valor valor;
	
	public ConValores () {
	
			/* Cria��o de Objetos */
			setTitle("Consulta Valores");
			lbcod_valor = new JLabel("C�digo Valor");
			cbcodValor = new JComboBox();
			lbnomef = new JLabel("Nome do Filme");
			tfnomef = new JTextField (5);
			btbuscar = new JButton("Buscar");
			btcancelar = new JButton("Cancelar");
			lbvalorPre�o = new JLabel("Valor R$:");
			tfvalorPre�o = new JTextField ();
			
			/* Coordenadas */
			setBounds(0, 0, 430, 200);
			lbvalorPre�o.setBounds(20, 65, 100, 20);
			tfvalorPre�o.setBounds(85, 65, 70, 20);
			lbcod_valor.setBounds(20, 10, 150, 20);
			cbcodValor.setBounds(95, 10, 70, 20);
			lbnomef.setBounds(20, 40, 100, 20);
			tfnomef.setBounds(110, 40, 300, 20);
			btbuscar.setBounds(20, 110, 90, 25);
			btcancelar.setBounds(300, 110, 90, 25);
			
			btbuscar.addActionListener(this);
			cbcodValor.addActionListener(this);
			btcancelar.addActionListener(this);
			
			valordao = new ValorDao();
			valor = new Valor();
			
			try {
				List<Valor> lista = valordao.buscarTodos();
			
				for (Valor v : lista) {
					cbcodValor.addItem(v.getCodValor()); 
				}
			
			/* Execu��o na Tela */
			add(lbvalorPre�o);
			add(tfvalorPre�o);
			add(lbcod_valor);
			add(cbcodValor);
			add(lbnomef);
			add(tfnomef);
			add(btbuscar);
			add(btcancelar);
	
			setLayout(null);
			setVisible(true);
			setResizable(false);
			
			} catch (DaoException e) {
				JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
				this.dispose();
				e.printStackTrace();
			}
				
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodValor.getSelectedItem());
				int codValor = Integer.parseInt(item);
				valor = valordao.buscarPorId(codValor);	
				
				tfnomef.setText(valor.getNomeFilme());
				tfvalorPre�o.setText(String.valueOf(valor.getValorFilme()));
					JOptionPane.showMessageDialog(null, "Valor do Filme Consultado com Sucesso!");
				}if (btcancelar == event.getSource()) {
					this.dispose();
				}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
}
