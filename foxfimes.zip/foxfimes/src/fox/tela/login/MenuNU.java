package fox.tela.login;

import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import fox.apagar.ApagaDescontos;
import fox.apagar.ApagaFilme;
import fox.apagar.ApagaFunc;
import fox.apagar.ApagaSala;
import fox.apagar.ApagaSessao;
import fox.apagar.ApagaValores;
import fox.atualiza.AtualizaDescontos;
import fox.atualiza.AtualizaFilmes;
import fox.atualiza.AtualizaFunc;
import fox.atualiza.AtualizaSalas;
import fox.atualiza.AtualizaSessao;
import fox.atualiza.AtualizaValores;
import fox.cadastro.CadDescontos;
import fox.cadastro.CadFilmes;
import fox.cadastro.CadFunc;
import fox.cadastro.CadSalas;
import fox.cadastro.CadSessao;
import fox.cadastro.CadValores;
import fox.consulta.ConDescontos;
import fox.consulta.ConFilmes;
import fox.consulta.ConFunc;
import fox.consulta.ConSalas;
import fox.consulta.ConSessao;
import fox.consulta.ConValores;
import fox.consulta.ConVendas;
import fox.exception.DaoException;
import fox.re.diario.RelatorioDiarioDescontos;
import fox.re.diario.RelatorioDiarioFilmes;
import fox.re.diario.RelatorioDiarioFuncionario;
import fox.re.diario.RelatorioDiarioSalas;
import fox.re.diario.RelatorioDiarioSessao;
import fox.re.diario.RelatorioDiarioValores;
import fox.re.diario.RelatorioDiarioVendas;
import fox.re.mensal.RelatorioMensalDescontos;
import fox.re.mensal.RelatorioMensalFilmes;
import fox.re.mensal.RelatorioMensalFuncionario;
import fox.re.mensal.RelatorioMensalSalas;
import fox.re.mensal.RelatorioMensalSessao;
import fox.re.mensal.RelatorioMensalValores;
import fox.re.mensal.RelatorioMensalVendas;
import fox.sobre.Contato;
import fox.sobre.Sobre;
import fox.sobre.Versao;
import fox.utilitarios.visual.Data;
import fox.vendas.ing.VendaIng;

public class MenuNU extends JFrame implements ActionListener{
	
	Data mostrarData = new Data();
	Data mostrarHora = new Data();
	
	private String temaW;
	private String temaN;
	private String temaM;
	private String temaL;
	private String temaC;
	private String temaP;
	final JLabel data;
	final JLabel hora;
	
	 public void LookAndFeelTema(){
         try{
            UIManager.setLookAndFeel(temaP);
            SwingUtilities.updateComponentTreeUI(this);
        }catch(Exception erro){
            JOptionPane.showMessageDialog(null, erro);
        }

}

	private JMenuBar barPrincipal;
	private JMenu mnCadastro;
	private JMenuItem mitempromo;
	private JMenuItem mitemFilme;
	private JMenuItem mitemFuncionario;
	private JMenuItem mitemSalas;
	private JMenuItem mitemSessao;
	private JMenuItem mitemValores;
	private JMenu mnConsulta;
	private JMenuItem mitemConsultapromo;
	private JMenuItem mitemConsultaFilme;
	private JMenuItem mitemConsultaFuncionario;
	private JMenuItem mitemConsultaSalas;
	private JMenuItem mitemConsultaSessao;
	private JMenuItem mitemConsultaValores;
	private JMenuItem mitemConsultaRegistroVendas;
	private JMenu mnApagar;
	private JMenuItem mitemAlterarpromo;
	private JMenuItem mitemAlterarFilme;
	private JMenuItem mitemAlterarFuncionario;
	private JMenuItem mitemAlterarSalas;
	private JMenuItem mitemAlterarSessao;
	private JMenuItem mitemAlterarValores;
	private JMenu mnAlterar;
	private JMenuItem mitemApagarpromo;
	private JMenuItem mitemApagarFilme;
	private JMenuItem mitemApagarFuncionario;
	private JMenuItem mitemApagarSalas;
	private JMenuItem mitemApagarSessao; 
	private JMenuItem mitemApagarValores;
	private JMenu mnVenda;
	private JMenuItem mitemVenda_de_Ingressos;
	private JMenu mnRelatorio;
	private JMenu mnRelatorioDiario;
	private JMenuItem mitemConsultaRelatorioDiarioPromo;
	private JMenuItem mitemConsultaRelatorioDiarioFilmes;
	private JMenuItem mitemConsultaRelatorioDiarioFuncionario;
	private JMenuItem mitemConsultaRelatorioDiarioSalas;
	private JMenuItem mitemConsultaRelatorioDiarioSessao;
	private JMenuItem mitemConsultaRelatorioDiarioValores;
	private JMenuItem mitemConsultaRelatorioDiarioRegistroVendas;
	private JMenu mnRelatorioMensal;
	private JMenuItem mitemConsultaRelatorioMensalPromo;
	private JMenuItem mitemConsultaRelatorioMensalFilmes;
	private JMenuItem mitemConsultaRelatorioMensalFuncionario;
	private JMenuItem mitemConsultaRelatorioMensalSalas;
	private JMenuItem mitemConsultaRelatorioMensalSessao;
	private JMenuItem mitemConsultaRelatorioMensalValores;
	private JMenuItem mitemConsultaRelatorioMensalRegistroVendas;
	private JMenu mnSobre;
	private JMenuItem mitemSobre;
	private JMenuItem mitemVersao;
	private JMenuItem mitemContato;
	private JMenu mnUtilitario;
	private JMenuItem mitemTema_01;
	private JMenuItem mitemTema_02;
	private JMenuItem mitemTema_03;
	private JMenuItem mitemTema_04;
	private JMenuItem mitemTema_05;
	private JButton btsair;
	
	public MenuNU  (){ 
		
		temaW = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
		temaN = "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel";
		temaM = "javax.swing.plaf.metal.MetalLookAndFeel";
		temaL = "com.birosoft.liquid.LiquidLookAndFeel";
		temaC = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
		temaP = temaL;
				
		this.data = new JLabel();
		this.hora = new JLabel();
		
		
		
		Thread threadDataSistema = new Thread() {
			@Override
			public void run() {
				while (true) {
					mostrarData.LeData();
					data.setText("Datal Atual: "+mostrarData.diaSemana+", "+mostrarData.dia+" de "+mostrarData.mes+" de "+mostrarData.ano);
					
					mostrarHora.LeHora();
					hora.setText("Hora Atual: "+mostrarHora.hora);
					
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		threadDataSistema.start();
		//timer1.start();		
		
		LookAndFeelTema();
		
		
		/* Cria��o de Objetos - Menu */
		setTitle("FOX FILMES");
		this.barPrincipal = new JMenuBar();
		this.mnCadastro = new JMenu("Cadastro");
		this.mitempromo = new JMenuItem ("Descontos");
		this.mitemFilme = new JMenuItem ("Filmes");
		this.mitemFuncionario = new JMenuItem ("Funcion�rio");
		this.mitemSalas = new JMenuItem ("Salas");
		this.mitemSessao = new JMenuItem ("Sess�o");
		this.mitemValores = new JMenuItem ("Valores");
		this.mnConsulta = new JMenu("Consulta");
		this.mitemConsultapromo = new JMenuItem ("Descontos");
		this.mitemConsultaFilme = new JMenuItem ("Filmes");
		this.mitemConsultaFuncionario = new JMenuItem ("Funcion�rio");
		this.mitemConsultaSalas = new JMenuItem ("Salas");
		this.mitemConsultaSessao = new JMenuItem ("Sess�o");
		this.mitemConsultaValores = new JMenuItem ("Valores");
		this.mitemConsultaRegistroVendas = new JMenuItem ("Vendas");
		this.mnAlterar = new JMenu("Atualizar");
		this.mitemAlterarpromo = new JMenuItem ("Descontos");
		this.mitemAlterarFilme = new JMenuItem ("Filmes");
		this.mitemAlterarFuncionario = new JMenuItem ("Funcion�rio");
		this.mitemAlterarSalas = new JMenuItem ("Salas");
		this.mitemAlterarSessao = new JMenuItem ("Sess�o");
		this.mitemAlterarValores = new JMenuItem ("Valores");
		this.mnApagar = new JMenu("Apagar");
		this.mitemApagarpromo = new JMenuItem ("Descontos");
		this.mitemApagarFilme = new JMenuItem ("Filmes");
		this.mitemApagarFuncionario = new JMenuItem ("Funcion�rio");
		this.mitemApagarSalas = new JMenuItem ("Salas");
		this.mitemApagarSessao = new JMenuItem ("Sess�o");
		this.mitemApagarValores = new JMenuItem ("Valores");
		this.mnVenda = new JMenu("Venda");
		this.mitemVenda_de_Ingressos = new JMenuItem ("Ingressos");
		this.mnRelatorio = new JMenu("Relat�rio");
		this.mnRelatorioDiario = new JMenu("Di�rio");
		this.mitemConsultaRelatorioDiarioPromo = new JMenuItem ("Descontos");
		this.mitemConsultaRelatorioDiarioFilmes = new JMenuItem ("Filmes");
		this.mitemConsultaRelatorioDiarioFuncionario = new JMenuItem ("Funcion�rio");
		this.mitemConsultaRelatorioDiarioSalas = new JMenuItem ("Salas");
		this.mitemConsultaRelatorioDiarioSessao = new JMenuItem ("Sess�o");
		this.mitemConsultaRelatorioDiarioValores = new JMenuItem ("Valores");
		this.mitemConsultaRelatorioDiarioRegistroVendas = new JMenuItem ("Vendas");
		this.mnRelatorioMensal = new JMenu("Mensal");
		this.mitemConsultaRelatorioMensalPromo = new JMenuItem ("Descontos");
		this.mitemConsultaRelatorioMensalFilmes = new JMenuItem ("Filmes");
		this.mitemConsultaRelatorioMensalFuncionario = new JMenuItem ("Funcion�rio");
		this.mitemConsultaRelatorioMensalSalas = new JMenuItem ("Salas");
		this.mitemConsultaRelatorioMensalSessao = new JMenuItem ("Sess�o");
		this.mitemConsultaRelatorioMensalValores = new JMenuItem ("Valores");
		this.mitemConsultaRelatorioMensalRegistroVendas = new JMenuItem ("Vendas");
		this.mnSobre = new JMenu("Sobre");
		this.mitemSobre = new JMenuItem ("Sobre");
		this.mitemVersao = new JMenuItem ("Vers�o");
		this.mitemContato = new JMenuItem ("Contato");
		this.mnUtilitario = new JMenu("Utilit�rio");
		this.mitemTema_01 = new JMenuItem ("Tema 01 - CDE/MODIF");
		this.mitemTema_02 = new JMenuItem ("Tema 02 - Liquid");
		this.mitemTema_03 = new JMenuItem ("Tema 03 - Metal");
		this.mitemTema_04 = new JMenuItem ("Tema 04 - Nimbus");
		this.mitemTema_05 = new JMenuItem ("Tema 05 - Windows");
		this.btsair = new JButton("Sair");
		btsair.addActionListener(this);
		
		/* Coordenadas - Menu */
		setBounds(250,100,800,600);
		barPrincipal.setBounds(0, 0, 640, 50);
		mnCadastro.setBounds(10, 10, 640, 50);
		data.setBounds(20, 580, 300, 30);
		hora.setBounds(20, 560, 300, 30);
		
		
		
		
		/* Execu��o na Tela - Menu */
		add(data);
		add(hora);
		mnCadastro.add(mitemFilme);
		mnCadastro.add(mitemFuncionario);
		mnCadastro.add(mitempromo);
		mnCadastro.add(mitemSalas);
		mnCadastro.add(mitemSessao);
		mnCadastro.add(mitemValores);
		mnCadastro.setMnemonic('C');
		barPrincipal.add(mnConsulta);
		mnConsulta.add(mitemConsultaFilme);
		mnConsulta.add(mitemConsultaFuncionario);
		mnConsulta.add(mitemConsultapromo);
		mnConsulta.add(mitemConsultaSalas);
		mnConsulta.add(mitemConsultaSessao);
		mnConsulta.add(mitemConsultaValores);
		mnConsulta.add(mitemConsultaRegistroVendas);
		mnConsulta.setMnemonic('o');
		mnApagar.add(mitemApagarFilme);
		mnApagar.add(mitemApagarFuncionario);
		mnApagar.add(mitemApagarpromo);
		mnApagar.add(mitemApagarSalas);
		mnApagar.add(mitemApagarSessao);
		mnApagar.add(mitemApagarValores);
		mnApagar.setMnemonic('p');
		mnAlterar.add(mitemAlterarFilme);
		mnAlterar.add(mitemAlterarFuncionario);
		mnAlterar.add(mitemAlterarpromo);
		mnAlterar.add(mitemAlterarSalas);
		mnAlterar.add(mitemAlterarSessao);
		mnAlterar.add(mitemAlterarValores);
		mnAlterar.setMnemonic('A');
		barPrincipal.add(mnVenda);
		mnVenda.add(mitemVenda_de_Ingressos);
		mnVenda.setMnemonic('V');
		mnRelatorio.setMnemonic('R');
		mnRelatorio.add(mnRelatorioDiario);
		mnRelatorioDiario.add(mitemConsultaRelatorioDiarioPromo);
		mnRelatorioDiario.add(mitemConsultaRelatorioDiarioFilmes);
		mnRelatorioDiario.add(mitemConsultaRelatorioDiarioFuncionario);
		mnRelatorioDiario.add(mitemConsultaRelatorioDiarioSalas);
		mnRelatorioDiario.add(mitemConsultaRelatorioDiarioSessao);
		mnRelatorioDiario.add(mitemConsultaRelatorioDiarioValores);
		mnRelatorioDiario.add(mitemConsultaRelatorioDiarioRegistroVendas);
		mnRelatorio.add(mnRelatorioMensal);
		mnRelatorioMensal.add(mitemConsultaRelatorioMensalPromo);
		mnRelatorioMensal.add(mitemConsultaRelatorioMensalFilmes);
		mnRelatorioMensal.add(mitemConsultaRelatorioMensalFuncionario);
		mnRelatorioMensal.add(mitemConsultaRelatorioMensalSalas);
		mnRelatorioMensal.add(mitemConsultaRelatorioMensalSessao);
		mnRelatorioMensal.add(mitemConsultaRelatorioMensalValores);
		mnRelatorioMensal.add(mitemConsultaRelatorioMensalRegistroVendas);
		barPrincipal.add(mnSobre);
		mnSobre.setMnemonic('S');
		mnSobre.add(mitemSobre);
		mnSobre.add(mitemVersao);
		mnSobre.add(mitemContato);
		barPrincipal.add(mnUtilitario);
		mnUtilitario.setMnemonic('U');
		mnUtilitario.add(mitemTema_01);
		mnUtilitario.add(mitemTema_02);
		mnUtilitario.add(mitemTema_03);
		mnUtilitario.add(mitemTema_04);
		mnUtilitario.add(mitemTema_05);
		barPrincipal.add(btsair);
		btsair.setMnemonic('a');
		
		setLayout(new FlowLayout());
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		setJMenuBar(barPrincipal);
		
		
		mitemFilme.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				CadFilmes objFilme = new CadFilmes();
				
				//objFilme.setLayout(null);
				//objFilme.setVisible(true);
			}	
		});
		mitemFuncionario.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				CadFunc objFuncionario = new CadFunc();
				
				//objFuncionario.setLayout(null);
				//objFuncionario.setVisible(true);
			}	
		});
		mitemSalas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				CadSalas objSalas = new CadSalas();
				
				//objSalas.setLayout(null);
				//objSalas.setVisible(true);
			}	
		});
		mitemSessao.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				CadSessao objSessao = new CadSessao();
				
				//objSessao.setLayout(null);
				//objSessao.setVisible(true);
			}	
		});
		mitemValores.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				CadValores objValores = new CadValores();
				
				//objSessao.setLayout(null);
				//objSessao.setVisible(true);
			}	
		});
		mitempromo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				CadDescontos objpromo = new CadDescontos();
				
				//objDescontos.setLayout(null);
				//objDescontos.setVisible(true);
			}	
		});
		mitemConsultapromo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				ConDescontos objConsultapromo = new ConDescontos();
				
				//objConsultaDescontos.setLayout(null);
				//objConsultaDescontos.setVisible(true);
			}	
		});
		
		mitemConsultaFilme.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				ConFilmes objConsultaFilme = new ConFilmes();
				
				//objConsultaFilme.setLayout(null);
				//objConsultaFilme.setVisible(true);
			}	
		});
		mitemConsultaFuncionario.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				ConFunc objConsultaFuncionario = new ConFunc();
				
				//objConsultaFuncionario.setLayout(null);
				//objConsultaFuncionario.setVisible(true);
			}	
		});
		mitemConsultaSalas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				ConSalas objConsultaSalas = new ConSalas();
				
				//objConsultaSalas.setLayout(null);
				//objConsultaSalas.setVisible(true);
			}	
		});
		mitemConsultaSessao.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				ConSessao objConsultaSessao = new ConSessao();
				
				//objConsultaSessao.setLayout(null);
				//objConsultaSessao.setVisible(true);
			}	
		});
		mitemConsultaRegistroVendas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				ConVendas objConsultaRegistroVendas = new ConVendas();
				
				//objConsultaRegistroVendas.setLayout(null);
				//objConsultaRegistroVendas.setVisible(true);
			}	
		});
		mitemVenda_de_Ingressos.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				VendaIng objVendaIngressos = new VendaIng();
				
				//objVendaIngressos.setLayout(null);
				//objVendaIngressos.setVisible(true);
			}	
		});
		mitemConsultaValores.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				ConValores objConsultaValores = new ConValores();
				
				//objSessao.setLayout(null);
				//objSessao.setVisible(true);
			}	
		});
		mitemConsultaRelatorioDiarioFilmes.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				RelatorioDiarioFilmes objRelatorioDiarioFilmes = new RelatorioDiarioFilmes();
				
				//objRelatorioDiarioFilmes.setLayout(null);
				//objRelatorioDiarioFilmes.setVisible(true);
			}	
		});
		mitemConsultaRelatorioDiarioPromo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				RelatorioDiarioDescontos objRelatorioDiarioPromo = new RelatorioDiarioDescontos();
				
				//objRelatorioDiarioPromo.setLayout(null);
				//objRelatorioDiarioPromo.setVisible(true);
			}	
		});
		mitemConsultaRelatorioDiarioFuncionario.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				try {
					RelatorioDiarioFuncionario objRelatorioDiarioFuncionario = new RelatorioDiarioFuncionario();
				} catch (HeadlessException e) {
					e.printStackTrace();
				} catch (DaoException e) {
					e.printStackTrace();
				}
				
				//objRelatorioDiarioFuncionario.setLayout(null);
				//objRelatorioDiarioFuncionario.setVisible(true);
			}	
		});
		mitemConsultaRelatorioDiarioSalas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				RelatorioDiarioSalas objRelatorioDiarioSalas = new RelatorioDiarioSalas();
				
				//objRelatorioDiarioSalas.setLayout(null);
				//objRelatorioDiarioSalas.setVisible(true);
			}	
		});
		mitemConsultaRelatorioDiarioSessao.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				RelatorioDiarioSessao objRelatorioDiarioSessao = new RelatorioDiarioSessao();
				
				//objRelatorioDiarioSessao.setLayout(null);
				//objRelatorioDiarioSessao.setVisible(true);
			}	
		});
		mitemConsultaRelatorioDiarioValores.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				RelatorioDiarioValores objRelatorioDiarioValores = new RelatorioDiarioValores();
				
				//objRelatorioDiarioValores.setLayout(null);
				//objRelatorioDiarioValores.setVisible(true);
			}	
		});
		mitemConsultaRelatorioDiarioRegistroVendas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				RelatorioDiarioVendas objRelatorioDiarioRegistroVendas = new RelatorioDiarioVendas();
				
				//objRelatorioDiarioRegistroVendas.setLayout(null);
				//objRelatorioDiarioRegistroVendas.setVisible(true);
			}	
		});
		mitemConsultaRelatorioMensalPromo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				RelatorioMensalDescontos objRelatorioMensalPromo = new RelatorioMensalDescontos();
				
				//objRelatorioMensalPromo.setLayout(null);
				//objRelatorioMensalPromo.setVisible(true);
			}	
		});
		mitemConsultaRelatorioMensalFilmes.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				RelatorioMensalFilmes objRelatorioMensalFilmes = new RelatorioMensalFilmes();
				
				//objRelatorioMensalFilmes.setLayout(null);
				//objRelatorioMensalFilmes.setVisible(true);
			}	
		});
		mitemConsultaRelatorioMensalFuncionario.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				RelatorioMensalFuncionario objRelatorioMensalFuncionario = new RelatorioMensalFuncionario();
				
				//objRelatorioMensalFuncionario.setLayout(null);
				//objRelatorioMensalFuncionario.setVisible(true);
			}	
		});
		mitemConsultaRelatorioMensalSalas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				RelatorioMensalSalas objRelatorioMensalSalas = new RelatorioMensalSalas();
				
				//objRelatorioMensalSalas.setLayout(null);
				//objRelatorioMensalSalas.setVisible(true);
			}	
		});
		mitemConsultaRelatorioMensalSessao.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				RelatorioMensalSessao objRelatorioMensalSessao = new RelatorioMensalSessao();
				
				//objRelatorioMensalSessao.setLayout(null);
				//objRelatorioMensalSessao.setVisible(true);
			}	
		});
		mitemConsultaRelatorioMensalValores.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				RelatorioMensalValores objRelatorioMensalValores = new RelatorioMensalValores();
				
				//objRelatorioMensalValores.setLayout(null);
				//objRelatorioMensalValores.setVisible(true);
			}	
		});
		mitemConsultaRelatorioMensalRegistroVendas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				RelatorioMensalVendas objRelatorioMensalRegistroVendas = new RelatorioMensalVendas();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});	
		mitemAlterarpromo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				AtualizaDescontos objAtualizaDescontos = new AtualizaDescontos();				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemAlterarFilme.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				AtualizaFilmes objAtualizaFilme = new AtualizaFilmes();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemAlterarFuncionario.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				AtualizaFunc objAtualizaFunc = new AtualizaFunc();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemAlterarSalas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				AtualizaSalas objAtualizaSalas = new AtualizaSalas();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemAlterarSessao.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				AtualizaSessao objAtualizaSessao = new AtualizaSessao();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemAlterarValores.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				AtualizaValores objAtualizaValores = new AtualizaValores();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemApagarpromo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				ApagaDescontos objApagaDescontos = new ApagaDescontos();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemApagarFilme.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				ApagaFilme objApagaFilme = new ApagaFilme();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemApagarFuncionario.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				ApagaFunc objApagaFunc = new ApagaFunc();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemApagarSalas.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				ApagaSala objApagaSalas = new ApagaSala();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemApagarSessao.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				ApagaSessao objApagaSessao = new ApagaSessao();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemApagarValores.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				ApagaValores objApagaValores = new ApagaValores();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});
		mitemSobre.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				Sobre sobre = new Sobre();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});	
		mitemVersao.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				Versao versao =  new Versao();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});	
		mitemContato.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				Contato contato = new Contato();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});	
		mitemTema_01.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				temaP = temaC;
				LookAndFeelTema();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});	
		mitemTema_02.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				temaP = temaL;
				LookAndFeelTema();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});	
		mitemTema_03.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				temaP = temaM;
				LookAndFeelTema();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});	
		mitemTema_04.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				temaP = temaN;
				LookAndFeelTema();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});	
		mitemTema_05.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				temaP = temaW;
				LookAndFeelTema();
				
				//objRelatorioMensalRegistroVendas.setLayout(null);
				//objRelatorioMensalRegistroVendas.setVisible(true);
			}	
		});		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == btsair){
			this.dispose();
		}
	}
	public static void main(String[] args) {
		new MenuNU();
	}
}
