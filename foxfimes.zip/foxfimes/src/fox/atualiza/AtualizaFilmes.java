package fox.atualiza;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import fox.bean.Filme;
import fox.dao.FilmeDao;
import fox.exception.CampoObrigatorioException;
import fox.exception.DaoException;


public class AtualizaFilmes extends JFrame implements ActionListener {
	
	private JLabel lbcod_filme;
	private JComboBox cbcodFilme;
	private JLabel lbnomef;
	private JTextField tfnomef;
	private JLabel lbcateg;
	private JComboBox lstcateg1;
	private JLabel lbprodf;
	private JTextField tfprodf;
	private JLabel lbdatal;
	private MaskFormatter maskfdatal;	
	private JFormattedTextField tfdatal;
	private JLabel lbtempoe;
	private MaskFormatter maskftempoe;
	private JFormattedTextField tftempoe;
	private JLabel lbporig;
	private JComboBox lstporig;
	private JLabel lbidioma;
	private JComboBox lstidioma;
	private JLabel lbCetaria;
	private JComboBox lstCetaria;
	private JButton btsalvar;
	private JButton btbuscar;
	private JButton btcancelar;
	private JCheckBox ckdublado;
	private JCheckBox cklegendado;
	private JRadioButton rbforaex;
	private ButtonGroup Botoes;
	private FilmeDao filmedao;
	private Filme filme;
	
	public AtualizaFilmes () {	
		
		/* Cria��o de Objetos */		
		setTitle("Atualiza Filmes");
		lbcod_filme = new JLabel("C�digo Filme");
		cbcodFilme = new JComboBox();
		lbnomef = new JLabel("Nome");
		tfnomef = new JTextField ();
		lbcateg = new JLabel("Categorias");
		String[] categorias1 = {"adicionar categoria ...", "Aventura", "Romance", "A��o", "Terror", "Suspense", "Document�rio", "Com�dia", "Policial", "Esportes", "Games", "Desenhos Animados", "Porn�(Adulto)", "Fic��o"};
		lstcateg1 = new JComboBox(categorias1);
		lbprodf = new JLabel("Produtora");
		tfprodf = new JTextField (5);
		lbdatal = new JLabel("Data de Lan�amento");
		maskfdatal = null;
		try {
			maskfdatal = new MaskFormatter("##/##/####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfdatal = new JFormattedTextField (maskfdatal);
		lbtempoe = new JLabel("Exebi��o at�:");
		maskftempoe = null;
		try {
			maskftempoe = new MaskFormatter("##/##/####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tftempoe = new JFormattedTextField (maskftempoe);
		lbporig = new JLabel("Pa�s de Origem");
		String[] porig = {"adicionar pa�s de origem ...", "Afeganist�o", "�frica do Sul", "Alb�nia", "Alemanha", "Andorra", "Angola", "Ant�gua", "Ar�bia Saudita", "Arg�lia", "Argentina", "Arm�nia", "Austr�lia", "�ustria", "Azerbaidj�o", "Bahamas", "Bangladesh", "Barbados", "Barein", "B�lgica", "Belize", "Benin", "Bielorr�ssia", "Bol�via", "B�snia-Herzeg�vinia", "Botsuana", "Brasil", "Brunei", "Bulg�ria", "Burkina", "Burundi", "But�o", "Cabo Verde", "Camar�es", "Camboja", "Canad�", "Catar", "Cazaquist�o", "Chade", "Chile", "China", "Chipre", "Cingapura", "Col�mbia", "Congo", "Cor�ia do Norte", "Cor�ia do Sul", "Costa do Marfim", "Costa Rica", "Cr�acia", "Cuba", "Dinamarca", "Djibuti", "Dominica", "Egito", "El Salvador", "Emirados �rabes Unidos", "Equador", "Eslov�nia", "Espanha", "Estados Unidos", "Est�nia", "Eti�pia","Eslov�qia", "Eslov�nia", "Fiji", "Filipinas", "Finl�ndia", "Formosa", "Fran�a", "Gab�o", "G�mbia", "Gana", "Ge�rgia", "Gr�-Bretanha", "Granada", "Gr�cia", "Guatemala", "Guiana", "Guin�", "Guin�-Bissau", "Guin�-Equatorial", "Haiti", "Holanda", "Honduras", "Hungria", "I�men", "Ilhas Comores", "Ilhas Marshall", "Ilhas Salom�o", "�ndia", "Indon�sia", "Ir�", "Iraque", "Irlanda", "Isl�ndia", "Israel", "It�lia", "Iugosl�via", "Jamaica", "Jap�o", "Jord�nia", "Kiribati", "Kuweit", "Laos", "Lesoto", "Let�nia", "L�bano", "Liechtenstein", "Litu�nia", "Luxemburgo", "Madagascar", "Mal�sia", "Malavi", "Maldivas", "Mali", "Malta", "Marrocos", "Maur�cio", "Maurit�nia", "M�xico", "Mianm�", "Micron�sia", "Mo�ambique", "Mold�via", "M�naco", "Mong�lia", "Nam�bia", "Nauru", "Nepal", "Nicar�gua", "N�ger", "Nig�ria", "Noruega", "Nova Zel�ndia", "Om�", "Panam�", "Papua Nova Guin�", "Paquist�o", "Paraguai", "Peru", "Pol�nia", "Portugual", "Qu�nia", "Quirgu�zia", "Rep�blica Centro-Africana", "Rep�blica Dominicana", "Rom�nia", "Ruanda", "R�ssia", "Samoa Ocidental", "San Marino", "Santa L�cia", "S�o Crist�v�o e N�vis", "S�o Tom� e Pr�ncipe", "S�o Vicente e Granadinas", "Senegal", "Serra Leoa", "S�rvia e Montenegro", "Seychelles", "S�ria", "S�molia", "Sri Lanka", "Suazil�ndia", "Sud�o", "Su�cia", "Su��a", "Suriname", "Tadjiquist�o", "Tail�ndia", "Tanz�nia", "Tcheco-Eslov�quia","Timor-Leste", "Togo", "Tonga", "Trinidad e Tobago", "Tun�sia", "Turcom�nia", "Turquia", "Tuvalu", "Ucr�nia", "Uganda", "Uruguai", "Uzbequist�o", "Vanuatu", "Vaticano", "Venezuela", "Vietn�", "Zaire", "Z�mbia", "Zimb�bue"};
		lstporig = new JComboBox(porig);
		lbidioma = new JLabel("Idioma");
		String[] idioma = {"adicionar idioma ...", "Alem�o(Alemanha)", "Alem�o(Sui�a)", "�rabe", "Chin�s(Rep�blica Popular da China)", "Chin�s(Mandarin)", "Chin�s(Taiwan)", "Coreano", "Dinamarqu�s","Escoc�s(Esc�cia)", "Espanhol(Espanha)", "Espanhol(Internacional)", "Espanhol(Casteliano)", "Filand�s", "Franc�s(Fran�a)", "Franc�s(Sui�a)", "Grego", "Hebraico", "Holand�s(Pa�ses Baixos)","Holand�s(Sui�a)", "Ingl�s(Canad�)", "Ingl�s(EUA)", "Ingl�s(Inglaterra)", "Ingl�s(Reino Unido)", "Italiano(It�lia)", "Italiano(Sui�a)", "Japon�s", "Noruegu�s","Portugu�s(Portugual)", "Portugu�s(Brasil)",  "Russo", "Sueco(Su�cia)", "Sueco(Sui�a)", "Tailand�s", "Turco"};
		lstidioma = new JComboBox(idioma);
		lbCetaria = new JLabel("Classifica��o Et�ria");
		String[] Cetaria = {"Livre", "10", "12", "14", "16", "18"};
		lstCetaria = new JComboBox(Cetaria);
		btsalvar = new JButton("Salvar");
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		ckdublado = new JCheckBox("Dublado");
		this.ckdublado.addActionListener(this);
		add(this.ckdublado);
		cklegendado = new JCheckBox("Legendado");
		this.cklegendado.addActionListener(this);
		add(this.cklegendado);
		rbforaex = new JRadioButton("Fora de Exibi��o", false);
		Botoes = new ButtonGroup();
		
		cbcodFilme.addActionListener(this);
		
		filmedao = new FilmeDao();
		
		try {
			List<Filme> lista = filmedao.buscarTodos();
		
			for (Filme f : lista) {
				cbcodFilme.addItem(f.getCodFilme()); 
			}
	
		
		/* Coordenadas */
		setBounds(0, 0, 610, 300);
		lbcod_filme.setBounds(20, 10, 85, 25);
		cbcodFilme.setBounds(95, 10, 80, 20);
		lbnomef.setBounds(20, 35, 100, 20);
		tfnomef.setBounds(62, 35, 300, 20);
		lbcateg.setBounds(20, 60, 100, 20);
		lstcateg1.setBounds(85, 60, 150, 20);
		lbprodf.setBounds(20, 85, 100, 20);
		tfprodf.setBounds(80, 85, 300, 20);
		lbdatal.setBounds(20, 110, 150, 20);
		tfdatal.setBounds(142, 110, 70, 20);
		lbtempoe.setBounds(246, 110, 150, 20);
		tftempoe.setBounds(332, 110, 70, 20);
		lbporig.setBounds(20, 135, 100, 20);
		lstporig.setBounds(112, 135, 180, 20);
		lbidioma.setBounds(305, 135, 150, 20);
		lstidioma.setBounds(350, 135, 230, 20);
		lbCetaria.setBounds(20, 160, 150, 20);
		lstCetaria.setBounds(140, 160, 60, 20);
		btsalvar.setBounds(20, 220, 90, 25);
		btbuscar.setBounds(190, 10, 90, 20);
		btcancelar.setBounds(490, 220, 90, 25);
		ckdublado.setBounds(20, 185, 75, 20);
		cklegendado.setBounds(100, 185, 90, 20);
		rbforaex.setBounds(380, 185, 130, 20);	
		
		/* Execu��o da Tela */
		add(lbcod_filme);
		add(cbcodFilme);
		add(lbnomef);
		add(tfnomef);
		add(lbcateg);
		add(lstcateg1);
		add(lbprodf);
		add(tfprodf);
		add(lbdatal);
		add(tfdatal);
		add(lbtempoe);
		add(tftempoe);
		add(lbporig);
		add(lstporig);
		add(lbidioma);
		add(lstidioma);
		add(lbCetaria);
		add(lstCetaria);
		add(btsalvar);
		add(btbuscar);
		add(btcancelar);
		add(ckdublado);
		add(cklegendado);
		add(rbforaex);
		Botoes.add(ckdublado);
		Botoes.add(ckdublado);
				
		setLayout(null);
		setResizable(false);
		setVisible(true);
		
		btsalvar.addActionListener(this);
		btbuscar.addActionListener(this);
		btcancelar.addActionListener(this);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodFilme.getSelectedItem());
				int codFilme = Integer.parseInt(item);
				filme = filmedao.buscarPorId(codFilme);	
				
				tfnomef.setText(filme.getNomeFilme());
				tfprodf.setText(filme.getProdutoraFilme());
				JOptionPane.showMessageDialog(null, "Filme Consultado com Sucesso!");
				
				}
			else if (event.getSource() == this.btsalvar) {
					if ("".equals(tfnomef.getText().trim())) {
						throw new CampoObrigatorioException("Nome Filme");
					}
		
					if ("".equals(tfprodf.getText().trim())) {
						throw new CampoObrigatorioException("Nome Produtora");
					}
					
					String dub = null;
					if (ckdublado.isSelected()) {
						dub = "SIM";
					}else {
						dub = "N�O";
					}
					String len = null;
					if (cklegendado.isSelected()) {
						len = "SIM";
					}else {
						len = "N�O";
					}
					String fora = null;
					if (rbforaex.isSelected()) {
						fora = "SIM";
					} else {
						fora = "N�O";
					}
					
					filmedao = new FilmeDao();
					filme = new Filme();
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					filme.setCodFilme(Integer.parseInt(cbcodFilme.getSelectedItem().toString()));
					filme.setNomeFilme(tfnomef.getText());
					filme.setCategoriaFilme(this.lstcateg1.getSelectedItem().toString());
					filme.setProdutoraFilme(tfprodf.getText());
					try {
						filme.setDataLancamento(sdf.parse(tfdatal.getText()));
					} catch (ParseException  e) {
						e.printStackTrace();
					}
					try {
						filme.setExibicaoAte(sdf.parse(tftempoe.getText()));
					} catch (ParseException e) {
						e.printStackTrace();
					}
					filme.setPaisOrigem(this.lstporig.getSelectedItem().toString());
					filme.setIdiomaFilme(this.lstidioma.getSelectedItem().toString());
					filme.setClassificacaoEtaria(this.lstCetaria.getSelectedItem().toString());
					filme.setDublado(dub);
					filme.setLegendado(len);
					filme.setForaExibicao(fora);
					
					filmedao.salvar(filme);
				
					JOptionPane.showMessageDialog(this, "Filme Atualizado com sucesso!");
					
					setValoresIniciais();
					
				}  else if (btcancelar == event.getSource()) {
					this.dispose();
				}
			} catch (CampoObrigatorioException e) {
				JOptionPane.showMessageDialog(this, e.getMessage(), "Erro de digita��o", JOptionPane.ERROR_MESSAGE);
			}catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	private void setValoresIniciais() {
		tfnomef.setText("");
		tfprodf.setText("");		
	}
}