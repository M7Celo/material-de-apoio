package fox.exception;

public class DaoException extends Exception {

	public DaoException() {
	}

	public DaoException(String message) {
		super(message);
	}

	public DaoException(Throwable throwed) {
		super(throwed);
	}

	public DaoException(String message, Throwable throwed) {
		super(message, throwed);
	}

}
