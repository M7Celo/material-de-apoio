package fox.exception;

public class NumException extends Exception {
	
	public NumException() {
	}

	public NumException(String message) {
		super(message);
	}

	public NumException(Throwable throwed) {
		super(throwed);
	}

	public NumException(String message, Throwable throwed) {
		super(message, throwed);
	}

}
