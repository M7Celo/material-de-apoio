package fox.sobre;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Versao extends JFrame {
	private JPanel painel;
	private JLabel sobre1;
	private JLabel sobre2;
	
	
	public Versao(){
		
		sobre1 = new JLabel("Vers�o 25/11/2011");
		sobre2 = new JLabel("Entrega Final do TCC");
		setTitle("Vers�o");
		setBounds(0,0,640,155);
		sobre1.setBounds(20, 40, 800, 20);
		sobre2.setBounds(20, 60, 800, 20);
		
		add(painel);
		painel.add(sobre1);
		painel.add(sobre2);
		
		setLayout(null);
		setResizable(false);
		setVisible(true);
		
	}

}
