package fox.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fox.bean.Descontos;

public class DescontosDao extends DaoBase<Descontos> {

	private static final String SEQUENCE = "CAD_DESCONTOS_SEQ";
	
	private static final String BUSCAR_POR_ID = "SELECT COD_DESCONTOS, " +
			"NOME_CONVENIO, " +
			"VALOR_CONVENIO, " +
			"NOME_PROMOCAO, " +
			"VALOR_PROMOCAO, " +
			"NOME_SINDICATO, " +
			"VALOR_SINDICATO, " +
			"DESCONTOS_FIXO " +
			"FROM CAD_DESCONTOS " +
			"WHERE COD_DESCONTOS = ? ";
	
	private static final String BUSCAR_TODOS = "SELECT COD_DESCONTOS, " +
			"NOME_CONVENIO, " +
			"VALOR_CONVENIO, " +
			"NOME_PROMOCAO, " +
			"VALOR_PROMOCAO, " +
			"NOME_SINDICATO, " +
			"VALOR_SINDICATO, " +
			"DESCONTOS_FIXO " +
			"FROM CAD_DESCONTOS ";
	
	private static final String SALVAR = "UPDATE CAD_DESCONTOS SET  " +
			"NOME_CONVENIO = ?, " +
			"VALOR_CONVENIO = ?, " +
			"NOME_PROMOCAO = ?, " +
			"VALOR_PROMOCAO = ?, " +
			"NOME_SINDICATO = ?, " +
			"VALOR_SINDICATO = ?, " +
			"DESCONTOS_FIXO = ? " +
			"WHERE COD_DESCONTOS = ? ";
	
	private static final String APAGAR = "DELETE FROM CAD_DESCONTOS WHERE COD_DESCONTOS = ? ";
	
	private static final String CRIAR = "insert into CAD_DESCONTOS(" +
			"COD_DESCONTOS, " +
			"NOME_CONVENIO , " +
			"VALOR_CONVENIO, " +
			"NOME_PROMOCAO, " +
			"VALOR_PROMOCAO, " +
			"NOME_SINDICATO, " +
			"VALOR_SINDICATO, " +
			"DESCONTOS_FIXO) " +
			"values( ?, ?, ?, ?, ?, ?, ?, ?)";
	
	public DescontosDao() {
		
		super(
//				NOME SEQUENCE
				SEQUENCE, 
				
//				SELECT POR ID'S(BUSCAR POR ID'S)
				BUSCAR_POR_ID, 

//				BUSCAR TODOS
				BUSCAR_TODOS,
				
//				SALVAR
				SALVAR,
				
//				APAGAR
				APAGAR, 
				
//				CRIAR
				CRIAR);
	}

	@Override
	protected Descontos getBean(ResultSet result) throws SQLException {
		Descontos bean = new Descontos();
		
		bean.setCodDescontos(result.getInt("COD_DESCONTOS"));
		bean.setNomeConvenio(result.getString("NOME_CONVENIO"));
		bean.setValorConvenio(result.getString("VALOR_CONVENIO"));
		bean.setNomePromo(result.getString("NOME_PROMOCAO"));
		bean.setValorPromo(result.getString("VALOR_PROMOCAO"));
		bean.setNomeSind(result.getString("NOME_SINDICATO"));
		bean.setValorSind(result.getString("VALOR_SINDICATO"));
		bean.setDescontosFixo(result.getString("DESCONTOS_FIXO"));		
		return bean;
	}

	@Override
	protected void setParametrosUpdate(
			PreparedStatement statement,
			Descontos bean) throws SQLException {
		
		statement.setString(1, bean.getNomeConvenio());
		statement.setString(2, bean.getValorConvenio());
		statement.setString(3, bean.getNomePromo());
		statement.setString(4, bean.getValorPromo());
		statement.setString(5, bean.getNomeSind());
		statement.setString(6, bean.getValorSind());
		statement.setString(7, bean.getDescontosFixo());
		statement.setInt(8, bean.getCodDescontos());
		
	}

	@Override
	protected void setParametrosInsert(
			PreparedStatement statement,
			Descontos bean,
			int novoId) throws SQLException {
		
		statement.setInt(1, bean.getCodDescontos());
		statement.setString(2, bean.getNomeConvenio());
		statement.setString(3, bean.getValorConvenio());
		statement.setString(4, bean.getNomePromo());
		statement.setString(5, bean.getValorPromo());
		statement.setString(6, bean.getNomeSind());
		statement.setString(7, bean.getValorSind());
		statement.setString(8, bean.getDescontosFixo());
		
	}

}
