package fox.re.mensal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;


public class RelatorioMensalFuncionario extends JFrame implements ActionListener {
	
	private JLabel lbnomefunc;
	private JTextField tfnomefunc;
	private JLabel lbdatainicial;
	private MaskFormatter maskfdatainicial;
	private JFormattedTextField tfdatainicial;
	private JLabel lbdatafinal;
	private MaskFormatter maskfdatafinal;
	private JFormattedTextField tfdatafinal;
	private JComboBox lstcodfunc;
	private JLabel lbcodfunc;
	private JButton btbuscar;
	private JButton btcancelar;
	private JScrollPane scrolTabela;
	private JTable tabela;

	public RelatorioMensalFuncionario (){
	
		//Cria��o de Objetos
		setTitle("Relat�rio Mensal de Funcionario");
		lbnomefunc = new JLabel("Nome");
		tfnomefunc = new JTextField();
		lbdatainicial = new JLabel("Data Inical");
		maskfdatainicial = null;
		try {
			maskfdatainicial = new MaskFormatter("  ##/##/####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfdatainicial = new JFormattedTextField (maskfdatainicial);
		lbdatafinal = new JLabel("Data Final");
		maskfdatafinal = null;
		try {
			maskfdatafinal = new MaskFormatter("  ##/##/####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfdatafinal = new JFormattedTextField (maskfdatafinal);
		String[] codfunc = {};
		lstcodfunc = new JComboBox(codfunc);
		lbcodfunc = new JLabel("C�digo Funcion�rio");
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		tabela = new JTable();

		Object[][] conteudoTabela = 
			new Object[][] {
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null},
				{ null, null, null, null, null, null}, 
				{ null, null, null, null, null, null} 
				};
		
		
		String[] titulos = new String[] { "C�digo Funcion�rio", "Nome Funcion�rio", "N�vel de Acesso", "Atividade", "Hora", "Data"};
		tabela.setModel(
				new DefaultTableModel(
						conteudoTabela,
						titulos)
				);
		
		tabela.setName("Relat�rio Mensal de Funcionario");
		scrolTabela = new JScrollPane(tabela);
		
		//Coordenadas
		setBounds(0,0,800,600);
		lbnomefunc.setBounds(20,50,85,20);
		tfnomefunc.setBounds(55,50,200,20);
		lbdatainicial.setBounds(20,70,85,20);
		tfdatainicial.setBounds(85,70,80,20);
		lbdatafinal.setBounds(180,70,85,20);
		tfdatafinal.setBounds(240,70,80,20);
		lbcodfunc.setBounds(260,50,120,20);
		lstcodfunc.setBounds(370,50,100,20);
		btbuscar.setBounds(495,50,85,25);
		scrolTabela.setBounds(20,90,750,450);
		btcancelar.setBounds(1175,50,85,25);
		
		//Execu��o na Tela
		add(lbnomefunc);
		add(tfnomefunc);
		add(lbdatainicial);
		add(tfdatainicial);
		add(lbdatafinal);
		add(tfdatafinal);
		add(lbcodfunc);
		add(lstcodfunc);
		add(btbuscar);
		add(btcancelar);
		add(scrolTabela);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
	}

}
