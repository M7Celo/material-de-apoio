package fox.re.diario;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;


public class RelatorioDiarioVendas {

	/**
	 * @param args
	 */
	public RelatorioDiarioVendas (){
	
		
		//Cria��o de Objetos
		JFrame frmTela = new JFrame("Relat�rio Di�rio de Vendas");
		JLabel lbnuming = new JLabel("N�mero Ingressos");
		JTextField tfnuming = new JTextField();
		JLabel lbhorainicial = new JLabel("Hora Inical");
		MaskFormatter maskfhorainicial = null;
		try {
			maskfhorainicial = new MaskFormatter("  ##hs##min");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JFormattedTextField tfhorainicial = new JFormattedTextField (maskfhorainicial);
		JLabel lbhorafinal = new JLabel("Hora Final");
		MaskFormatter maskfhorafinal = null;
		try {
			maskfhorafinal = new MaskFormatter("  ##hs##min");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JFormattedTextField tfhorafinal = new JFormattedTextField (maskfhorafinal);
		String[] coding = {};
		JComboBox lstcoding = new JComboBox(coding);
		JLabel lbcoding = new JLabel("C�digo Ingressos");
		//JList tfexibi�ao = new JList();
		JTextField pnexibi�ao = new JTextField();
		JButton btbuscar = new JButton("Buscar");
		JButton btcancelar = new JButton("Cancelar");
		
		//Coordenadas
		frmTela.setBounds(0,0,1024,600);
		lbnuming.setBounds(20,50,120,20);
		tfnuming.setBounds(130,50,200,20);
		lbhorainicial.setBounds(20,70,85,20);
		tfhorainicial.setBounds(85,70,80,20);
		lbhorafinal.setBounds(180,70,85,20);
		tfhorafinal.setBounds(240,70,80,20);
		lbcoding.setBounds(340,50,120,20);
		lstcoding.setBounds(440,50,100,20);
		pnexibi�ao.setBounds(20,90,974,424);
		btbuscar.setBounds(20,525,85,25);
		btcancelar.setBounds(910,525,85,25);
		
		//Execu��o na Tela
		frmTela.add(lbnuming);
		frmTela.add(tfnuming);
		frmTela.add(lbhorainicial);
		frmTela.add(tfhorainicial);
		frmTela.add(lbhorafinal);
		frmTela.add(tfhorafinal);
		frmTela.add(lbcoding);
		frmTela.add(lstcoding);
		frmTela.add(pnexibi�ao);
		frmTela.add(btbuscar);
		frmTela.add(btcancelar);
		
		frmTela.setLayout(null);
		frmTela.setVisible(true);

	}

}
