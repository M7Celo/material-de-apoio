package fox.re.mensal;
import java.awt.HeadlessException;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;


public class RelatorioMensalFilmes extends JFrame {
	
	//Cria��o de Objetos
	JLabel lbnomef;
	JTextField tfnomefilme;
	JLabel lbdatainicial;
	MaskFormatter maskfdatainicial;
	JFormattedTextField tfdatainicial;
	JLabel lbdatafinal;
	MaskFormatter maskfdatafinal;
	JFormattedTextField tfdatafinal;
	JComboBox lstcodfilme;
	JLabel lbcodfilme;
	JButton btbuscar;
	JButton btcancelar;	
	private JScrollPane scrolTabela;
	private JTable tabela;
	
	public RelatorioMensalFilmes ()throws HeadlessException{
		
		//Cria��o de Objetos
		setTitle("Relat�rio Mensal de Filmes");
		lbnomef = new JLabel("Nome");
		tfnomefilme = new JTextField();
		lbdatainicial = new JLabel("Data Inical");
		maskfdatainicial = null;
		try {
			maskfdatainicial = new MaskFormatter("  ##/##/####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfdatainicial = new JFormattedTextField (maskfdatainicial);
		lbdatafinal = new JLabel("Data Final");
		maskfdatafinal = null;
		try {
			maskfdatafinal = new MaskFormatter("  ##/##/####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfdatafinal = new JFormattedTextField (maskfdatafinal);
		String[] codfilme = {};
		lstcodfilme = new JComboBox(codfilme);
		lbcodfilme = new JLabel("C�digo Filme");
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		tabela = new JTable();
		
		Object[][] conteudoTabela = 
			new Object[][] {
				  {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
				};
		
		
		String[] titulos = new String[] { "C�digo Filme", "Nome Filme", "Categoria Filme", "Produtora Filme", "Data Lan�amento", "Exibi��o At�", "Pa�s de Origem", "Idioma Filme", "Classifica��o Et�ria", "Dublado", "Legendado", "Fora de Exibi��o","C�digo Funcion�rio", "Nome Funcion�rio","Hora", "Data"};
		tabela.setModel(
				new DefaultTableModel(
						conteudoTabela,
						titulos)
				);
		
		tabela.setName("Relat�rio Di�rio de Descontos");
		scrolTabela = new JScrollPane(tabela);
		
		//Coordenadas
		setBounds(0,0,800,600);
		lbnomef.setBounds(20,50,85,20);
		tfnomefilme.setBounds(55,50,200,20);
		lbdatainicial.setBounds(20,70,85,20);
		tfdatainicial.setBounds(85,70,80,20);
		lbdatafinal.setBounds(180,70,85,20);
		tfdatafinal.setBounds(240,70,80,20);
		lbcodfilme.setBounds(260,50,85,20);
		lstcodfilme.setBounds(335,50,100,20);
		scrolTabela.setBounds(20,90,750,450);
		btbuscar.setBounds(445,50,85,25);
		btcancelar.setBounds(1175,50,85,25);
		
		//Execu��o na Tela
		add(lbnomef);
		add(tfnomefilme);
		add(lbdatainicial);
		add(tfdatainicial);
		add(lbdatafinal);
		add(tfdatafinal);
		add(lbcodfilme);
		add(lstcodfilme);
		add(scrolTabela);
		add(btbuscar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);

	}

}
