package fox.re.diario;

import java.awt.FlowLayout;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class TelaGrid extends JFrame {

	public TelaGrid() throws HeadlessException {
		JTable tabela = new JTable();

		Object[][] conteudoTabela = 
			new Object[][] {
				{ null, null, null, null }, 
				{ null, null, null, null },
				{ null, null, null, null }, 
				{ null, null, null, null } 
				};
		
		
		String[] titulos = new String[] { "Title 1", "Title 2", "Title 3", "Title 4" };
		tabela.setModel(
				new DefaultTableModel(
						conteudoTabela,
						titulos)
				);
		
		tabela.setName("jTable1");
		JScrollPane scrolTabela = new JScrollPane(tabela);

		setLayout(new FlowLayout());
		
		add(scrolTabela);
		
		setBounds(0,0,640,480);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	
}
