package fox.atualiza;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Descontos;
import fox.dao.DescontosDao;
import fox.exception.CampoObrigatorioException;
import fox.exception.DaoException;
public class AtualizaDescontos extends JFrame implements ActionListener {
	
	private JLabel lbcod_promo;
	private JComboBox cbcodDesc;
	private JLabel lbconv;
	private JTextField tfconv;
	private JLabel lbsind;
	private JTextField tfsind;
	private JLabel lbpromo;
	private JTextField tfpromo;
	private JLabel lbvaldescconv;
	private JComboBox cbvaldescconv;
	private JLabel lbvaldescsind;
	private JComboBox cbvaldescsind;
	private JLabel lbvaldescpromo;
	private JComboBox cbvaldescpromo;
	private JLabel lbdescfixo;
	private JComboBox cbdescfixo;
	private JButton btsalvar;
	private JButton btbuscar;
	private JButton btcancelar;
	private DescontosDao descontosDao;
	private Descontos descontos;
	
	public AtualizaDescontos (){
		
		/* Cria��o de Objetos */
		setTitle("Atualiza Descontos");
		lbcod_promo = new JLabel("C�digo Descontos");
		cbcodDesc = new JComboBox();
		lbconv = new JLabel("Conv�nios");
		tfconv = new JTextField ();
		lbsind = new JLabel("Sindicatos");
		tfsind = new JTextField (5);
		lbpromo = new JLabel("Promocional");
		tfpromo = new JTextField (5);
		lbvaldescconv = new JLabel("Valor de Descontos");
		String[] conv = {"5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%", "50%"};
		cbvaldescconv = new JComboBox(conv);
		lbvaldescsind = new JLabel("Valor de Descontos");
		String[] sind = {"5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%", "50%"};
		cbvaldescsind = new JComboBox(sind);
		lbvaldescpromo = new JLabel("Valor de Descontos");
		String[] promo = {"5%", "10%", "15%", "20%", "25%", "30%", "35%", "40%", "45%", "50%"};
		cbvaldescpromo = new JComboBox(promo);
		lbdescfixo = new JLabel("Descontos Fixo");
		String[] descfixo = {"10%", "20%", "30%", "40%", "50%(Estudante)", "100%(Vip)"};
		cbdescfixo = new JComboBox(descfixo);
		btsalvar = new JButton("Salvar");
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		
		btsalvar.addActionListener(this);
		btbuscar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodDesc.addActionListener(this);
		
		descontosDao = new DescontosDao();
		
		try {
			List<Descontos> lista = descontosDao.buscarTodos();
		
			for (Descontos d : lista) {
				cbcodDesc.addItem(d.getCodDescontos()); 
			}
	
		/* Coordenadas */
		setBounds(0, 0, 400, 290);
		lbcod_promo.setBounds(20, 10, 150, 20);
		cbcodDesc.setBounds(130, 10, 80, 20);
		lbconv.setBounds(20, 35, 100, 25);
		tfconv.setBounds(85, 35, 300, 20);
		lbvaldescconv.setBounds(20, 60, 150, 25);
		cbvaldescconv.setBounds(135, 60, 50, 20);
		lbsind.setBounds(20, 85, 100, 25);
		tfsind.setBounds(85, 85, 300, 20);
		lbvaldescsind.setBounds(20, 110, 150, 25);
		cbvaldescsind.setBounds(135, 110, 50, 20);
		lbpromo.setBounds(20, 135, 100, 25);
		tfpromo.setBounds(95, 135, 290, 20);
		lbvaldescpromo.setBounds(20, 160, 150, 25);
		cbvaldescpromo.setBounds(135, 160, 50, 20);
		lbdescfixo.setBounds(20, 185, 150, 25);
		cbdescfixo.setBounds(115, 185, 120, 20);
		btsalvar.setBounds(20,  220, 90, 25);
		btbuscar.setBounds(220, 10, 90, 20);
		btcancelar.setBounds(280,  220, 90, 25);
		
		/* Execu��o da Tela */
		add(lbcod_promo);
		add(cbcodDesc);
		add(lbconv);
		add(tfconv);
		add(lbvaldescconv);
		add(cbvaldescconv);
		add(lbsind);
		add(tfsind);
		add(lbvaldescsind);
		add(cbvaldescsind);
		add(lbpromo);
		add(tfpromo);
		add(lbvaldescpromo);
		add(cbvaldescpromo);
		add(lbdescfixo);
		add(cbdescfixo);
		add(btsalvar);
		add(btbuscar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados!");
			this.dispose();
			e.printStackTrace();
		}

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodDesc.getSelectedItem());
				int codDesconto = Integer.parseInt(item);
				descontos = descontosDao.buscarPorId(codDesconto);	
				
				tfconv.setText(descontos.getNomeConvenio());
				tfsind.setText(descontos.getNomeSind());
				tfpromo.setText(descontos.getNomePromo());
					JOptionPane.showMessageDialog(null, "Descontos consultado com Sucesso!");
					
				}
			else if (event.getSource() == this.btsalvar) {
					try{
					if ("".equals(tfconv.getText().trim())) {
						throw new CampoObrigatorioException("Nome Conv�nio");
					}
		
					else if ("".equals(tfsind.getText().trim())) {
						throw new CampoObrigatorioException("Nome Sindicato");
					}
					
					else if("".equals(tfpromo.getText().trim())) {
						throw new CampoObrigatorioException("Nome Promo��o");
					}
					
					descontosDao = new DescontosDao();
					descontos = new Descontos();
					descontos.setCodDescontos(Integer.parseInt(cbcodDesc.getSelectedItem().toString()));
					descontos.setNomeConvenio(tfconv.getText());
					descontos.setValorConvenio(cbvaldescconv.getSelectedItem().toString());
					descontos.setNomeSind(tfsind.getText());
					descontos.setValorSind(this.cbvaldescsind.getSelectedItem().toString());
					descontos.setNomePromo(tfpromo.getText());
					descontos.setValorPromo(this.cbvaldescpromo.getSelectedItem().toString());
					descontos.setDescontosFixo(this.cbdescfixo.getSelectedItem().toString());
					descontosDao.salvar(descontos);
				
					JOptionPane.showMessageDialog(this, "Descontos atualizado com sucesso");
					
					setValoresIniciais();
			} catch (CampoObrigatorioException e) {
				JOptionPane.showMessageDialog(this, e.getMessage(), "Erro de digita��o", JOptionPane.ERROR_MESSAGE);
			}
			}
			else if (btcancelar == event.getSource()) {
				this.dispose();
			} 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
	private void setValoresIniciais() {
		tfconv.setText("");
		tfsind.setText("");
		tfpromo.setText("");
	}
}