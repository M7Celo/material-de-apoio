package fox.atualiza;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import fox.bean.Descontos;
import fox.bean.Valor;
import fox.dao.DescontosDao;
import fox.dao.ValorDao;
import fox.exception.DaoException;

public class AtualizaValores extends JFrame implements ActionListener {
	
	private JLabel lbcod_valor;
	private JComboBox cbcodValor;
	private JLabel lbnomef;
	private JTextField tfnomef;
	private JButton btsalvar;
	private JButton btbuscar;
	private JButton btcancelar;
	private JLabel lbvalorPre�o;
	private MaskFormatter maskfvalorfilme;
	private JFormattedTextField tfvalorPreco;
	private ValorDao valordao;
	private Valor valor;
	
	public AtualizaValores () {
	
			/* Cria��o de Objetos */
			setTitle("Atualiza Valores");
			lbcod_valor = new JLabel("C�digo Valor");
			cbcodValor = new JComboBox();
			lbnomef = new JLabel("Nome do Filme");
			tfnomef = new JTextField (5);
			btbuscar = new JButton("Buscar");
			btsalvar = new JButton("Salvar");
			btcancelar = new JButton("Cancelar");
			lbvalorPre�o = new JLabel("Valor R$:");
			maskfvalorfilme = null;
			try {
				maskfvalorfilme = new MaskFormatter("##,##");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			tfvalorPreco = new JFormattedTextField (maskfvalorfilme);
			
			btsalvar.addActionListener(this);
			btbuscar.addActionListener(this);
			btcancelar.addActionListener(this);
			cbcodValor.addActionListener(this);
			
			valordao = new ValorDao();
			valor = new Valor();
			
			try {
				List<Valor> lista = valordao.buscarTodos();
			
				for (Valor v : lista) {
					cbcodValor.addItem(v.getCodValor()); 
				}
			
			/* Coordenadas */
			setBounds(0, 0, 430, 170);
			lbvalorPre�o.setBounds(20, 35, 100, 20);
			tfvalorPreco.setBounds(85, 35, 50, 20);
			lbcod_valor.setBounds(20, 10, 150, 20);
			cbcodValor.setBounds(95, 10, 70, 20);
			lbnomef.setBounds(20, 60, 100, 20);
			tfnomef.setBounds(110, 60, 300, 20);
			btsalvar.setBounds(20,  100, 90, 25);
			btbuscar.setBounds(180, 10, 90, 20);
			btcancelar.setBounds(300,  100, 90, 25);
			
			/* Execu��o na Tela */
			add(lbvalorPre�o);
			add(tfvalorPreco);
			add(lbcod_valor);
			add(cbcodValor);
			add(lbnomef);
			add(tfnomef);
			add(btsalvar);
			add(btbuscar);
			add(btcancelar);
	
			setLayout(null);
			setVisible(true);
			setResizable(false);
			
			} catch (DaoException e) {
				JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados!");
				this.dispose();
				e.printStackTrace();
			}
				
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodValor.getSelectedItem());
				int codValor = Integer.parseInt(item);
				valor = valordao.buscarPorId(codValor);	
				
				tfnomef.setText(valor.getNomeFilme());
				tfvalorPreco.setText(String.valueOf(valor.getValorFilme()));
					JOptionPane.showMessageDialog(null, "Valor do Filme Consultado com Sucesso!");
				}
			if(event.getSource() == this.btsalvar){
				valordao = new ValorDao();
				valor = new Valor();
				valor.setCodValor(Integer.parseInt(cbcodValor.getSelectedItem().toString()));
				valor.setNomeFilme(tfnomef.getText());
				valor.setValorFilme(tfvalorPreco.getText());
				
				valordao.salvar(valor);
				
				JOptionPane.showMessageDialog(this, "Valor do Filme Atualizado com Sucesso!");
				tfnomef.setText("");
				tfvalorPreco.setText("");
				
			}if (btcancelar == event.getSource()) {
				this.dispose();
			}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
}
