package fox.atualiza;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Funcionario;
import fox.bean.Sessao;
import fox.dao.FuncionarioDao;
import fox.dao.SessaoDao;
import fox.exception.DaoException;


public class AtualizaSessao extends JFrame implements ActionListener {
	
	private JLabel lbcod_sessao;
	private JComboBox cbcodSessao;
	private JLabel lbcod_sala;
	private JTextField tfcod_sala;
	private JLabel lbcod_filme;
	private JTextField tfcod_filme;
	private JButton btsalvar;
	private JButton btbuscar;
	private JButton btcancelar;
	private JLabel lbnomesessao;
	private JTextField tfnomesessao;
	private JLabel lbhorsessao;
	private JLabel lbhorsessaoinicial;
	private JTextField tfhorsessaoinicial;
	private JLabel lbhorsessaofinal;
	private JTextField tfhorsessaofinal;
	private JLabel lbnomef;
	private JTextField tfnomef;
	private JLabel lbnumsala;
	private JTextField tfnumsala;
	private SessaoDao sessaodao;
	private Sessao sessao;
	
	public AtualizaSessao () {
		
			/* Cria��o de Objetos */
			setTitle("Atualiza Sess�o");
			lbcod_sessao = new JLabel("Cod_Sess�o");
			cbcodSessao = new JComboBox();
			lbcod_sala = new JLabel("Cod_sala");
			tfcod_sala = new JTextField ();
			lbcod_filme = new JLabel("Cod_Filme");
			tfcod_filme = new JTextField ();
			btsalvar = new JButton("Salvar");
			btbuscar = new JButton("Buscar");
			btcancelar = new JButton("Cancelar");
			lbnomesessao = new JLabel("Nome Sess�o");
			tfnomesessao = new JTextField ();
			lbhorsessao = new JLabel("Hor�rio Sess�o");
			lbhorsessaoinicial = new JLabel("In�cio");
			tfhorsessaoinicial = new JTextField ();
			lbhorsessaofinal = new JLabel("T�rmino");
			tfhorsessaofinal = new JTextField ();
			tfnumsala = new JTextField();
			lbnumsala = new JLabel("Num Sala");
			tfnomef = new JTextField();
			lbnomef = new JLabel("Nome Filme");
			
			/* Coordenadas */
			setBounds(0, 0, 480, 220);
			lbcod_sessao.setBounds(20, 10, 75, 25);
			cbcodSessao.setBounds(95, 10, 80, 20);
			btbuscar.setBounds(200, 10, 90, 20);
			lbnomesessao.setBounds(20, 35, 130, 20);
			tfnomesessao.setBounds(105, 35, 200, 20);
			lbhorsessao.setBounds(20, 60, 100, 20);
			lbhorsessaoinicial.setBounds(160, 60, 100, 20);
			tfhorsessaoinicial.setBounds(195, 60, 70, 20);
			lbhorsessaofinal.setBounds(300, 60, 100, 20);
			tfhorsessaofinal.setBounds(350, 60, 70, 20);
			lbcod_sala.setBounds(20, 85, 150, 20);
			tfcod_sala.setBounds(82, 85, 70, 20);
			lbcod_filme.setBounds(165, 85, 150, 20);
			tfcod_filme.setBounds(230, 85, 70, 20);
			lbnumsala.setBounds(20, 115, 60, 20);
			tfnumsala.setBounds(80, 115, 50, 20);
			lbnomef.setBounds(150, 115, 70, 20);
			tfnomef.setBounds(220, 115, 245, 20);
			btsalvar.setBounds(20,  150, 90, 25);
			btcancelar.setBounds(320,  150, 90, 25);
			
			btbuscar.addActionListener(this);
			btcancelar.addActionListener(this);
			btsalvar.addActionListener(this);
			cbcodSessao.addActionListener(this);
			
			sessaodao = new SessaoDao();
			sessao = new Sessao();
			
			try {
				List<Sessao> lista = sessaodao.buscarTodos();
			
				for (Sessao sessao : lista) {
					cbcodSessao.addItem(sessao.getCodigoSessao()); 
				}
			
			/* Execu��o na Tela */
			add(lbcod_sessao);
			add(lbnomef);
			add(lbnumsala);
			add(cbcodSessao);
			add(lbnomesessao);
			add(tfnomesessao);
			add(lbhorsessao);
			add(lbhorsessaoinicial);
			add(tfhorsessaoinicial);
			add(lbhorsessaofinal);
			add(tfhorsessaofinal);
			add(lbcod_sala);
			add(tfcod_sala);
			add(lbcod_filme);
			add(tfcod_filme);
			add(tfnumsala);
			add(tfnomef);
			add(btsalvar);
			add(btbuscar);
			add(btcancelar);
			
			setLayout(null);
			setVisible(true);
			setResizable(false);
			
			} catch (DaoException e) {
				JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
				this.dispose();
				e.printStackTrace();
			}
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodSessao.getSelectedItem());
				int codSessao = Integer.parseInt(item);
				sessao = sessaodao.buscarPorId(codSessao);	
				
				tfnomesessao.setText(sessao.getNomeSessao());
				tfhorsessaoinicial.setText(sessao.getHorarioInicial());
				tfhorsessaofinal.setText(sessao.getHorarioFinal());
				tfcod_sala.setText(String.valueOf(sessao.getCodigoSala()));
				tfnumsala.setText(String.valueOf(sessao.getNumSala()));
				tfcod_filme.setText(String.valueOf(sessao.getCodigoFilme()));
				tfnomef.setText(sessao.getNomeFilme());
					JOptionPane.showMessageDialog(null, "Sess�o Consultada com Sucesso!");
				}
			if(event.getSource() == this.btsalvar){
				sessaodao = new SessaoDao();
				sessao = new Sessao();
				sessao.setCodigoSessao(Integer.parseInt(cbcodSessao.getSelectedItem().toString()));
				sessao.setNomeSessao(tfnomesessao.getText());
				sessao.setHorarioInicial(tfhorsessaoinicial.getText());
				sessao.setHorarioFinal(tfhorsessaoinicial.getText());
				sessao.setCodigoSala(Integer.parseInt(tfnumsala.getText()));
				sessao.setNumSala(Integer.parseInt(tfnumsala.getText()));
				sessao.setNomeFilme(tfnomef.getText());
				sessao.setNomeFilme(tfnomef.getText());
				
				sessaodao.salvar(sessao);
				
				JOptionPane.showMessageDialog(this, "Sess�o Atualizada com sucesso!");
				
				setValoresIniciais();
			}
			else if (btcancelar == event.getSource()) {
				this.dispose();
			}
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
	private void setValoresIniciais() {
		tfnomesessao.setText("");
		tfhorsessaoinicial.setText("");
		tfhorsessaofinal.setText("");
		tfcod_sala.setText("");
		tfnumsala.setText("");
		tfcod_filme.setText("");
		tfnomef.setText("");
	}
}
