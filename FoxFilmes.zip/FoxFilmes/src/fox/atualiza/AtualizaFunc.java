package fox.atualiza;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import fox.bean.Funcionario;
import fox.dao.FuncionarioDao;
import fox.exception.CampoObrigatorioException;
import fox.exception.DaoException;

public class AtualizaFunc extends JFrame implements ActionListener {
	
	private JLabel lbcod_func;
	private JComboBox cbcodFunc;
	private JLabel lbnomefunc;
	private JTextField tfnomefunc;
	private JLabel lbsenha_func;
	private JPasswordField pfsenha_func;
	private JLabel lbniv_acesso;
	private JRadioButton rbnivel1;
	private JRadioButton rbnivel2;
	private JRadioButton rbnivel3;
	private JRadioButton rbnivel4;
	private JRadioButton rbnivel5;
	private ButtonGroup nivelAcesso;
	private JButton btsalvar;
	private JButton btbuscar;
	private JButton btcancelar;
	private FuncionarioDao funcionariodao;
	private Funcionario funcionario;
	
	public AtualizaFunc () {
		
		/* Cria��o de Objetos */
		setTitle("Atualiza Funcion�rio");
		lbcod_func = new JLabel("C�digo Funcion�rio");
		cbcodFunc = new JComboBox();
		lbnomefunc = new JLabel("Nome Funcion�rio");
		tfnomefunc = new JTextField();
		lbsenha_func = new JLabel("Senha Funcion�rio");
		pfsenha_func = new JPasswordField();
		lbniv_acesso = new JLabel("N�vel de Acesso Funcion�rio");
		nivelAcesso = new ButtonGroup();
		rbnivel1 = new JRadioButton("N�vel 1", true);
		rbnivel2 = new JRadioButton("N�vel 2", false);
		rbnivel3 = new JRadioButton("N�vel 3", false);
		rbnivel4 = new JRadioButton("N�vel 4", false);
		rbnivel5 = new JRadioButton("N�vel 5", false);
		this.rbnivel1.addActionListener(this);
		add(this.rbnivel1);
		this.rbnivel2.addActionListener(this);
		add(this.rbnivel2);
		this.rbnivel3.addActionListener(this);
		add(this.rbnivel3);
		this.rbnivel4.addActionListener(this);
		add(this.rbnivel4);
		this.rbnivel5.addActionListener(this);
		add(this.rbnivel5);
		btbuscar = new JButton("Buscar");
		btsalvar = new JButton("Salvar");
		btcancelar = new JButton("Cancelar");
		
		btbuscar.addActionListener(this);
		btsalvar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodFunc.addActionListener(this);
		
		funcionariodao = new FuncionarioDao();
		funcionario = new Funcionario();
		
		try {
			List<Funcionario> lista = funcionariodao.buscarTodos();
		
			for (Funcionario func : lista) {
				cbcodFunc.addItem(func.getCodFuncionario()); 
			}

		/* Coordenadas */
		setBounds(0, 0, 360, 230);
		lbcod_func.setBounds(20, 20, 150, 20);
		cbcodFunc.setBounds(130, 20, 80, 20);
		btbuscar.setBounds(232, 20, 90, 20);
		lbnomefunc.setBounds(20, 50, 130, 20);
		tfnomefunc.setBounds(125, 50, 200, 20);
		lbsenha_func.setBounds(20, 75, 200, 20);
		pfsenha_func.setBounds(125, 75, 200, 20);
		lbniv_acesso.setBounds(20, 100, 180, 20);
		rbnivel1.setBounds(20, 120, 65, 25);
		rbnivel2.setBounds(85, 120, 65, 25);
		rbnivel3.setBounds(150, 120, 65, 25);
		rbnivel4.setBounds(215, 120, 65, 25);
		rbnivel5.setBounds(280, 120, 65, 25);
		btsalvar.setBounds(20, 150, 90, 25);
		btcancelar.setBounds(240, 150, 90, 25);

		/* Execu��o na Tela */
		add(lbcod_func);
		add(cbcodFunc);
		add(lbnomefunc);
		add(tfnomefunc);
		add(lbsenha_func);
		add(pfsenha_func);
		add(lbniv_acesso);
		nivelAcesso.add(rbnivel1);
		nivelAcesso.add(rbnivel2);
		nivelAcesso.add(rbnivel3);
		nivelAcesso.add(rbnivel4);
		nivelAcesso.add(rbnivel5);
		add(btsalvar);
		add(btcancelar);
		add(btbuscar);

		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodFunc.getSelectedItem());
				int codDesconto = Integer.parseInt(item);
				funcionario = funcionariodao.buscarPorId(codDesconto);	
				
				tfnomefunc.setText(funcionario.getNomeFuncionario());
					JOptionPane.showMessageDialog(null, "Funcion�rio Consultado com Sucesso!");
				} 
			else if (event.getSource() == this.btsalvar) {
				if ("".equals(tfnomefunc.getText().trim())) {
					throw new CampoObrigatorioException("Nome Funcionario");
				}
	
				if ("".equals(pfsenha_func.getText().trim())) {
					throw new CampoObrigatorioException("Senha");
				}
	
				String nivel = null;
				if (rbnivel1.isSelected()) {
					nivel = "1";
				} else if (rbnivel2.isSelected()) {
					nivel = "2";
				} else if (rbnivel3.isSelected()) {
					nivel = "3";
				} else if (rbnivel4.isSelected()) {
					nivel = "4";
				} else if (rbnivel5.isSelected()) {
					nivel = "5";
				}
				
				funcionariodao = new FuncionarioDao();
				funcionario = new Funcionario();
				funcionario.setCodFuncionario(Integer.parseInt(cbcodFunc.getSelectedItem().toString()));
				funcionario.setNomeFuncionario(tfnomefunc.getText());
				funcionario.setSenha(pfsenha_func.getText());
				funcionario.setNivelAcesso(Integer.parseInt(nivel));
				funcionariodao.salvar(funcionario);
			
				JOptionPane.showMessageDialog(this, "Funcionario cadastrado com sucesso");
				
				setValoresIniciais();
				
			}else if (btcancelar == event.getSource()) {
				this.dispose();
			}
			 
		}catch (CampoObrigatorioException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Erro de digita��o", JOptionPane.ERROR_MESSAGE);
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
	private void setValoresIniciais() {
		tfnomefunc.setText("");
		pfsenha_func.setText("");
		
		rbnivel1.setSelected(true);
		rbnivel2.setSelected(false);
		rbnivel3.setSelected(false);
		rbnivel4.setSelected(false);
		rbnivel5.setSelected(false);
	}
}
