package fox.cadastro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import fox.bean.Funcionario;
import fox.dao.FuncionarioDao;
import fox.exception.CampoObrigatorioException;
import fox.exception.DaoException;
import fox.util.db.Conexao;

public class CadFunc extends JFrame implements ActionListener {
	
	Conexao conectaBanco;
	
	private JLabel lbnomefunc;
	private JTextField tfnomefunc;
	private JLabel lbsenha_func;
	private JPasswordField pfsenha_func;
	private JLabel lbniv_acesso;
	private JRadioButton rbnivel1;
	private JRadioButton rbnivel2;
	private JRadioButton rbnivel3;
	private JRadioButton rbnivel4;
	private JRadioButton rbnivel5;
	private JButton btsalvar;
	private JButton btapagar;
	private JButton btcancelar;
	private ButtonGroup nivelAcesso;
	private FuncionarioDao funcionariodao;
	private Funcionario funcionario;
	
	public CadFunc () {
		
		/* Cria��o de Objetos */
		setTitle("Cadastro Funcion�rio");
		lbnomefunc = new JLabel("Nome Funcion�rio");
		tfnomefunc = new JTextField();
		lbsenha_func = new JLabel("Senha Funcion�rio");
		pfsenha_func = new JPasswordField();
		lbniv_acesso = new JLabel("N�vel de Acesso Funcion�rio");
		nivelAcesso = new ButtonGroup();
		rbnivel1 = new JRadioButton("N�vel 1", true);
		rbnivel2 = new JRadioButton("N�vel 2", false);
		rbnivel3 = new JRadioButton("N�vel 3", false);
		rbnivel4 = new JRadioButton("N�vel 4", false);
		rbnivel5 = new JRadioButton("N�vel 5", false);
		this.rbnivel1.addActionListener(this);
		add(this.rbnivel1);
		this.rbnivel2.addActionListener(this);
		add(this.rbnivel2);
		this.rbnivel3.addActionListener(this);
		add(this.rbnivel3);
		this.rbnivel4.addActionListener(this);
		add(this.rbnivel4);
		this.rbnivel5.addActionListener(this);
		add(this.rbnivel5);
		btsalvar = new JButton("Salvar");
		btapagar = new JButton("Limpar");
		btcancelar = new JButton("Cancelar");

		/* Coordenadas */
		setBounds(0, 0, 360, 200);
		lbnomefunc.setBounds(20, 10, 130, 20);
		tfnomefunc.setBounds(125, 10, 210, 20);
		lbsenha_func.setBounds(20, 35, 200, 20);
		pfsenha_func.setBounds(125, 35, 210, 20);
		lbniv_acesso.setBounds(20, 60, 180, 20);
		rbnivel1.setBounds(20, 85, 65, 20);
		rbnivel2.setBounds(85, 85, 65, 20);
		rbnivel3.setBounds(150, 85, 65, 20);
		rbnivel4.setBounds(215, 85, 65, 20);
		rbnivel5.setBounds(280, 85, 65, 20);
		btsalvar.setBounds(20, 125, 90, 25);
		btapagar.setBounds(130, 125, 90, 25);
		btcancelar.setBounds(240, 125, 90, 25);

		/* Execu��o na Tela */
		add(lbnomefunc);
		add(tfnomefunc);
		add(lbsenha_func);
		add(pfsenha_func);
		add(lbniv_acesso);
		nivelAcesso.add(rbnivel1);
		nivelAcesso.add(rbnivel2);
		nivelAcesso.add(rbnivel3);
		nivelAcesso.add(rbnivel4);
		nivelAcesso.add(rbnivel5);
		add(btsalvar);
		add(btapagar);
		add(btcancelar);

		setLayout(null);
		setVisible(true);
		setResizable(false);
			
		btsalvar.addActionListener(this);
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}
	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.btsalvar) {
				if ("".equals(tfnomefunc.getText().trim())) {
					throw new CampoObrigatorioException("Nome Funcionario");
				}
	
				if ("".equals(pfsenha_func.getText().trim())) {
					throw new CampoObrigatorioException("Senha");
				}
	
				String nivel = null;
				if (rbnivel1.isSelected()) {
					nivel = "1";
				} else if (rbnivel2.isSelected()) {
					nivel = "2";
				} else if (rbnivel3.isSelected()) {
					nivel = "3";
				} else if (rbnivel4.isSelected()) {
					nivel = "4";
				} else if (rbnivel5.isSelected()) {
					nivel = "5";
				}
				
				funcionariodao = new FuncionarioDao();
				funcionario = new Funcionario();
				funcionario.setNomeFuncionario(tfnomefunc.getText());
				funcionario.setSenha(pfsenha_func.getText());
				funcionario.setNivelAcesso(Integer.parseInt(nivel));
				funcionariodao.criar(funcionario);
			
				JOptionPane.showMessageDialog(this, "Funcionario cadastrado com sucesso");
				setValoresIniciais();
				
			} else if (btapagar == event.getSource()) {
				setValoresIniciais();
			} else if (btcancelar == event.getSource()) {
				this.dispose();
			}
		} catch (CampoObrigatorioException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Erro de digita��o", JOptionPane.ERROR_MESSAGE);
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar a base, contactar o Marcelo ou o Vinicius", "Erro de banco de dados", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	private void setValoresIniciais() {
		tfnomefunc.setText("");
		pfsenha_func.setText("");
		
		rbnivel1.setSelected(true);
		rbnivel2.setSelected(false);
		rbnivel3.setSelected(false);
		rbnivel4.setSelected(false);
		rbnivel5.setSelected(false);
	}
}
