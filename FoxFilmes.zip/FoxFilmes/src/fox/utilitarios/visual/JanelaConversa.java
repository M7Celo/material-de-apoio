package fox.utilitarios.visual;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class JanelaConversa extends JFrame {

	private ServerSocket serverSocket;
	private Socket socket;
	
	private ObjectOutputStream outputStream;
	private ObjectInputStream inputStream;
	
	private JTextArea textFieldEnviar;
	private JTextArea textFieldReceber;
	private JButton enviar;
	private JButton fechar;
	
	private static final int NUM_COLUNAS_TEXT_AREA = 30;
	
	public JanelaConversa(ServerSocket serverSocket, Socket socket,
			ObjectOutputStream outputStream, ObjectInputStream inputStream) {
		this.serverSocket = serverSocket;
		this.socket = socket;
		
		this.outputStream = outputStream;
		this.inputStream = inputStream;
	
	
		this.textFieldEnviar = new JTextArea(5, NUM_COLUNAS_TEXT_AREA);
		this.textFieldEnviar.setLineWrap(true);
		
		Box box1 = Box.createHorizontalBox();
		box1.add(new JScrollPane(this.textFieldEnviar));
		
		this.textFieldReceber = new JTextArea(5, NUM_COLUNAS_TEXT_AREA);
		this.textFieldReceber.setLineWrap(true);
		this.textFieldReceber.setEditable(false);
		
		Box box2 = Box.createHorizontalBox();
		box2.add(new JScrollPane(this.textFieldReceber));
		
		boolean cliente = (this.serverSocket == null); 
		
		this.enviar = new JButton("Enviar");
		this.enviar.addActionListener(new TratadorEnviarButton(this));

		LeitorSocket leitorSocket = 
				new LeitorSocket(
						this.inputStream,
						this.textFieldReceber, 
						cliente, 
						this.socket, 
						this);
		
		
		this.fechar = new JButton("Fechar");
		this.fechar.addActionListener(new TratadorFecharButton(this, cliente, leitorSocket));
		
		tentaSetaNimbus();
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(2584/6, 1597/4);
		
		LeiouteCadastroBuilder leiaute = new LeiouteCadastroBuilder(this);
		
		Thread thread = 
				new Thread(
						leitorSocket);
		
		thread.start();
		
		leiaute.inicio(0, 0).esq()
			.add(new JLabel("Mensagens Recebidas"))
			.pulaLinha()
			.add(box2)
			.pulaLinha()
			.add(new JLabel("Mensagem"))
			.pulaLinha()
			.add(box1)
			.add(this.enviar, 1)
			.pulaLinha()
			.pulaColuna(1)
			.add(this.fechar, 1);
			
		setVisible(true);
		
	}
	
	private class LeitorSocket implements Runnable {

		private ObjectInputStream inputStream;
		private JTextArea textFieldReceber;
		private boolean cliente;
		private boolean continuar = true;
		private Socket socket;
		private JFrame jframe;
		
		public LeitorSocket(
				ObjectInputStream inputStream,
				JTextArea textFieldReceber, 
				boolean cliente, 
				Socket socket,
				JFrame jframe) {
			this.inputStream = inputStream;
			this.textFieldReceber = textFieldReceber;
			this.cliente = cliente;
			this.socket = socket;
			this.jframe = jframe;
		}

		@Override
		public void run() {
			while (this.continuar) {
				try {
					Thread.sleep(100);
				
					String line = (String)inputStream.readObject();
					System.out.println("Linha recebida :" + line);
					
					processaMensagem(line);
				
					
					
				} catch (InterruptedException e) {
					//e.printStackTrace();
					this.continuar = false;
				} catch (IOException e) {
					//e.printStackTrace();
					this.continuar = false;
				} catch (ClassNotFoundException e) {
					//e.printStackTrace();
					this.continuar = false;
				} 
			}
			System.out.println("Terminando");
			this.jframe.dispose();
			System.exit(0);
		}

		private void processaMensagem(String line) {
			if (line.startsWith("[MSG]")) {
				line = line.substring("[MSG]".length());
				this.textFieldReceber.setText(this.textFieldReceber.getText() + "\n" +  line);
			} else if (line.startsWith("[BYE]")) {
				terminarConversar();
			}
			
		}

		private void terminarConversar() {
			if (this.cliente) {
				try {
					this.socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			this.continuar = false;
		}
		
	}
	
	private class TratadorFecharButton implements ActionListener {

		private JFrame janelaConversa;
		private boolean cliente;
		private LeitorSocket leitorSocket;
		
		public TratadorFecharButton(JFrame janelaConversa, boolean cliente, LeitorSocket leitorSocket) {
			this.janelaConversa = janelaConversa;
			this.cliente = cliente;
			this.leitorSocket = leitorSocket;
		}


		@Override
		public void actionPerformed(ActionEvent action) {
			try {
				if (this.cliente) {
					socket.close();
				} else {
					JanelaConversa.enviarMensagem("[BYE]", "BYE", outputStream);
				}
				this.leitorSocket.continuar = false;
				
			} catch (IOException e) {
				JOptionPane.showMessageDialog(janelaConversa, e.getMessage());
			}
		}
		
	}

	private class TratadorEnviarButton implements ActionListener {

		private JFrame janelaConversa;
		
		public TratadorEnviarButton(JFrame janelaConversa) {
			this.janelaConversa = janelaConversa;
		}


		@Override
		public void actionPerformed(ActionEvent action) {
			try {
				
				JanelaConversa.enviarMensagem("[MSG]", textFieldEnviar.getText(), outputStream);
				textFieldEnviar.setText("");
			} catch (IOException e) {
				JOptionPane.showMessageDialog(janelaConversa, e.getMessage());
			}
		}
	}
	
	public static void enviarMensagem(String tipo, String mensagem, ObjectOutputStream outputStream) throws IOException {
		String msg = String.format("%s%s", tipo, mensagem);
		outputStream.writeObject(msg);
		outputStream.flush();
	}
	
	public void tentaSetaNimbus() {
		UIManager.LookAndFeelInfo[] looks = UIManager.getInstalledLookAndFeels();
		for (UIManager.LookAndFeelInfo look :looks) {
			if (look.getClassName().matches("(?i).*nimbus.*")) {
				try {
					UIManager.setLookAndFeel(look.getClassName());
					SwingUtilities.updateComponentTreeUI(this);
					return;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
}
