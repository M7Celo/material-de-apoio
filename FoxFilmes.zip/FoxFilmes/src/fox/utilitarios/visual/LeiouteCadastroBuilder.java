package fox.utilitarios.visual;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;

public class LeiouteCadastroBuilder {

	private JFrame frame;
	private GridBagLayout layout;
	private GridBagConstraints gridBagConstraints;
	private int colunaInicial;
	
	public LeiouteCadastroBuilder(JFrame frame) {
		this.frame = frame;
		this.layout = new GridBagLayout();
		frame.setLayout(this.layout);
		this.gridBagConstraints = new GridBagConstraints();
		this.gridBagConstraints.gridheight = 1;
		largura(1).center();
	}
	
	public LeiouteCadastroBuilder inicio(int x, int y) {
		this.colunaInicial = x;
		this.gridBagConstraints.gridx = x;
		this.gridBagConstraints.gridy = y;
		return this;
	}
	
	public LeiouteCadastroBuilder largura(int largura) {
		this.gridBagConstraints.gridheight = largura;
		return this;
	}
	
	public LeiouteCadastroBuilder esq() {
		this.gridBagConstraints.anchor = GridBagConstraints.WEST;
		return this;
	}
	
	public LeiouteCadastroBuilder dir() {
		this.gridBagConstraints.anchor = GridBagConstraints.EAST;
		return this;
	}
	
	public LeiouteCadastroBuilder center() {
		this.gridBagConstraints.anchor = GridBagConstraints.CENTER;
		return this;
	}
	
	public LeiouteCadastroBuilder add(Component comp) {
		return add(comp, 1);
	}
	
	public LeiouteCadastroBuilder add(Component comp, int largura) {
		this.gridBagConstraints.gridx += largura;
		this.gridBagConstraints.gridwidth = largura;
		this.layout.setConstraints(comp, this.gridBagConstraints);
		this.frame.add(comp);
		return this;
	}
	
	public LeiouteCadastroBuilder pulaColuna() {
		this.gridBagConstraints.gridx++;
		return this;
	}
	
	public LeiouteCadastroBuilder pulaColuna(int numeroColunasPuladas) {
		this.gridBagConstraints.gridx += numeroColunasPuladas;
		return this;
	}
	
	public LeiouteCadastroBuilder pulaLinha() {
		this.gridBagConstraints.gridx = this.colunaInicial;
		this.gridBagConstraints.gridy++;
		return this;
	}
	
	public GridBagLayout getLayout() {
		return layout;
	}
}
