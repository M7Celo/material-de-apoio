package fox.utilitarios.visual;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class TemaInicial extends JFrame {
	
	String temaL = "com.birosoft.liquid.LiquidLookAndFeel";
	
	 public void LookAndFeelInicial(){
         try{
            UIManager.setLookAndFeel(temaL);
            SwingUtilities.updateComponentTreeUI(this);
        }catch(Exception erro){
            JOptionPane.showMessageDialog(null, erro);
        }

}

}
