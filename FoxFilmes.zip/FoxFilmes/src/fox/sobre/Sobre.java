package fox.sobre;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Sobre extends JFrame {
	private JPanel painel;
	private JLabel sobre1;
	private JLabel sobre2;
	private JLabel sobre3;
	private JLabel sobre4;
	private JLabel sobre5;
		
	public Sobre (){
		setTitle("Sobre");
		setBounds(0,0,640,155);
		
		this.painel = new JPanel();
		this.sobre1 = new JLabel("Este software foi desenvolvido em base de conhcecimentos adquiridos no curos t�cnico de inform�tica.");
		this.sobre2 = new JLabel("ITB Prof� Ant�nio Arantes Filho - Pq.Viana.");
		this.sobre3 = new JLabel("O objetivo deste software � atender os requisitos necess�rios para Trabalho de Conclus�o de Curso (TCC).");
		this.sobre4 = new JLabel("Supervis�o de Desenvolvimento: Prof� Alessandro Tacinni");
		this.sobre5 = new JLabel("Desenvolvedor do Sistema: Marcelo Correia de Lima");
		
		painel.setBounds(20, 20, 590, 150);
		painel.setBackground(new Color(255,255,255));
		sobre4.setForeground(new Color(255,0,0));
		sobre5.setForeground(new Color(0,0,255));
		sobre1.setBounds(40, 40, 400, 30);
		sobre4.setBounds(40, 100, 100, 20);
		sobre5.setBounds(40, 120, 100, 20);
		
		add(painel);
		painel.add(sobre1);
		painel.add(sobre2);
		painel.add(sobre3);
		painel.add(sobre4);
		painel.add(sobre5);
		
		
		setLayout(null);
		setResizable(false);
		setVisible(true);
		
		
	}

}
