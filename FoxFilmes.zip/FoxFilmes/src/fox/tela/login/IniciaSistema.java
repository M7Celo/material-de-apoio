package fox.tela.login;

import java.util.List;

import javax.swing.JOptionPane;

import fox.bean.Descontos;
import fox.bean.Verifica;
import fox.dao.VerificaDao;
import fox.exception.DaoException;

public class IniciaSistema {

	private static VerificaDao verificadao;
	private static Verifica verifica;
	private static int codV;
	private static int verif;
	private static int primeiroAcesso;
	private static int ve;
	
	public static void main(String[] args) {
		verificadao = new VerificaDao();
		verifica = new Verifica();
		
		try {
			List<Verifica> lista = verificadao.buscarTodos();
		
			for (Verifica v : lista) {
				codV = v.getCodVerif();
				verif = v.getVerif();
				
			}
			if(verif == 1){
				new TelaLoginFoxFilmes ();
				primeiroAcesso = 1;
				
			}else{
				primeiroAcesso = 1;
				codV = 1;
				
				verifica.setCodVerif(codV);
				verifica.setVerif(primeiroAcesso);
				
				verificadao.salvar(verifica);
				
				new SemCadastro();
				
			}
			
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(null, "Erro ao acessar o banco de dados");
			e.printStackTrace();
		}
		
		
	}

}
