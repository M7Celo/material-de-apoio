package fox.apagar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Sessao;
import fox.dao.SessaoDao;
import fox.exception.DaoException;

public class ApagaSessao extends JFrame implements ActionListener{
	
	private JLabel lbcodSessao;
	private JComboBox cbcodSessao;
	private JButton btapagar;
	private JButton btcancelar;
	private JTextField txtnomeS;
	private SessaoDao sessaodao;	
	
	public ApagaSessao(){
		
		setTitle("Apagar Sess�o");
		lbcodSessao = new JLabel("C�digo Sess�o");
		cbcodSessao = new JComboBox();
		txtnomeS = new JTextField();
		btapagar = new JButton("Apagar");
		btcancelar = new JButton("Cancelar");
		
		setBounds( 0, 0, 300, 130);
		lbcodSessao.setBounds(20,10,200,20);
		cbcodSessao.setBounds(130,10,80,20);
		txtnomeS.setBounds(20, 40, 250, 20);
		btapagar.setBounds(20,70,90,20);
		btcancelar.setBounds(180,70,90,20);
		
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodSessao.addActionListener(this);
		
		sessaodao = new SessaoDao();
		
		try {
			List<Sessao> lista = sessaodao.buscarTodos();
		
			for (Sessao sessao : lista) {
				cbcodSessao.addItem(sessao.getCodigoSessao()); 
			}
		
		add(lbcodSessao);
		add(cbcodSessao);
		add(txtnomeS);
		add(btapagar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.cbcodSessao) {
				String item = String.valueOf(cbcodSessao.getSelectedItem());
				int codSessao = Integer.parseInt(item);
				Sessao sessao = this.sessaodao.buscarPorId(codSessao);
				
				txtnomeS.setText(sessao.getNomeSessao());
				
			}
			
			if(event.getSource() == this.btapagar){
				String item = String.valueOf(cbcodSessao.getSelectedItem());
				int opcao = 
					JOptionPane.showConfirmDialog(
						this, "Deseja realmente apagar '" + this.txtnomeS.getText() + "'?", 
						"Apagar Sess�o", 
						JOptionPane.YES_NO_OPTION);
				int codApagar = Integer.parseInt(item);
					if (opcao == JOptionPane.YES_OPTION) {
						sessaodao.apagar(codApagar);
						txtnomeS.setText("");
						JOptionPane.showMessageDialog(null, "Sess�o Apagada com Sucesso!");
					}
				}
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
