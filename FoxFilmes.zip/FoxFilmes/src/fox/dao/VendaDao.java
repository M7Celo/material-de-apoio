package fox.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fox.bean.Filme;
import fox.bean.Venda;
import fox.util.db.DbUtil;

public class VendaDao extends DaoBase<Venda> {
	
private static final String SEQUNCE = "VENDA_ING_SEQ";
	
	private static final String BUSCAR_POR_ID = "SELECT " +
				"NUM_ING," +
				"NOME_SESSAO, " +
				"NOME_FILME, " +
				"NOME_DESC, " +
				"VALOR_DESC, " +
				"QTD_POL_DISP, " + 
				"QTD_POL_RES, " +
				"QTD_POL_ESP, " + 
				"VALOR_FILME," +  
				"VALOR_REC, " +
				"TROCO, "  +
				"VALOR_FINAL, " +
				"CARTAO "+
				"FROM VENDA_ING WHERE NUM_ING = ? ";
	
	private static final String BUSCAR_TODOS = "SELECT NUM_ING, " +
				"NOME_SESSAO, " +
				"NOME_FILME, " +
				"NOME_DESC, " +
				"VALOR_DESC, " +
				"QTD_POL_DISP, " + 
				"QTD_POL_RES, " +
				"QTD_POL_ESP, " + 
				"VALOR_FILME," +  
				"VALOR_REC, " +
				"TROCO, "  +
				"VALOR_FINAL, " +
				"CARTAO "+
				"FROM VENDA_ING ";
	
	private static final String SALVAR = "UPDATE VENDA_ING SET " +
				"NUM_ING, " +
				"NOME_SESSAO = ? , " +
				"NOME_FILME = ? , " +
				"NOME_DESC = ? , " +
				"VALOR_DESC = ? , " +
				"QTD_POL_DISP = ? , " + 
				"QTD_POL_RES = ? , " +
				"QTD_POL_ESP = ? , " + 
				"VALOR_FILME = ? ," +  
				"VALOR_REC = ? , " +
				"TROCO = ? , "  +
				"VALOR_FINAL = ?,  " +
				"CARTAO "+
				"WHERE NUM_ING = ? ";
				
	
	private static final String APAGAR = "DELETE FROM VENDA_ING WHERE COD_FILME = ? ";
	
	private static final String CRIAR = "" +
			"insert into VENDA_ING(" +
			"NUM_ING, " +
			"NOME_SESSAO, " +
			"NOME_FILME, " +
			"NOME_DESC, " +
			"VALOR_DESC, " +
			"QTD_POL_DISP, " + 
			"QTD_POL_RES, " +
			"QTD_POL_ESP, " + 
			"VALOR_FILME," +  
			"VALOR_REC, " +
			"TROCO, "  +
			"VALOR_FINAL, " +
			"CARTAO) " +
			"values( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";

	public VendaDao() {
		super(
//				NOME SEQUENCE
				SEQUNCE, 
				
//				SELECT POR ID'S(BUSCAR POR ID'S)
				BUSCAR_POR_ID, 

//				BUSCAR TODOS
				BUSCAR_TODOS,
				
//				SALVAR
				SALVAR,
				
//				APAGAR
				APAGAR, 
				
//				CRIAR
				CRIAR);
	}

	@Override
	protected Venda getBean(ResultSet result) throws SQLException {
		Venda bean = new Venda();
		bean.setNumIng(result.getInt("NUM_ING"));
		bean.setNomesessao(result.getString("NOME_SESSAO"));
		bean.setNomefilme(result.getString("NOME_FILME"));
		bean.setNomedesc(result.getString("NOME_DESC"));
		bean.setValordesc(result.getString("VALOR_DESC"));
		bean.setQtdpoldisp(result.getInt("QTD_POL_DISP"));
		bean.setQtdpolres(result.getInt("QTD_POL_RES"));
		bean.setQtdpolres(result.getInt("QTD_POL_ESP"));
		bean.setValorfilme(result.getString("VALOR_FILME"));
		bean.setValorrec(result.getString("VALOR_REC"));
		bean.setTroco(result.getString("TROCO"));
		bean.setValorfinal(result.getString("VALOR_FINAL"));
		bean.setCartao(result.getString("CARTAO"));	
		return bean;
	}

	@Override
	protected void setParametrosUpdate(
			PreparedStatement statement,
			Venda bean)
			throws SQLException {
		
		statement.setString(1, bean.getNomesessao());
		statement.setString(2, bean.getNomefilme());
		statement.setString(3, bean.getNomedesc());
		statement.setString(4, bean.getValordesc());
		statement.setInt(5, bean.getQtdpoldisp());
		statement.setInt(6, bean.getQtdpolres());
		statement.setInt(7, bean.getQtdpolesp());
		statement.setString(8, bean.getValorfilme());
		statement.setString(9, bean.getValorrec());
		statement.setString(10, bean.getTroco());
		statement.setString(11, bean.getValorfinal());
		statement.setString(112, bean.getCartao());
		statement.setInt(13, bean.getNumIng());		
	}

	@Override
	protected void setParametrosInsert(
			PreparedStatement statement,
			Venda bean,
			int novoId) throws SQLException {
		
		
		statement.setInt(1, bean.getNumIng());
		statement.setString(2, bean.getNomesessao());
		statement.setString(3, bean.getNomefilme());
		statement.setString(4, bean.getNomedesc());
		statement.setString(5, bean.getValordesc());
		statement.setInt(6, bean.getQtdpoldisp());
		statement.setInt(7, bean.getQtdpolres());
		statement.setInt(8, bean.getQtdpolesp());
		statement.setString(9, bean.getValorfilme());
		statement.setString(10, bean.getValorrec());
		statement.setString(11, bean.getTroco());
		statement.setString(12, bean.getValorfinal());
		statement.setString(13, bean.getCartao());
	}	

}
