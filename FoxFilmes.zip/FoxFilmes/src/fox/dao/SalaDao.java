package fox.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fox.bean.Sala;

public class SalaDao extends DaoBase<Sala> {
	
	private static final String SEQUENCE = "CAD_SALA_SEQ";
	
	private static final String BUSCAR_POR_ID = "SELECT " +
			"COD_SALA, " +
			"NUM_SALA, " +
			"QTD_POLTRONA , " +
			"QTD_POLTRONA_DISP, " +
			"QTD_POLTRONA_RES, " +
			"QTD_POLTRONA_ESP " +
			"FROM CAD_SALA WHERE COD_SALA = ? ";
	
	private static final String BUSCAR_TODOS = "SELECT COD_SALA, NUM_SALA, QTD_POLTRONA, QTD_POLTRONA_DISP, QTD_POLTRONA_RES, QTD_POLTRONA_ESP FROM CAD_SALA ";
	
	private static final String SALVAR = "UPDATE CAD_SALA " +
				"SET " +
				" NUM_SALA = ? , " +
				" QTD_POLTRONA = ?," +
				" QTD_POLTRONA_DISP = ?, " +
				" QTD_POLTRONA_RES = ?, " +
				" QTD_POLTRONA_ESP = ? " +
				"WHERE COD_SALA = ? ";
	
	private static final String APAGAR = "DELETE FROM CAD_SALA WHERE COD_SALA = ? ";
	
	private static final String CRIAR = "insert into CAD_SALA(" +
			"COD_SALA," +
			" NUM_SALA, " +
			"QTD_POLTRONA, " +
			"QTD_POLTRONA_DISP, " +
			"QTD_POLTRONA_RES, " +
			"QTD_POLTRONA_ESP) values( ?, ?, ?, ?, ?, ?)";


	public SalaDao() {
		
		super(
//				NOME SEQUENCE
				SEQUENCE, 
				
//				SELECT POR ID'S(BUSCAR POR ID'S)
				BUSCAR_POR_ID, 

//				BUSCAR TODOS
				BUSCAR_TODOS,
				
//				SALVAR
				SALVAR,
				
//				APAGAR
				APAGAR, 
				
//				CRIAR
				CRIAR);
		
	}

	@Override
	protected Sala getBean(ResultSet result) throws SQLException {
		Sala bean = new Sala();
		bean.setCodSala(result.getInt("COD_SALA"));
		bean.setNumSala(result.getInt("NUM_SALA"));
		bean.setQtdPoltrona(result.getInt("QTD_POLTRONA"));
		bean.setQtdPoltronaDis(result.getInt("QTD_POLTRONA_DISP"));
		bean.setQtdPoltronaRes(result.getInt("QTD_POLTRONA_RES"));
		bean.setQtdPoltronaEsp(result.getInt("QTD_POLTRONA_ESP"));		
		return bean;
	}

	@Override
	protected void setParametrosUpdate(PreparedStatement statement, Sala bean)
			throws SQLException {
		
		statement.setInt(1, bean.getNumSala());
		statement.setInt(2, bean.getQtdPoltrona());
		statement.setInt(3, bean.getQtdPoltronaDis());
		statement.setInt(4, bean.getQtdPoltronaRes());
		statement.setInt(5, bean.getQtdPoltronaEsp());
		statement.setInt(6, bean.getCodSala());
		
	}

	@Override
	protected void setParametrosInsert(
			PreparedStatement statement,
			Sala bean,
			int novoId) throws SQLException {
			bean.setCodSala(novoId);
			
			statement.setInt(1, bean.getCodSala());
			statement.setInt(2, bean.getNumSala());
			statement.setInt(3, bean.getQtdPoltrona());
			statement.setInt(4, bean.getQtdPoltronaDis());
			statement.setInt(5, bean.getQtdPoltronaRes());
			statement.setInt(6, bean.getQtdPoltronaEsp());
	}

}
