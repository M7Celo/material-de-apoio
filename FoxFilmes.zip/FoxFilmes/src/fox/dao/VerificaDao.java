package fox.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fox.bean.Valor;
import fox.bean.Verifica;

public class VerificaDao extends DaoBase<Verifica> {
	
private static final String SEQUENCE = "VERIFICA_SEQ";
	
	private static final String BUSCAR_POR_ID = "SELECT " +
			"COD_VERIFICA, " +
			"VERIFICA, " +
			"FROM PRIMEIRO_ACESSO " +
			"WHERE COD_VERIFICA = ? ";
	
	private static final String BUSCAR_TODOS = "SELECT " +
			"COD_VERIFICA, " +
			"VERIFICA " +
			"FROM PRIMEIRO_ACESSO ";
	
	private static final String SALVAR = "UPDATE PRIMEIRO_ACESSO SET " +
			"VERIFICA = ? " +
			"WHERE COD_VERIFICA = ? ";

	private static final String APAGAR = "DELETE FROM PRIMEIRO_ACESSO WHERE COD_VERIFICA = ? ";
	
	private static final String CRIAR = "insert into PRIMEIRO_ACESSO(" +
			"COD_VERIFICA, " +
			"VERIFICA ) values( ?, ?)";
	
	public VerificaDao() {

		super(
//				NOME SEQUENCE
				SEQUENCE, 
				
//				SELECT POR ID'S(BUSCAR POR ID'S)
				BUSCAR_POR_ID, 

//				BUSCAR TODOS
				BUSCAR_TODOS,
				
//				SALVAR
				SALVAR,
				
//				APAGAR
				APAGAR, 
				
//				CRIAR
				CRIAR);
	}

	@Override
	protected Verifica getBean(ResultSet result) throws SQLException {
		Verifica bean = new Verifica();
		bean.setCodVerif(result.getInt("COD_VERIFICA"));
		bean.setVerif(result.getInt("VERIFICA"));
		return bean;
	}

	@Override
	protected void setParametrosUpdate(
			PreparedStatement statement,
			Verifica bean)
			throws SQLException {
		
		
		statement.setInt(1, bean.getVerif());
		statement.setInt(2, bean.getCodVerif());
		
	}

	@Override
	protected void setParametrosInsert(
			PreparedStatement statement,
			Verifica bean,
			int novoId) throws SQLException {
		
		statement.setInt(1, bean.getCodVerif());
		statement.setInt(2, bean.getVerif());
		
		
	}

}
