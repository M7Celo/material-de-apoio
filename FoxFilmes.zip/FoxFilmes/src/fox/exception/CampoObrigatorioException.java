package fox.exception;

public class CampoObrigatorioException extends Exception {

	public CampoObrigatorioException() {
	}

	public CampoObrigatorioException(String arg0) {
		super(montaMensagem(arg0));
	}

	private static String montaMensagem(String arg0) {
		return "Campo '" + arg0 + "' obrigatorio";
	}

	public CampoObrigatorioException(Throwable arg0) {
		super(arg0);
	}

	public CampoObrigatorioException(String arg0, Throwable arg1) {
		super(montaMensagem(arg0), arg1);
	}

}
