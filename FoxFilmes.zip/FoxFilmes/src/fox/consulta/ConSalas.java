package fox.consulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Sala;
import fox.dao.SalaDao;
import fox.exception.DaoException;

public class ConSalas extends JFrame implements ActionListener {
	
	private JLabel lbcod_sala;
	private JComboBox cbcodSala;
	private JLabel lbnomesala;
	private JTextField tfnomesala;
	private JLabel lbqtdpol;
	private JTextField tfqtdpol;
	private JLabel lbqtdpoldis;
	private JTextField tfqtdpoldis;
	private JLabel lbqtdpolres;
	private JTextField tfqtdpolres;
	private JLabel lbpolesp;
	private JTextField tfpolesp;
	private JButton btbuscar;
	private JButton btcancelar;
	private SalaDao saladao;
	private Sala sala;
	

	public ConSalas () {
		
		/* Cria��o de Objetos */
		setTitle("Consulta Salas");
		lbcod_sala = new JLabel("C�digo sala");
		cbcodSala = new JComboBox();
		lbnomesala = new JLabel("N�mero Sala");
		tfnomesala = new JTextField ();
		lbqtdpol = new JLabel("Qtd Poltrona");
		tfqtdpol = new JTextField ();
		lbqtdpoldis = new JLabel("Qtd Poltrona Dispon�veis");
		tfqtdpoldis = new JTextField ();
		lbqtdpolres = new JLabel("Qtd Poltrona Reservadas");
		tfqtdpolres = new JTextField ();
		lbpolesp = new JLabel("Poltrona Especiais");
		tfpolesp = new JTextField ();
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		
		btbuscar.addActionListener(this);
		cbcodSala.addActionListener(this);
		btcancelar.addActionListener(this);
		
		saladao = new SalaDao();
		
		try {
			List<Sala> lista = saladao.buscarTodos();
		
			for (Sala sala : lista) {
				cbcodSala.addItem(sala.getCodSala()); 
			}
		
		/* Coordenadas */
		setBounds(0, 0, 300, 250);
		lbcod_sala.setBounds(20, 10, 80, 25);
		cbcodSala.setBounds(95, 10, 80, 20);
		lbnomesala.setBounds(20, 40, 130, 25);
		tfnomesala.setBounds(100, 40, 100, 20);
		lbqtdpol.setBounds(20, 65, 100, 25);
		tfqtdpol.setBounds(98, 65, 70, 20);
		lbqtdpoldis.setBounds(20, 90, 150, 25);
		tfqtdpoldis.setBounds(165, 90, 70, 20);
		lbqtdpolres.setBounds(20, 115, 150, 25);
		tfqtdpolres.setBounds(168, 115, 70, 20);
		lbpolesp.setBounds(20, 140, 150, 25);
		tfpolesp.setBounds(135, 140, 70, 20);
		btbuscar.setBounds(20, 180, 90, 25);
		btcancelar.setBounds(180, 180, 90, 25);
		
		
		/* Execu��o na Tela */
		add(lbcod_sala);
		add(cbcodSala);
		add(lbnomesala);
		add(tfnomesala);
		add(lbqtdpol);
		add(tfqtdpol);
		add(lbqtdpoldis);
		add(tfqtdpoldis);
		add(lbqtdpolres);
		add(tfqtdpolres);
		add(lbpolesp);
		add(tfpolesp);
		add(btbuscar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);	
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
	}


	@Override
	public void actionPerformed(ActionEvent event) {
		try{
		if(event.getSource() == this.btbuscar){
			String item = String.valueOf(cbcodSala.getSelectedItem());
			int codSala = Integer.parseInt(item);
			sala = saladao.buscarPorId(codSala);	
			
			tfnomesala.setText(String.valueOf(sala.getNumSala()));
			tfqtdpol.setText(String.valueOf(sala.getQtdPoltrona()));
			tfqtdpoldis.setText(String.valueOf(sala.getQtdPoltronaDis()));
			tfqtdpolres.setText(String.valueOf(sala.getQtdPoltronaRes()));
			tfpolesp.setText(String.valueOf(sala.getQtdPoltronaEsp()));
				JOptionPane.showMessageDialog(null, "Sala Consultada com Sucesso!");
			}if (btcancelar == event.getSource()) {
				this.dispose();
			}
		 
	} catch (DaoException e) {
		JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
		e.printStackTrace();
		}
		
	}
}