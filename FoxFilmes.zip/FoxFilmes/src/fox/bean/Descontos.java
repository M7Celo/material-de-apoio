package fox.bean;

public class Descontos {
	
	private int codDescontos;
	private String nomeConvenio;
	private String valorConvenio;
	private String nomePromo;
	private String valorPromo;
	private String nomeSind;
	private String valorSind;
	private String descontosFixo;
	
	public int getCodDescontos() {
		return codDescontos;
	}
	public void setCodDescontos(int codDescontos) {
		this.codDescontos = codDescontos;
	}
	public String getNomeConvenio() {
		return nomeConvenio;
	}
	public void setNomeConvenio(String nomeConvenio) {
		this.nomeConvenio = nomeConvenio;
	}
	public String getValorConvenio() {
		return valorConvenio;
	}
	public void setValorConvenio(String valorConvenio) {
		this.valorConvenio = valorConvenio;
	}
	public String getNomePromo() {
		return nomePromo;
	}
	public void setNomePromo(String nomePromo) {
		this.nomePromo = nomePromo;
	}
	public String getValorPromo() {
		return valorPromo;
	}
	public void setValorPromo(String valorPromo) {
		this.valorPromo = valorPromo;
	}
	public String getNomeSind() {
		return nomeSind;
	}
	public void setNomeSind(String nomeSind) {
		this.nomeSind = nomeSind;
	}
	public String getValorSind() {
		return valorSind;
	}
	public void setValorSind(String valorSind) {
		this.valorSind = valorSind;
	}
	public String getDescontosFixo() {
		return descontosFixo;
	}
	public void setDescontosFixo(String descontosFixo) {
		this.descontosFixo = descontosFixo;
	}
	public String toString() {
		return "Descontos [codDescontos=" + codDescontos + ", nomeConvenio="
				+ nomeConvenio + ", valorConvenio=" + valorConvenio
				+ ", nomePromo=" + nomePromo + ", valorPromo=" + valorPromo
				+ ", nomeSind=" + nomeSind + ", valorSind=" + valorSind
				+ ", descontosFixo=" + descontosFixo + "]";
	}
	
}
