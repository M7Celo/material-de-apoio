package fox.bean;

public class Funcionario {

	private int codFuncionario;
	private String nomeFuncionario;
	private String senha;
	private int nivelAcesso;
	
	public int getCodFuncionario() {
		return codFuncionario;
	}
	public void setCodFuncionario(int codFuncionario) {
		this.codFuncionario = codFuncionario;
	}
	public String getNomeFuncionario() {
		return nomeFuncionario;
	}
	public void setNomeFuncionario(String nomeFuncionario) {
		this.nomeFuncionario = nomeFuncionario;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public int getNivelAcesso() {
		return nivelAcesso;
	}
	public void setNivelAcesso(int nivelAcesso) {
		this.nivelAcesso = nivelAcesso;
	}
	@Override
	public String toString() {
		return "Funcionario [codFuncionario=" + codFuncionario
				+ ", nomeFuncionario=" + nomeFuncionario + ", senha=" + senha
				+ ", nivelAcesso=" + nivelAcesso + "]";
	}
}
