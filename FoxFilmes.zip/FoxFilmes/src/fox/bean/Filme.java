package fox.bean;

import java.util.Date;

public class Filme {

	private int codFilme;
	private String nomeFilme;
	private String categoriaFilme;
	private String produtoraFilme;
	private Date dataLancamento;
	private Date exibicaoAte;
	private String paisOrigem;
	private String idiomaFilme;
	private String classificacaoEtaria;
	private String dublado;
	private String legendado;
	private String emExibicao;
	private String foraExibicao;
	
	public int getCodFilme() {
		return codFilme;
	}
	public void setCodFilme(int codFilme) {
		this.codFilme = codFilme;
	}
	public String getNomeFilme() {
		return nomeFilme;
	}
	public void setNomeFilme(String nomeFilme) {
		this.nomeFilme = nomeFilme;
	}
	public String getCategoriaFilme() {
		return categoriaFilme;
	}
	public void setCategoriaFilme(String categoriaFilme) {
		this.categoriaFilme = categoriaFilme;
	}
	public String getProdutoraFilme() {
		return produtoraFilme;
	}
	public void setProdutoraFilme(String produtoraFilme) {
		this.produtoraFilme = produtoraFilme;
	}
	public Date getDataLancamento() {
		return dataLancamento;
	}
	public void setDataLancamento(Date dataLancamento) {
		this.dataLancamento = dataLancamento;
	}
	public Date getExibicaoAte() {
		return exibicaoAte;
	}
	public void setExibicaoAte(Date exibicaoAte) {
		this.exibicaoAte = exibicaoAte;
	}
	public String getPaisOrigem() {
		return paisOrigem;
	}
	public void setPaisOrigem(String paisOrigem) {
		this.paisOrigem = paisOrigem;
	}
	public String getIdiomaFilme() {
		return idiomaFilme;
	}
	public void setIdiomaFilme(String idiomaFilme) {
		this.idiomaFilme = idiomaFilme;
	}
	public String getClassificacaoEtaria() {
		return classificacaoEtaria;
	}
	public void setClassificacaoEtaria(String classificacaoEtaria) {
		this.classificacaoEtaria = classificacaoEtaria;
	}
	public String getDublado() {
		return dublado;
	}
	public void setDublado(String dublado) {
		this.dublado = dublado;
	}
	public String getLegendado() {
		return legendado;
	}
	public void setLegendado(String legendado) {
		this.legendado = legendado;
	}
	public String getEmExibicao() {
		return emExibicao;
	}
	public void setEmExibicao(String emExibicao) {
		this.emExibicao = emExibicao;
	}
	public String getForaExibicao() {
		return foraExibicao;
	}
	public void setForaExibicao(String foraExibicao) {
		this.foraExibicao = foraExibicao;
	}
	@Override
	public String toString() {
		return "Filme [codFilme=" + codFilme + ", nomeFilme=" + nomeFilme
				+ ", categoriaFilme=" + categoriaFilme + ", produtoraFilme="
				+ produtoraFilme + ", dataLancamento=" + dataLancamento
				+ ", exibicaoAte=" + exibicaoAte + ", paisOrigem=" + paisOrigem
				+ ", idiomaFilme=" + idiomaFilme + ", classificacaoEtaria="
				+ classificacaoEtaria + ", dublado=" + dublado + ", legendado="
				+ legendado + ", emExibicao=" + emExibicao + ", foraExibicao="
				+ foraExibicao + "]";
	}
}
