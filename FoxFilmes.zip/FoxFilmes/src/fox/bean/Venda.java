package fox.bean;

public class Venda {
	
	private int numIng;
	private String nomesessao;
	private String nomefilme;
	private String nomedesc;
	private String valordesc;
	private int qtdpoldisp;	
	private int qtdpolres;	
	private int qtdpolesp;	
	private String valorfilme;
	private String valorrec;
	private String troco;
	private String valorfinal;
	private String cartao;
	
	public int getNumIng() {
		return numIng;
	}
	public void setNumIng(int numIng) {
		this.numIng = numIng;
	}
	public String getNomesessao() {
		return nomesessao;
	}
	public void setNomesessao(String nomesessao) {
		this.nomesessao = nomesessao;
	}
	public String getNomefilme() {
		return nomefilme;
	}
	public void setNomefilme(String nomefilme) {
		this.nomefilme = nomefilme;
	}
	public String getNomedesc() {
		return nomedesc;
	}
	public void setNomedesc(String nomedesc) {
		this.nomedesc = nomedesc;
	}
	public String getValordesc() {
		return valordesc;
	}
	public void setValordesc(String valordesc) {
		this.valordesc = valordesc;
	}
	public int getQtdpoldisp() {
		return qtdpoldisp;
	}
	public void setQtdpoldisp(int qtdpoldisp) {
		this.qtdpoldisp = qtdpoldisp;
	}
	public int getQtdpolres() {
		return qtdpolres;
	}
	public void setQtdpolres(int qtdpolres) {
		this.qtdpolres = qtdpolres;
	}
	public int getQtdpolesp() {
		return qtdpolesp;
	}
	public void setQtdpolesp(int qtdpolesp) {
		this.qtdpolesp = qtdpolesp;
	}
	public String getValorfilme() {
		return valorfilme;
	}
	public void setValorfilme(String valorfilme) {
		this.valorfilme = valorfilme;
	}
	public String getValorrec() {
		return valorrec;
	}
	public void setValorrec(String valorrec) {
		this.valorrec = valorrec;
	}
	public String getTroco() {
		return troco;
	}
	public void setTroco(String troco) {
		this.troco = troco;
	}
	public String getValorfinal() {
		return valorfinal;
	}
	public void setValorfinal(String valorfinal) {
		this.valorfinal = valorfinal;
	}
	public String getCartao() {
		return cartao;
	}
	public void setCartao(String cartao) {
		this.cartao = cartao;
	}
	@Override
	public String toString() {
		return "Venda [numIng=" + numIng + ", nomesessao=" + nomesessao
				+ ", nomefilme=" + nomefilme + ", nomedesc=" + nomedesc
				+ ", valordesc=" + valordesc + ", qtdpoldisp=" + qtdpoldisp
				+ ", qtdpolres=" + qtdpolres + ", qtdpolesp=" + qtdpolesp
				+ ", valorfilme=" + valorfilme + ", valorrec=" + valorrec
				+ ", troco=" + troco + ", valorfinal=" + valorfinal
				+ ", cartao=" + cartao + "]";
	}
	


}
