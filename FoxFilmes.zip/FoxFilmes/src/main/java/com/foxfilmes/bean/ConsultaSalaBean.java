package com.foxfilmes.bean;

import java.util.Optional;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Sala;
import com.foxfilmes.model.SalaJson;
import com.foxfilmes.repository.SalaRepository;

public class ConsultaSalaBean {
	
	@Autowired
	private SalaRepository salaRepository;
	
	public static final String SALA = "salas";
	public static final String ID_SALA = "id_sala";
	
	public void formatarEntrada(Exchange exchange) {
		
		Sala sala = new Sala();
		
		SalaJson salaJson = exchange.getIn().getBody(SalaJson.class);
		
		String idSala = exchange.getIn().getHeader(ID_SALA, String.class);
		
		sala.setIdSala(salaJson.getIdSala());
		sala.setNomeSala(salaJson.getNomeSala());
		sala.setQtdPoltrona(salaJson.getQtdPoltrona());
		sala.setQtdPoltronaDisp(salaJson.getQtdPoltronaDisp());
		sala.setQtdPoltronaReser(salaJson.getQtdPoltronaReser());
		sala.setQtdPoltronaEspecial(salaJson.getQtdPoltronaEspecial());
		
		exchange.setProperty(ID_SALA, idSala);
		exchange.setProperty(SALA, sala);
		
		exchange.getOut().setBody(sala);
	}
	
	public void formatarSaida(Exchange exchange) {
		
		SalaJson salaJson = new SalaJson();
		
		Long idSala = Long.parseLong((String) exchange.getProperty("id_sala"));
		Optional<Sala> sala = salaRepository.findById(idSala);
		
		salaJson.setIdSala(sala.get().getIdSala());
		salaJson.setNomeSala(sala.get().getNomeSala());
		salaJson.setQtdPoltrona(sala.get().getQtdPoltrona());
		salaJson.setQtdPoltronaDisp(sala.get().getQtdPoltronaDisp());
		salaJson.setQtdPoltronaReser(sala.get().getQtdPoltronaReser());
		salaJson.setQtdPoltronaEspecial(sala.get().getQtdPoltronaEspecial());
		
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK);
		exchange.getOut().setBody(salaJson);
			
	}

}
