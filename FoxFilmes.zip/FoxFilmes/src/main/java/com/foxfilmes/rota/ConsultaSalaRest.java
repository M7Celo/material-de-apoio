package com.foxfilmes.rota;

import org.apache.camel.builder.RouteBuilder;
//import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class ConsultaSalaRest extends RouteBuilder{
	
	public static final String REST_ROUTE = "/salas/{id_sala}";
	public static final String REST_ROUTE_ID = "get-salas-rest";

	@Override
	public void configure() throws Exception {
		
		rest(REST_ROUTE)
			.get()
				.consumes(MediaType.APPLICATION_JSON_UTF8_VALUE)
					.route()
						.routeId(REST_ROUTE_ID)
						.routeDescription("Consulta de Salas")
							.doTry()
								.to(ConsultaSalaRota.ROUTE)
							.endDoTry()
							.doCatch(Exception.class)
			.end();
//				.marshal()
//				.json(JsonLibrary.Jackson);
	}

}
