package com.foxfilmes.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "sessao")
public class Sessao implements Serializable{

	private static final long serialVersionUID = 8872227278292501862L;
	
	@Id
	@NotNull
	@NotEmpty
	@Column(name="id_sessao")
	private Long idSessao;
	
	@NotNull
	@NotEmpty
	@Column(name="nome_sessao")
	private String nomeSessao;
	
	@NotNull
	@NotEmpty
	@Column(name="horario_inicial")
	private LocalDateTime horarioInicial;
	
	@NotNull
	@NotEmpty
	@Column(name="horario_final")
	private LocalDateTime horarioFinal;
	
	@NotNull
	@NotEmpty
	@Column(name="sala")
	private Sala sala;
	
	@NotNull
	@NotEmpty
	@Column(name="filmes")
	private Filmes filmes;

	public Sessao() {
		super();
	}

	public Sessao(Long idSessao, @NotNull @NotEmpty String nomeSessao, @NotNull @NotEmpty LocalDateTime horarioInicial,
			@NotNull @NotEmpty LocalDateTime horarioFinal, @NotNull @NotEmpty Sala sala,
			@NotNull @NotEmpty Filmes filmes) {
		super();
		this.idSessao = idSessao;
		this.nomeSessao = nomeSessao;
		this.horarioInicial = horarioInicial;
		this.horarioFinal = horarioFinal;
		this.sala = sala;
		this.filmes = filmes;
	}

	public Long getIdSessao() {
		return idSessao;
	}

	public void setIdSessao(Long idSessao) {
		this.idSessao = idSessao;
	}

	public String getNomeSessao() {
		return nomeSessao;
	}

	public void setNomeSessao(String nomeSessao) {
		this.nomeSessao = nomeSessao;
	}

	public LocalDateTime getHorarioInicial() {
		return horarioInicial;
	}

	public void setHorarioInicial(LocalDateTime horarioInicial) {
		this.horarioInicial = horarioInicial;
	}

	public LocalDateTime getHorarioFinal() {
		return horarioFinal;
	}

	public void setHorarioFinal(LocalDateTime horarioFinal) {
		this.horarioFinal = horarioFinal;
	}

	public Sala getSala() {
		return sala;
	}

	public void setSala(Sala sala) {
		this.sala = sala;
	}

	public Filmes getFilmes() {
		return filmes;
	}

	public void setFilmes(Filmes filmes) {
		this.filmes = filmes;
	}

	@Override
	public String toString() {
		return "Sessao [idSessao=" + idSessao + ", nomeSessao=" + nomeSessao + ", horarioInicial=" + horarioInicial
				+ ", horarioFinal=" + horarioFinal + ", sala=" + sala + ", filmes=" + filmes + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idSessao == null) ? 0 : idSessao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sessao other = (Sessao) obj;
		if (idSessao == null) {
			if (other.idSessao != null)
				return false;
		} else if (!idSessao.equals(other.idSessao))
			return false;
		return true;
	}
	
}
