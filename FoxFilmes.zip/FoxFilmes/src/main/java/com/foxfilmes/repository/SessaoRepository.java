package com.foxfilmes.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.foxfilmes.entity.Sessao;

@Repository
@Transactional
public interface SessaoRepository extends CrudRepository<Sessao, Long>{

}
