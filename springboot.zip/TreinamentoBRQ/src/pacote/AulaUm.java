package pacote;

import java.util.Scanner;

public class AulaUm {

	String nome;
	int idade;
	String email;
	boolean isEstudante;
	String estudante;

	Scanner scanner = new Scanner(System.in);

	public AulaUm() {

		System.out.println("Digite o nome:");
		nome = scanner.next();

		System.out.println("Digite a idade:");
		idade = Integer.parseInt(scanner.next());

		System.out.println("Digite o e-mail:");
		email = scanner.next();

		System.out.println("� estudante:");
		estudante = scanner.next();

		// verifica nome
		if (nome.length() < 4) {
			System.out.println("O campo 'nome' deve conter o m�nimo de 4 caracteres!");
		} else if (nome.isEmpty()) {
			System.out.println("O campo 'nome' n�o pode ser vazio");
		} else {
			System.out.println("O nome �: " + nome);
		}

		// verifica idade
		if (idade == 0) {
			System.out.println("o campo 'idade' n�o pode ser zero!");
		} else {
			System.out.println("A idade �: " + idade);
		}

		// verifica e-mail
		if (email.contains("@")) {
			System.out.println("O e-mail �: " + email);
		} else {
			System.out.println("Digite um e-mail v�lido!");
		}

		// verifica estudante
		if (estudante == "sim" || estudante == "SIM" || estudante == "Sim") {
			isEstudante = true;
		} else {
			isEstudante = false;
		}
	}

	public static void main(String[] args) {
		new AulaUm();
	}
}
