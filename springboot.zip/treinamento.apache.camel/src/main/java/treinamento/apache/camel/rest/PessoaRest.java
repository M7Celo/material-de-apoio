package treinamento.apache.camel.rest;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class PessoaRest extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		rest("/pessoas")
		.get()
		.produces(MediaType.APPLICATION_JSON_VALUE)
		.route()
		.routeId("lista-pessoas")
		.routeDescription("Lista de Pessoas")
		.to("direct:lista-pessoas-route")
		.marshal().json(JsonLibrary.Jackson)
		.end();
	}

}
