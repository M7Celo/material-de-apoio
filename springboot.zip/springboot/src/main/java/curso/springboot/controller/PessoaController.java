package curso.springboot.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import curso.springboot.model.Pessoa;
import curso.springboot.model.Telefone;
import curso.springboot.repository.PessoaRepository;
import curso.springboot.repository.TelefoneRepository;

@Controller
public class PessoaController {

	@Autowired
	private PessoaRepository pessoaRepository;

	@Autowired
	private TelefoneRepository telefoneRepository;

	@RequestMapping(method = RequestMethod.GET, value = "/cadastropessoa")
	public ModelAndView inicio() {
		ModelAndView modelAndView = new ModelAndView("cadastro/cadastropessoa");
		modelAndView.addObject("pessoaobj", new Pessoa());
		Iterable<Pessoa> pessoasIterable = pessoaRepository.findAll();
		modelAndView.addObject("pessoas", pessoasIterable);
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.POST, value = "**/salvarpessoa")
	public ModelAndView create(@Valid Pessoa pessoa, BindingResult bindingResult) {
		
		if(bindingResult.hasErrors()) {
			ModelAndView modelAndViewValid = new ModelAndView("cadastro/cadastropessoa");
			Iterable<Pessoa> pessoasIterable = pessoaRepository.findAll();
			modelAndViewValid.addObject("pessoas", pessoasIterable);
			modelAndViewValid.addObject("pessoaobj", pessoa);
			
			List<String> listaMsgErros =  new ArrayList<String>();
			for(ObjectError objectError : bindingResult.getAllErrors()) {
				listaMsgErros.add(objectError.getDefaultMessage());
			}
			modelAndViewValid.addObject("listaMsgErros", listaMsgErros);
			return modelAndViewValid;
		}
		pessoaRepository.save(pessoa);
		ModelAndView modelAndView = new ModelAndView("cadastro/cadastropessoa");
		Iterable<Pessoa> pessoasIterable = pessoaRepository.findAll();
		modelAndView.addObject("pessoas", pessoasIterable);
		modelAndView.addObject("pessoaobj", new Pessoa());
		return modelAndView;
	}

	@PostMapping("**/pesquisarpessoa")
	public ModelAndView findByName(@RequestParam("nomepesquisa") String nome) {
		ModelAndView modelAndView = new ModelAndView("cadastro/cadastropessoa");
		modelAndView.addObject("pessoas", pessoaRepository.findByNome(nome));
		modelAndView.addObject("pessoaobj", new Pessoa());
		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/listapessoas")
	public ModelAndView listAll() {
		ModelAndView modelAndView = new ModelAndView("cadastro/cadastropessoa");
		Iterable<Pessoa> pessoasIterable = pessoaRepository.findAll();
		modelAndView.addObject("pessoas", pessoasIterable);
		modelAndView.addObject("pessoaobj", new Pessoa());
		return modelAndView;
	}

	@GetMapping("/editarpessoa/{id}")
	public ModelAndView update(@PathVariable("id") Long id) {
		Optional<Pessoa> pessoa = pessoaRepository.findById(id);
		ModelAndView modelAndView = new ModelAndView("cadastro/cadastropessoa");
		modelAndView.addObject("pessoaobj", pessoa.get());
		return modelAndView;
	}

	@GetMapping("/excluirpessoa/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		pessoaRepository.deleteById(id);
		ModelAndView modelAndView = new ModelAndView("cadastro/cadastropessoa");
		modelAndView.addObject("pessoas", pessoaRepository.findAll());
		modelAndView.addObject("pessoaobj", new Pessoa());
		return modelAndView;
	}

	@GetMapping("/telefones/{id}")
	public ModelAndView telefones(@PathVariable("id") Long id) {
		Pessoa pessoa = pessoaRepository.findById(id).get();
		ModelAndView modelAndView = new ModelAndView("cadastro/telefones");
		modelAndView.addObject("pessoaobj", pessoa);
		modelAndView.addObject("telefones", telefoneRepository.findByPessoaTelefone(pessoa));
		return modelAndView;
	}

	@PostMapping("**/addfonepessoa/{pessoatelid}")
	public ModelAndView addFonePessoa(Telefone telefone, @PathVariable("pessoatelid") Long pessoatelid) {
		Pessoa pessoa = pessoaRepository.findById(pessoatelid).get();
		
			if(telefone != null && telefone.getNumero().isEmpty() || telefone.getTipo().isEmpty()) {		
			
			ModelAndView modelAndView = new ModelAndView("cadastro/telefones");
			modelAndView.addObject("pessoaobj", pessoa);
			modelAndView.addObject("telefones", telefoneRepository.findByPessoaTelefone(pessoa));
			
			List<String> listaMsgErros =  new ArrayList<String>();
			if(telefone.getNumero().isEmpty()) {
				listaMsgErros.add("Número deve ser informado");
			}
			
			if(telefone.getTipo().isEmpty()) {
				listaMsgErros.add("Tipo deve ser informado");
			}
			modelAndView.addObject("listaMsgErros", listaMsgErros);
			return modelAndView;
		}
		
		telefone.setPessoaTelefone(pessoa);
		telefoneRepository.save(telefone);
		ModelAndView modelAndView = new ModelAndView("cadastro/telefones");
		modelAndView.addObject("pessoaobj", pessoa);
		modelAndView.addObject("telefones", telefoneRepository.findByPessoaTelefone(pessoa));
		return modelAndView;
	}
	
	@GetMapping("/excluirtelefone/{idtelefone}")
	public ModelAndView deleteTelefone(@PathVariable("idtelefone") Long idTelefone) {
		Pessoa pessoa = telefoneRepository.findById(idTelefone).get().getPessoaTelefone();
		telefoneRepository.deleteById(idTelefone);
		ModelAndView modelAndView = new ModelAndView("cadastro/telefones");
		modelAndView.addObject("pessoaobj", pessoa);
		modelAndView.addObject("telefones", telefoneRepository.findByPessoaTelefone(pessoa));
		return modelAndView;
	}
}
