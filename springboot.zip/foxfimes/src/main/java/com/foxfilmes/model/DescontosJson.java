package com.foxfilmes.model;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.foxfilmes.entity.Descontos;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id_descontos", "nome_descontos", "valor_descontos" })
public class DescontosJson implements Serializable{

	private static final long serialVersionUID = -3927896264299567898L;
	
	@JsonProperty("id_descontos")
	private Long idDescontos;
	
	@JsonProperty("nome_descontos")
	private String nomeDescontos;
	
	@JsonProperty("valor_descontos")
	private BigDecimal valorDescontos;

	public DescontosJson() {
		super();
	}
	
	public DescontosJson(Descontos descontos) {
		this.idDescontos = descontos.getIdDescontos();
		this.nomeDescontos = descontos.getNomeDescontos();
		this.valorDescontos = descontos.getValorDescontos();
	}

	public DescontosJson(Long idDescontos, String nomeDescontos, BigDecimal valorDescontos) {
		this.idDescontos = idDescontos;
		this.nomeDescontos = nomeDescontos;
		this.valorDescontos = valorDescontos;
	}

	public Long getIdDescontos() {
		return idDescontos;
	}

	public void setIdDescontos(Long idDescontos) {
		this.idDescontos = idDescontos;
	}

	public String getNomeDescontos() {
		return nomeDescontos;
	}

	public void setNomeDescontos(String nomeDescontos) {
		this.nomeDescontos = nomeDescontos;
	}

	public BigDecimal getValorDescontos() {
		return valorDescontos;
	}

	public void setValorDescontos(BigDecimal valorDescontos) {
		this.valorDescontos = valorDescontos;
	}

}
