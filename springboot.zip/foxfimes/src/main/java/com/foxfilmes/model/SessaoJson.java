package com.foxfilmes.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.foxfilmes.entity.Filmes;
import com.foxfilmes.entity.Sala;
import com.foxfilmes.entity.Sessao;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id_sessao", "nome_sessao", "horario_inicial", "horario_final", "sala", "filmes" })
public class SessaoJson implements Serializable{

	private static final long serialVersionUID = 8872227278292501862L;
	
	@JsonProperty("id_sessao")
	private Long idSessao;
	
	@JsonProperty("nome_sessao")
	private String nomeSessao;
	
	@JsonProperty("horario_inicial")
	private LocalDateTime horarioInicial;
	
	@JsonProperty("horario_final")
	private LocalDateTime horarioFinal;
	
	@JsonProperty("sala")
	private SalaJson salaJson;
	
	@JsonProperty("filmes")
	private FilmesJson filmesJson;

	public SessaoJson() {
		super();
	}
	
	public SessaoJson(Sessao sessao, Sala sala, Filmes filmes) {
		this.idSessao = sessao.getIdSessao();
		this.nomeSessao = sessao.getNomeSessao();
		this.horarioInicial = sessao.getHorarioInicial();
		this.horarioFinal = sessao.getHorarioFinal();
		this.salaJson = new SalaJson(sala);
		this.filmesJson = new FilmesJson(filmes);
	}

	public SessaoJson(Long idSessao, @NotNull @NotEmpty String nomeSessao, @NotNull @NotEmpty LocalDateTime horarioInicial,
			@NotNull @NotEmpty LocalDateTime horarioFinal, @NotNull @NotEmpty SalaJson salaJson, @NotNull @NotEmpty FilmesJson filmesJson) {
		super();
		this.idSessao = idSessao;
		this.nomeSessao = nomeSessao;
		this.horarioInicial = horarioInicial;
		this.horarioFinal = horarioFinal;
		this.salaJson = salaJson;
		this.filmesJson = filmesJson;
	}

	public Long getIdSessao() {
		return idSessao;
	}

	public void setIdSessao(Long idSessao) {
		this.idSessao = idSessao;
	}

	public String getNomeSessao() {
		return nomeSessao;
	}

	public void setNomeSessao(String nomeSessao) {
		this.nomeSessao = nomeSessao;
	}

	public LocalDateTime getHorarioInicial() {
		return horarioInicial;
	}

	public void setHorarioInicial(LocalDateTime horarioInicial) {
		this.horarioInicial = horarioInicial;
	}

	public LocalDateTime getHorarioFinal() {
		return horarioFinal;
	}

	public void setHorarioFinal(LocalDateTime horarioFinal) {
		this.horarioFinal = horarioFinal;
	}

	public SalaJson getSala() {
		return salaJson;
	}

	public void setSala(SalaJson salaJson) {
		this.salaJson = salaJson;
	}

	public FilmesJson getFilmes() {
		return filmesJson;
	}

	public void setFilmes(FilmesJson filmesJson) {
		this.filmesJson = filmesJson;
	}
	
}
