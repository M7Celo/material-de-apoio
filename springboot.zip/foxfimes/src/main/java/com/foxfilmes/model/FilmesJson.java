package com.foxfilmes.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.foxfilmes.entity.Filmes;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id_filme", "nome_filme", "categoria_filme", "produtora_filme", "data_lancamento", 
	"exibicao_ate", "pais_origem", "idioma", "classificao_etaria", "dublado", "legendado", "fora_exibicao" })
public class FilmesJson implements Serializable{

	private static final long serialVersionUID = -5718677679400423281L;

	@JsonProperty("id_filme")
	private Long idFilme;
	
	@JsonProperty("nome_filme")
	private String nomeFilme;
	
	@JsonProperty("categoria_filme")
	private String categoriaFilme;
	
	@JsonProperty("produtora_filme")
	private String produtoraFilme;
	
	@JsonProperty("data_lancamento")
	private Date dataLancamento;
	
	@JsonProperty("exibicao_ate")
	private Date exibicaoAte;
	
	@JsonProperty("pais_origem")
	private String paisOrigem;
	
	@JsonProperty("idioma")
	private String idioma;
	
	@JsonProperty("classificao_etaria")
	private String classificaoEtaria;
	
	@JsonProperty("dublado")
	private String dublado;
	
	@JsonProperty("legendado")
	private String legendado;
	
	@JsonProperty("fora_exibicao")
	private String foraExibicao;

	public FilmesJson() {
		super();
	}
	
	public FilmesJson(Filmes filmes) {
		this.idFilme = filmes.getIdFilme();
		this.nomeFilme = filmes.getNomeFilme();
		this.categoriaFilme = filmes.getCategoriaFilme();
		this.produtoraFilme = filmes.getProdutoraFilme();
		this.dataLancamento = filmes.getDataLancamento();
		this.exibicaoAte = filmes.getExibicaoAte();
		this.paisOrigem = filmes.getPaisOrigem();
		this.idioma = filmes.getIdioma();
		this.classificaoEtaria = filmes.getClassificaoEtaria();
		this.dublado = filmes.getDublado();
		this.legendado = filmes.getLegendado();
		this.foraExibicao = filmes.getForaExibicao();
	}

	public FilmesJson(Long idFilme, String nomeFilme, String categoriaFilme, String produtoraFilme, Date dataLancamento,
			Date exibicaoAte, String paisOrigem, String idioma, String classificaoEtaria, String dublado,
			String legendado, String foraExibicao) {
		super();
		this.idFilme = idFilme;
		this.nomeFilme = nomeFilme;
		this.categoriaFilme = categoriaFilme;
		this.produtoraFilme = produtoraFilme;
		this.dataLancamento = dataLancamento;
		this.exibicaoAte = exibicaoAte;
		this.paisOrigem = paisOrigem;
		this.idioma = idioma;
		this.classificaoEtaria = classificaoEtaria;
		this.dublado = dublado;
		this.legendado = legendado;
		this.foraExibicao = foraExibicao;
	}
	
	public Long getIdFilme() {
		return idFilme;
	}

	public void setIdFilme(Long idFilme) {
		this.idFilme = idFilme;
	}

	public String getNomeFilme() {
		return nomeFilme;
	}

	public void setNomeFilme(String nomeFilme) {
		this.nomeFilme = nomeFilme;
	}

	public String getCategoriaFilme() {
		return categoriaFilme;
	}

	public void setCategoriaFilme(String categoriaFilme) {
		this.categoriaFilme = categoriaFilme;
	}

	public String getProdutoraFilme() {
		return produtoraFilme;
	}

	public void setProdutoraFilme(String produtoraFilme) {
		this.produtoraFilme = produtoraFilme;
	}

	public Date getDataLancamento() {
		return dataLancamento;
	}

	public void setDataLancamento(Date dataLancamento) {
		this.dataLancamento = dataLancamento;
	}

	public Date getExibicaoAte() {
		return exibicaoAte;
	}

	public void setExibicaoAte(Date exibicaoAte) {
		this.exibicaoAte = exibicaoAte;
	}

	public String getPaisOrigem() {
		return paisOrigem;
	}

	public void setPaisOrigem(String paisOrigem) {
		this.paisOrigem = paisOrigem;
	}

	public String getIdioma() {
		return idioma;
	}

	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}

	public String getClassificaoEtaria() {
		return classificaoEtaria;
	}

	public void setClassificaoEtaria(String classificaoEtaria) {
		this.classificaoEtaria = classificaoEtaria;
	}

	public String isDublado() {
		return dublado;
	}

	public void setDublado(String dublado) {
		this.dublado = dublado;
	}

	public String isLegendado() {
		return legendado;
	}

	public void setLegendado(String legendado) {
		this.legendado = legendado;
	}

	public String isForaExibicao() {
		return foraExibicao;
	}

	public void setForaExibicao(String foraExibicao) {
		this.foraExibicao = foraExibicao;
	}
	
}
