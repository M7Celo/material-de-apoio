package com.foxfilmes.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.foxfilmes.entity.Funcionario;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id_funcionario", "nome_funcionario", "login", "senha", "nivel_acesso" })
public class FuncionarioJson implements Serializable{

	private static final long serialVersionUID = 5899462874843384293L;
	
	@JsonProperty("id_funcionario")
	private Long idFuncionario;
	
	@JsonProperty("nome_funcionario")
	private String nomeFuncionario;
	
	@JsonProperty("login")
	private String login;
	
	@JsonProperty("senha")
	private String password;
	
	@JsonProperty("nivel_acesso")
	private String nivelAcesso;

	public FuncionarioJson() {
		super();
	}
	
	public FuncionarioJson(Funcionario funcionario) {
		this.idFuncionario = funcionario.getIdFuncionario();
		this.nomeFuncionario = funcionario.getNomeFuncionario();
		this.login = funcionario.getLogin();
		this.password = funcionario.getPassword();
		this.nivelAcesso = funcionario.getNivelAcesso();
	}

	public FuncionarioJson(Long idFuncionario, String nomeFuncionario, String login, String password, String nivelAcesso) {
		super();
		this.idFuncionario = idFuncionario;
		this.nomeFuncionario = nomeFuncionario;
		this.login = login;
		this.password = password;
		this.nivelAcesso = nivelAcesso;
	}

	public Long getIdFuncionario() {
		return idFuncionario;
	}

	public void setIdFuncionario(Long idFuncionario) {
		this.idFuncionario = idFuncionario;
	}

	public String getNomeFuncionario() {
		return nomeFuncionario;
	}

	public void setNomeFuncionario(String nomeFuncionario) {
		this.nomeFuncionario = nomeFuncionario;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNivelAcesso() {
		return nivelAcesso;
	}

	public void setNivelAcesso(String nivelAcesso) {
		this.nivelAcesso = nivelAcesso;
	}
	
}
