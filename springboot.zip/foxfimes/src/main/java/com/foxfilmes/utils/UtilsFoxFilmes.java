package com.foxfilmes.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.json.JsonSanitizer;

public class UtilsFoxFilmes {
	
	public static final String REST_ERRO = "direct:erro-retorno";
	public static final String REST_ERRO_ID = "direct-erro-retorno";

	public UtilsFoxFilmes() {
		
	}
	
	public static String serializar(Object objeto) throws IOException{
		return new ObjectMapper().writeValueAsString(objeto);
	}
	
	public static String sanitizarJson(String json){
		return JsonSanitizer.sanitize(json);
	}
	
	public static <T> T extrairJson (String content, Class<T> valueType) throws IOException{
		return new ObjectMapper().readValue(sanitizarJson(content), valueType);
	}
	
	public static <T> Collection<T> extrairListaJson(String stringJson, Class<T> classe) throws IOException, JsonParseException, JsonMappingException{		
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readTree(stringJson);
		Collection<T> listaObjetos =  new ArrayList<T>();
		
		for(JsonNode item : jsonNode.elements().next()) {
			if(!item.traverse().toString().isEmpty()) {
				listaObjetos.add(objectMapper.readValue(item.traverse(), classe));
			}
		}
		return listaObjetos;
	}

}