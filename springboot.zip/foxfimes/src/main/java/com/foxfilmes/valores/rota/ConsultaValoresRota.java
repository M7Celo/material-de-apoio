package com.foxfilmes.valores.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.ConsultaValoresBean;

@Component
public class ConsultaValoresRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:get-valores";
	public static final String ROUTE_ID = "direct-get-valores";

	@Override
	public void configure() throws Exception {
		
		from(ROUTE)
		.routeId(ROUTE_ID)
			.bean(ConsultaValoresBean.class, "formatarEntrada")
			.bean(ConsultaValoresBean.class, "formatarSaida")
			.marshal().json(JsonLibrary.Jackson)
	.end();	
		
	}

}
