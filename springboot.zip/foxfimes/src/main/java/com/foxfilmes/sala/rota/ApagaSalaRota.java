package com.foxfilmes.sala.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.ApagaSalaBean;

@Component
public class ApagaSalaRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:delete-sala";
	public static final String ROUTE_ID = "direct-delete-sala";

	@Override
	public void configure() throws Exception {
		
		from(ROUTE)
		.routeId(ROUTE_ID)
			.bean(ApagaSalaBean.class, "formatarEntrada")
			.bean(ApagaSalaBean.class, "formatarSaida")
			.marshal().json(JsonLibrary.Jackson)
	.end();	
		
	}

}
