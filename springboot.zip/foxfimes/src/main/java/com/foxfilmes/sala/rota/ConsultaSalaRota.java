package com.foxfilmes.sala.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.ConsultaSalaBean;

@Component
public class ConsultaSalaRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:get-sala";
	public static final String ROUTE_ID = "direct-get-sala";
	
	@Override
	public void configure() throws Exception {
				
		from(ROUTE)
			.routeId(ROUTE_ID)
				.bean(ConsultaSalaBean.class, "formatarEntrada")
				.bean(ConsultaSalaBean.class, "formatarSaida")
				.marshal().json(JsonLibrary.Jackson)
		.end();		
	}

}
