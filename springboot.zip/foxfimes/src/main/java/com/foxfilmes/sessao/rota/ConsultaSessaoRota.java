package com.foxfilmes.sessao.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.ConsultaSessaoBean;

@Component
public class ConsultaSessaoRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:get-sessao";
	public static final String ROUTE_ID = "direct-get-sessao";

	@Override
	public void configure() throws Exception {
		
		from(ROUTE)
		.routeId(ROUTE_ID)
			.bean(ConsultaSessaoBean.class, "formatarEntrada")
			.bean(ConsultaSessaoBean.class, "formatarSaida")
			.marshal().json(JsonLibrary.Jackson)
	.end();
		
	}

}
