package com.foxfilmes.funcionario.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.ConsultaDescontosBean;

@Component
public class ConsultaFuncionarioRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:get-funcionario";
	public static final String ROUTE_ID = "direct-get-funcionario";

	@Override
	public void configure() throws Exception {
		
		from(ROUTE)
		.routeId(ROUTE_ID)
			.bean(ConsultaDescontosBean.class, "formatarEntrada")
			.bean(ConsultaDescontosBean.class, "formatarSaida")
			.marshal().json(JsonLibrary.Jackson)
	.end();
		
	}

}
