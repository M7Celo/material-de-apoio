package com.foxfilmes.filmes.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.ConsultaFilmesBean;

@Component
public class ConsultaFilmesRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:get-filmes";
	public static final String ROUTE_ID = "direct-get-filmes";

	@Override
	public void configure() throws Exception {
		
		from(ROUTE)
		.routeId(ROUTE_ID)
			.bean(ConsultaFilmesBean.class, "formatarEntrada")
			.bean(ConsultaFilmesBean.class, "formatarSaida")
			.marshal().json(JsonLibrary.Jackson)
	.end();	
		
	}

}
