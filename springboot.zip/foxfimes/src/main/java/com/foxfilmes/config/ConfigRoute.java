package com.foxfilmes.config;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigRoute extends RouteBuilder{

	@SuppressWarnings("rawtypes")
	@Bean
	protected ServletRegistrationBean camelServletRegistrationBean() {
		@SuppressWarnings("unchecked")
		ServletRegistrationBean registration = new ServletRegistrationBean(new CamelHttpTransportServlet(),"/foxfilmes/*");
		registration.setName("CamelServlet");
		return registration;
	}

	@Override
	public void configure() throws Exception {
		
		restConfiguration()
		.component("servlet")
//		.contextPath(contextPath)
//		.host(host)
//        .port(port)
		.apiProperty("cors", "true")
        .enableCORS(true); 
		
	}

}