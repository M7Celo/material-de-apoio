package com.foxfilmes.descontos.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.ConsultaFuncionarioBean;

@Component
public class ConsultaDescontosRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:get-descontos";
	public static final String ROUTE_ID = "direct-get-descontos";

	@Override
	public void configure() throws Exception {
		
		from(ROUTE)
		.routeId(ROUTE_ID)
			.bean(ConsultaFuncionarioBean.class, "formatarEntrada")
			.bean(ConsultaFuncionarioBean.class, "formatarSaida")
			.marshal().json(JsonLibrary.Jackson)
	.end();	
		
	}

}
