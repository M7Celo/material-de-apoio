package com.foxfilmes.venda.rota;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class ConsultaVendaIngressosRest extends RouteBuilder{
	
	public static final String REST_ROUTE = "/vendas/{id_venda}";
	public static final String REST_ROUTE_ID = "get-vendas-rest";
	
	@Override
	public void configure() throws Exception {
		
		rest(REST_ROUTE)
		.get()
			.produces(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.route()
					.routeId(REST_ROUTE_ID)
					.routeDescription("Consulta de Vendas")
						.doTry()
							.to(ConsultaVendaIngressosRota.ROUTE)
						.endDoTry()
						.doCatch(Exception.class)
		.end();
		
	}

}
