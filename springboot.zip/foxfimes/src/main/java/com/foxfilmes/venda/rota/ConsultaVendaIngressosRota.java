package com.foxfilmes.venda.rota;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

import com.foxfilmes.bean.ConsultaVendaIngressoBean;

@Component
public class ConsultaVendaIngressosRota extends RouteBuilder{
	
	public static final String ROUTE = "direct:get-vendas";
	public static final String ROUTE_ID = "direct-get-vendas";

	@Override
	public void configure() throws Exception {
		
		from(ROUTE)
		.routeId(ROUTE_ID)
			.bean(ConsultaVendaIngressoBean.class, "formatarEntrada")
			.bean(ConsultaVendaIngressoBean.class, "formatarSaida")
			.marshal().json(JsonLibrary.Jackson)
	.end();	
		
	}

}
