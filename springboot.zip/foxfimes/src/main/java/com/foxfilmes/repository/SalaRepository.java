package com.foxfilmes.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.foxfilmes.entity.Sala;

@Repository
@Transactional
public interface SalaRepository extends CrudRepository<Sala, Long>{
	 
	Sala findByIdSala(Long idSala);

}
