package com.foxfilmes.bean;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Filmes;
import com.foxfilmes.entity.Valores;
import com.foxfilmes.model.ValoresJson;
import com.foxfilmes.repository.FilmesRepository;
import com.foxfilmes.repository.ValoresRepository;

public class ConsultaValoresBean {
	
	@Autowired
	private ValoresRepository valoresRepository;
	
	@Autowired
	private FilmesRepository filmesRepository;
	
	public static final String VALORES = "valores";
	public static final String ID_VALORES = "id_valores";
	
	public static final String FILME = "filmes";
	
	public void formatarEntrada(Exchange exchange) {
		
		Long idValores = exchange.getIn().getHeader(ID_VALORES, Long.class);
		
		Valores valores = valoresRepository.findByIdValores(idValores);
		
		Filmes filme = filmesRepository.findByIdFilme(valores.getFilme().getIdFilme());
		
		exchange.setProperty(FILME, filme);
		
		exchange.setProperty(VALORES, valores);
		exchange.getOut().setBody(valores);		
	}
	
	public void formatarSaida(Exchange exchange) {
		
		ValoresJson valoresJson = new ValoresJson(exchange.getProperty(VALORES, Valores.class), exchange.getProperty(FILME, Filmes.class));
		
		exchange.getOut().setBody(valoresJson);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());		
	}

}
