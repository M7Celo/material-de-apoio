package com.foxfilmes.bean;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Filmes;
import com.foxfilmes.model.FilmesJson;
import com.foxfilmes.repository.FilmesRepository;

public class ConsultaFilmesBean {
	
	@Autowired
	private FilmesRepository filmesRepository;
	
	public static final String FILMES = "filmes";
	public static final String ID_FILME = "id_filmes";
	
	public void formatarEntrada(Exchange exchange) {
		
		Long idFilme = exchange.getIn().getHeader(ID_FILME, Long.class);
		
		Filmes filmes = filmesRepository.findByIdFilme(idFilme);
		
		exchange.setProperty(FILMES, filmes);
		exchange.getOut().setBody(filmes);		
	}
	
	public void formatarSaida(Exchange exchange) {
		
		FilmesJson filmesJson = new FilmesJson(exchange.getProperty(FILMES, Filmes.class));
		
		exchange.getOut().setBody(filmesJson);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());
	}

}
