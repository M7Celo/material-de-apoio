package com.foxfilmes.bean;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Descontos;
import com.foxfilmes.model.DescontosJson;
import com.foxfilmes.repository.DescontosRepository;

public class ConsultaDescontosBean {
	
	@Autowired
	private DescontosRepository descontosRepository;
	
	public static final String DESCONTOS = "descontos";
	public static final String ID_DESCONTOS = "id_descontos";
	
	public void formatarEntrada(Exchange exchange) {
		
		Long idDesconto = exchange.getIn().getHeader(ID_DESCONTOS, Long.class);
		
		Descontos descontos = descontosRepository.findByIdDescontos(idDesconto);
		
		exchange.setProperty(DESCONTOS, descontos);
		exchange.getOut().setBody(descontos);		
	}

	public void formatarSaida(Exchange exchange) {
		
		DescontosJson descontosJson = new DescontosJson(exchange.getProperty(DESCONTOS, Descontos.class));
		
		exchange.getOut().setBody(descontosJson);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());
	}
}
