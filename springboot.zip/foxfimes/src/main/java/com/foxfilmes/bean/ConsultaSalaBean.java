package com.foxfilmes.bean;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Sala;
import com.foxfilmes.model.SalaJson;
import com.foxfilmes.repository.SalaRepository;

public class ConsultaSalaBean {
	
	@Autowired
	private SalaRepository salaRepository;
	
	public static final String SALA = "salas";
	public static final String ID_SALA = "id_sala";
	
	public void formatarEntrada(Exchange exchange) {
		
		Long idSala = exchange.getIn().getHeader(ID_SALA, Long.class);
		
		Sala sala = salaRepository.findByIdSala(idSala);
		
		exchange.setProperty(SALA, sala);
		exchange.getOut().setBody(sala);
	}
	
	public void formatarSaida(Exchange exchange) {

		SalaJson salaJson = new SalaJson(exchange.getProperty(SALA, Sala.class));
			
		exchange.getOut().setBody(salaJson);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());		
	}

}
