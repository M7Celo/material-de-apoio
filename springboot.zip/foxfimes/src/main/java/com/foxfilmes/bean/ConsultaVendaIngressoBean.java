package com.foxfilmes.bean;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.foxfilmes.entity.Descontos;
import com.foxfilmes.entity.Filmes;
import com.foxfilmes.entity.Sala;
import com.foxfilmes.entity.Sessao;
import com.foxfilmes.entity.Valores;
import com.foxfilmes.entity.VendaIngressos;
import com.foxfilmes.model.VendaIngressosJson;
import com.foxfilmes.repository.DescontosRepository;
import com.foxfilmes.repository.FilmesRepository;
import com.foxfilmes.repository.SalaRepository;
import com.foxfilmes.repository.SessaoRepository;
import com.foxfilmes.repository.ValoresRepository;
import com.foxfilmes.repository.VendaIngressoRepository;

public class ConsultaVendaIngressoBean {
	
	@Autowired
	private VendaIngressoRepository vendaIngressoRepository;
	
	@Autowired
	private SessaoRepository sessaoRepository;
	
	@Autowired
	private FilmesRepository filmesRepository;
	
	@Autowired
	private DescontosRepository descontosRepository;
	
	@Autowired
	private SalaRepository salaRepository;
	
	@Autowired
	private ValoresRepository valoresRepository;
	
	public static final String VENDA = "venda";
	public static final String ID_VENDA = "id_venda";
	
	public static final String SESSAO = "sessao";	
	public static final String FILME = "filmes";
	public static final String DESCONTOS = "descontos";
	public static final String SALA = "salas";
	public static final String VALORES = "valores";
	
	public void formatarEntrada(Exchange exchange) {
		
		Long idVenda = exchange.getIn().getHeader(ID_VENDA, Long.class);
		
		VendaIngressos venda = vendaIngressoRepository.findByIdVenda(idVenda);
		
		Sessao sessao = sessaoRepository.findByIdSessao(venda.getSessao().getIdSessao());
		Filmes filme = filmesRepository.findByIdFilme(venda.getFilmes().getIdFilme());
		Descontos descontos = descontosRepository.findByIdDescontos(venda.getDescontos().getIdDescontos());
		Sala sala = salaRepository.findByIdSala(venda.getSala().getIdSala());
		Valores valores = valoresRepository.findByIdValores(venda.getValores().getIdValores());
		
		exchange.setProperty(SESSAO, sessao);
		exchange.setProperty(FILME, filme);
		exchange.setProperty(DESCONTOS, descontos);
		exchange.setProperty(SALA, sala);
		exchange.setProperty(VALORES, valores);		
		
		exchange.setProperty(VENDA, venda);
		exchange.getOut().setBody(venda);		
	}
	
	public void formatarSaida(Exchange exchange) {
		
		VendaIngressosJson vendaIngressosJson = new VendaIngressosJson(
				exchange.getProperty(VENDA, VendaIngressos.class), exchange.getProperty(SESSAO, Sessao.class),
				exchange.getProperty(FILME, Filmes.class), exchange.getProperty(DESCONTOS, Descontos.class),
				exchange.getProperty(SALA, Sala.class), exchange.getProperty(VALORES, Valores.class));
		
		exchange.getOut().setBody(vendaIngressosJson);
		exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.OK.value());		
	}

}
