package com.example.algamoney.api.model;

public enum TipoLancamento {
	
	RECEITA,
	DESPESA

}
