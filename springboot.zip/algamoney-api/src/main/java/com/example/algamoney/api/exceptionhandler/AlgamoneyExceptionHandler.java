package com.example.algamoney.api.exceptionhandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class AlgamoneyExceptionHandler extends ResponseEntityExceptionHandler{
	
	@Autowired
	private MessageSource messageSource;
	
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException exception1,
			HttpHeaders httpHeaders, HttpStatus httpStatus, WebRequest webRequest) {
		
		String mensagemUsuario = messageSource.getMessage("mensagem.invalida", null, LocaleContextHolder.getLocale());
		String mensagemDesenvolvedor = exception1.getCause() != null ? exception1.toString()
				: exception1.toString();
		
		List<Erro> erros =  Arrays.asList(new Erro( mensagemUsuario, mensagemDesenvolvedor));
		
		return handleExceptionInternal(exception1, erros, httpHeaders, 
				httpStatus.BAD_REQUEST, webRequest);
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException exception2,
			HttpHeaders httpHeaders, HttpStatus httpStatus, WebRequest webRequest) {
		
		List<Erro> erros = criarListaDeErros(exception2.getBindingResult());
		
		return handleExceptionInternal(exception2, erros, httpHeaders, 
				httpStatus.BAD_REQUEST, webRequest);
	}
	
	@ExceptionHandler({ EmptyResultDataAccessException.class })
	public ResponseEntity<Object> handleEmptyResultDataAccessException(EmptyResultDataAccessException exception3, 
			WebRequest webRequest) {
		
		String mensagemUsuario = messageSource.getMessage("recurso.nao-encontrado", null, LocaleContextHolder.getLocale());
		String mensagemDesenvolvedor = exception3.toString();
		
		List<Erro> erros =  Arrays.asList(new Erro( mensagemUsuario, mensagemDesenvolvedor));
		
		return handleExceptionInternal(exception3, erros, new HttpHeaders(), 
				HttpStatus.NOT_FOUND, webRequest);
	}
	
	@ExceptionHandler({DataIntegrityViolationException.class})
	public ResponseEntity<Object> handleDataIntegrityViolationException(DataIntegrityViolationException exception4, 
			WebRequest webRequest){
		
		String mensagemUsuario = messageSource.getMessage("recurso.operacao-nao-permitida", null, LocaleContextHolder.getLocale());
		String mensagemDesenvolvedor = ExceptionUtils.getRootCauseMessage(exception4);
		
		List<Erro> erros =  Arrays.asList(new Erro( mensagemUsuario, mensagemDesenvolvedor));
		
		return handleExceptionInternal(exception4, erros, new HttpHeaders(), HttpStatus.BAD_REQUEST, webRequest);
		
	}
	
	private List<Erro> criarListaDeErros(BindingResult bindingResult){
		List<Erro> erros = new ArrayList<>();
		
		for(FieldError fieldError : bindingResult.getFieldErrors()) {
		String mensagemUsuario = messageSource.getMessage(fieldError, LocaleContextHolder.getLocale());
		String mensagemDesenvolvedor = fieldError.toString();
		
		erros.add(new Erro( mensagemUsuario, mensagemDesenvolvedor));
		}
		
	return erros;	
	
	}
	
	public static class Erro{
		
		private String mensagemUsuario;
		private String mensagemDesenvolvedor;
		
		public Erro(String mensagemUsuario, String mensagemDesenvolvedor) {
			super();
			this.mensagemUsuario = mensagemUsuario;
			this.mensagemDesenvolvedor = mensagemDesenvolvedor;
		}

		public String getMensagemUsuario() {
			return mensagemUsuario;
		}

		public String getMensagemDesenvolvedor() {
			return mensagemDesenvolvedor;
		}
		
	}

}
