package fox.vendas.ing;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import fox.bean.Descontos;
import fox.bean.Sessao;
import fox.bean.Venda;
import fox.dao.DescontosDao;
import fox.dao.SessaoDao;
import fox.dao.VendaDao;
import fox.exception.DaoException;

public class VendaIng extends JFrame implements ActionListener {

	private JLabel lbcod_filme;
	private JTextField tfcod_filme;
	private JLabel lbnomeSessao;
	private JComboBox cbcodSessao;
	private JLabel lbvalor_rec;
	private JTextField tfvalor_rec;
	private JLabel lbtroco;
	private JTextField tftroco;
	private JLabel lbcod_sessao;
	private JTextField tfcod_sessao;
	private JLabel lbValorRS;
	private JTextField txtValorRs;
	private JLabel lbvalor_desc;
	private JTextField tfvalor_desc;
	private JLabel lbcod_sala;
	private JTextField tfcod_sala;
	private JLabel lbconv;
	private JComboBox cbConv;
	private JLabel lbsind;
	private JComboBox cbSind;
	private JLabel lbpromo;
	private JComboBox cbPromo;
	private JLabel lbdescfixo;
	private JLabel lbnomef;
	private JTextField txtnomeFilme;
	private JComboBox lstdescfixo;
	private JRadioButton rbpolespdf;
	private JRadioButton rbpolreservada;
	private JRadioButton rbNaodesc;
	private JLabel lbcartao;
	private JComboBox lstcartao;
	private JButton btsalvar;
	private JButton btcancelar;
	private JLabel lbnomedesc;
	private JTextField txtnomedesc;
	private SessaoDao sessaodao;
	private Sessao sessao;
	private DescontosDao descontosdao;
	private Descontos descontos;
	private JLabel lbvalorf;
	private JTextField tfvalorf;
	private  int qtdpoldisp;
	private int qtdpolres;
	private int qtdpolesp;
	private double valordesc;
	private double valorFilme;
	private double valorRec ;
	private double valorTroco;
	private double valordescfinal;
	private double valorfinal;
	private String cartao;
	private String rec;
	private VendaDao vendadao;
	private Venda venda;
	
	public VendaIng () {
		
		/* Cria��o de Objetos */
		setTitle("Venda de Ingressos");
		lbcod_filme = new JLabel("Cod_Filme");
		tfcod_filme = new JTextField();
		lbnomeSessao = new JLabel("Sess�o");
		cbcodSessao = new JComboBox();
		lbvalor_rec = new JLabel("Valor Rec.");	
		tfvalor_rec = new JTextField();
		lbtroco = new JLabel("Troco");	
		tftroco = new JTextField ();
		lbcod_sessao = new JLabel("Cod_Sess�o");
		tfcod_sessao = new JTextField ();
		lbValorRS = new JLabel("Valor R$:");		
		txtValorRs = new JTextField();
		lbvalor_desc = new JLabel("Valor Descontos:");
		tfvalor_desc = new JTextField ();
		lbcod_sala = new JLabel("Cod_sala");
		tfcod_sala = new JTextField ();
		lbconv = new JLabel("Conv�nios");
		cbConv = new JComboBox();
		lbsind = new JLabel("Sindicatos");
		cbSind = new JComboBox();
		lbpromo = new JLabel("Promo��es");
		cbPromo = new JComboBox();
		lbdescfixo = new JLabel("Descontos Fixo");
		String[] descfixo = {"10%", "20%", "30%", "40%", "50%(Estudante)", "100%(VIP)"};
		lstdescfixo = new JComboBox(descfixo);
		rbpolespdf = new JRadioButton("Poltrona Especiais D.F");
		rbpolreservada = new JRadioButton("Poltrona Reservada");
		lbcartao = new JLabel("Cart�o");
		String[] cartao = {"cr�dito", "d�bito"};
		lstcartao = new JComboBox(cartao);
		lbnomef = new JLabel("Filme");
		txtnomeFilme = new JTextField();
		lbnomedesc = new JLabel("Descontos");
		txtnomedesc = new JTextField();
		btsalvar = new JButton("Salvar");
		btcancelar = new JButton("Cancelar");
		rbNaodesc = new JRadioButton("Sem Descontos");
		lbvalorf = new JLabel("Valor Filme");
		tfvalorf =new JTextField();
		
		/* Coordenadas */
		setBounds(0, 0, 520, 380);
		lbcod_filme.setBounds(20, 50, 80, 20);
		tfcod_filme.setBounds(84, 50, 80, 20);
		lbnomeSessao.setBounds(20, 10, 80, 20);
		cbcodSessao.setBounds(65, 10, 340, 20);
		lbcod_sessao.setBounds(175, 50, 80, 20);
		lbnomef.setBounds(20,40, 80,20);
		txtnomeFilme.setBounds(60,40,340,20);
		tfcod_sessao.setBounds(180, 50, 80, 20);
		lbValorRS.setBounds(180, 240, 80, 20);
		txtValorRs.setBounds(240, 240, 60, 20);
		lbvalor_desc.setBounds(180, 200, 100, 20);
		tfvalor_desc.setBounds(280, 200, 100, 20);
		lbvalor_rec.setBounds(20, 220, 80, 20);
		tfvalor_rec.setBounds(84, 220, 45, 20);
		lbtroco.setBounds(20, 240, 80, 20);
		tftroco.setBounds(84, 240, 45, 20);
		lbcod_sala.setBounds(345, 50, 80, 25);
		tfcod_sala.setBounds(403, 50, 80, 20);
		lbconv.setBounds(20, 65, 100, 20);
		cbConv.setBounds(85, 65, 310, 20);
		lbsind.setBounds(20, 85, 100, 20);
		cbSind.setBounds(85, 85, 310, 20);
		lbpromo.setBounds(20, 105, 100, 20);
		cbPromo.setBounds(85, 105, 310, 20);
		lbnomedesc.setBounds(20, 130, 80, 20);
		txtnomedesc.setBounds(85, 130, 310, 20);
		rbNaodesc.setBounds(20, 155, 150, 20);
		lbdescfixo.setBounds(20, 180, 150, 20);
		lstdescfixo.setBounds(118, 180, 120, 20);
		rbpolespdf.setBounds(300,  150, 170, 20);
		rbpolreservada.setBounds(300,  175, 170, 20);
		lbcartao.setBounds(180,  220, 80, 20);
		lstcartao.setBounds(220,  220, 70, 20);
		btsalvar.setBounds(20,  280, 90, 25);
		btcancelar.setBounds(400,  280, 90, 25);
		lbvalorf.setBounds(20, 200, 80, 20);
		tfvalorf.setBounds(85, 200, 45, 20);
		
		sessaodao = new SessaoDao();
		sessao = new Sessao();
		descontosdao = new DescontosDao();
		descontos = new Descontos();
		
		cbcodSessao.addActionListener(this);
		cbConv.addActionListener(this);
		cbSind.addActionListener(this);
		cbPromo.addActionListener(this);
		rbNaodesc.addActionListener(this);
		rbpolespdf.addActionListener(this);
		rbpolreservada.addActionListener(this);
		btsalvar.addActionListener(this);
		lstdescfixo.addActionListener(this);
		lstcartao.addActionListener(this);
		
		/* Execu��o da Tela */
		add(lbnomeSessao);
		add(cbcodSessao);
		add(lbValorRS);
		add(txtValorRs);
		add(lbvalor_rec);
		add(tfvalor_rec);
		add(lbvalor_desc);
		add(tfvalor_desc);
		add(lbtroco);
		add(tftroco);
		add(lbnomedesc);
		add(txtnomedesc);
		add(lbconv);
		add(cbConv);
		add(lbsind);
		add(cbSind);
		add(lbpromo);
		add(cbPromo);
		add(lbdescfixo);
		add(lstdescfixo);
		add(rbpolespdf);
		add(rbpolreservada);
		add(lbcartao);
		add(lstcartao);
		add(btsalvar);
		add(btcancelar);
		add(txtnomeFilme);
		add(lbnomef);
		add(rbNaodesc);
		add(lbvalorf);
		add(tfvalorf);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		try {
			List<Sessao> lista = sessaodao.buscarTodos();
		
			for (Sessao sessao : lista) {
				cbcodSessao.addItem(sessao.getCodigoSessao() + " - " +sessao.getNomeSessao()); 
			}				
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
		
		try {
			List<Descontos> listad = this.descontosdao.buscarTodos();
			
			for(Descontos d : listad){
				cbConv.addItem(d.getCodDescontos() + " - " + d.getNomeConvenio() + " - " + d.getValorConvenio());
				cbSind.addItem(d.getCodDescontos() + " - " + d.getNomeSind()+ " - " + d.getValorSind());
				cbPromo.addItem(d.getCodDescontos() + " - " + d.getNomePromo()+  " - " + d.getValorPromo());
			}		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {			
			if (event.getSource() == this.cbcodSessao) {
				String item = String.valueOf(cbcodSessao.getSelectedItem());
				item = item.substring(0, item.indexOf("-")).trim();
				
				int codSessao = Integer.parseInt(item);
				sessao = this.sessaodao.buscarPorId(codSessao);
				
				txtnomeFilme.setText(sessao.getNomeFilme());
				
				tfvalorf.setText(String.valueOf(sessao.getValorFilme()));
				valorFilme = Double.parseDouble(sessao.getValorFilme());
				txtValorRs.setText(String.valueOf(valorFilme));
			}
			
			if (event.getSource() == this.cbConv) {
				String item = String.valueOf(cbConv.getSelectedItem());
				item = item.substring(0, item.indexOf("-")).trim();
				
				int coddesc = Integer.parseInt(item);
				descontos = this.descontosdao.buscarPorId(coddesc);
				
				txtnomedesc.setText(descontos.getNomeConvenio());
				tfvalor_desc.setText(descontos.getValorConvenio());
				String valordescC = descontos.getValorConvenio();
					if(valordescC == "5%"){
					valordesc = 5;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "10%"){
					valordesc = 10;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "15%"){
					valordesc = 15;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "20%"){
					valordesc = 20;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "25%"){
					valordesc = 25;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "30%"){
					valordesc = 30;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "35%"){
					valordesc = 35;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "40%"){
					valordesc = 40;	
					valordescfinal = (valorFilme/100) * valordesc;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "45%"){
					valordesc = 45;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}else if(valordescC == "50%"){
					valordesc = 50;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
					}
				}
			if (event.getSource() == this.cbSind) {
				String item = String.valueOf(cbSind.getSelectedItem());
				item = item.substring(0, item.indexOf("-")).trim();
				
				int coddesc = Integer.parseInt(item);
				descontos = this.descontosdao.buscarPorId(coddesc);
				
				txtnomedesc.setText(descontos.getNomeSind());
				tfvalor_desc.setText(descontos.getValorSind());
				String valordescS = descontos.getValorSind();
				if(valordescS == "5%"){
					valordesc = 5;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}else if(valordescS == "10%"){
					valordesc = 10;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescS == "15%"){
					valordesc = 15;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescS == "20%"){
					valordesc = 20;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescS == "25%"){
					valordesc = 25;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescS == "30%"){
					valordesc = 30;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescS == "35%"){
					valordesc = 35;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescS == "40%"){
					valordesc = 40;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescS == "45%"){
					valordesc = 45;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescS == "50%"){
					valordesc = 50;	
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				
			}
			if (event.getSource() == this.cbPromo) {
				String item = String.valueOf(cbPromo.getSelectedItem());
				item = item.substring(0, item.indexOf("-")).trim();
				
				int coddesc = Integer.parseInt(item);
				descontos = this.descontosdao.buscarPorId(coddesc);
				
				txtnomedesc.setText(descontos.getNomePromo());
				tfvalor_desc.setText(descontos.getValorPromo());
				String valordescP = descontos.getValorPromo();
				if(valordescP == "5%"){
					valordesc = 5;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}else if(valordescP == "10%"){
					valordesc = 10;
					valordescfinal = (valorFilme/100) * valordesc;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescP == "15%"){
					valordesc = 15;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescP == "20%"){
					valordesc = 20;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescP == "25%"){
					valordesc = 25;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescP == "30%"){
					valordesc = 30;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescP == "35%"){
					valordesc = 35;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescP == "40%"){
					valordesc = 40;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescP == "45%"){
					valordesc = 45;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
				else if(valordescP == "50%"){
					valordesc = 50;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}
			}
			if(event.getSource() == this.lstdescfixo){
				String descfixo = String.valueOf(lstdescfixo.getSelectedItem());
				tfvalor_desc.setText(descfixo);
				String desc = descfixo;
				if(desc == "10%"){
					valordesc = 10;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}else if(desc == "20%"){
					valordesc = 20;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}else if(desc == "30%"){
					valordesc = 30;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}else if(desc == "40%"){
					valordesc = 40;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}else if(desc == "50%(Estudante)"){
					valordesc = 50;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}else if(desc == "100%(VIP)"){
					valordesc = 100;
					valordescfinal = (valorFilme/100) * valordesc;
					valorfinal = valorFilme - valordescfinal;
					txtValorRs.setText(String.valueOf(valorfinal));
				}	
			}
			if(event.getSource() == this.rbNaodesc){
				txtnomedesc.setText("");
				tfvalor_desc.setText("");
				valordescfinal = 0;
			}
			if(event.getSource() == this.rbpolreservada){
				String item = String.valueOf(cbcodSessao.getSelectedItem());
				item = item.substring(0, item.indexOf("-")).trim();
				
				int codSessao = Integer.parseInt(item);
				sessao = this.sessaodao.buscarPorId(codSessao);
				qtdpolres = 0;
				qtdpolres = sessao.getQtdpolres();
				qtdpolres = qtdpolres - 1;
				if(qtdpolres <0 ){
					JOptionPane.showMessageDialog(this, "N�o h� Poltrona Reservadas dispon�veis!");
				}
			}
			if(event.getSource() == this.rbpolespdf){
				String item = String.valueOf(cbcodSessao.getSelectedItem());
				item = item.substring(0, item.indexOf("-")).trim();
				
				int codSessao = Integer.parseInt(item);
				sessao = this.sessaodao.buscarPorId(codSessao);
				qtdpolesp = 0;
				qtdpolesp = sessao.getQtdpolesp();
				qtdpolesp = qtdpolesp - 1;
				if(qtdpolesp <0 ){
					JOptionPane.showMessageDialog(this, "N�o h� Poltrona Especiais dispon�veis!");
				}
			}
			if(event.getSource() == this.lstcartao){
				cartao = null;
				cartao = String.valueOf(cbcodSessao.getSelectedItem());
				
			}
			valorfinal = valorFilme - valordescfinal;
			if(event.getSource() == btsalvar){
				valorRec = 0.0;
				rec = tfvalor_rec.getText();
				valorRec = Double.parseDouble(rec);
				valorTroco = 0.0;
				valorfinal = valorFilme - valordescfinal;
				valorTroco = (valorRec - valorfinal);
				tftroco.setText(String.valueOf(valorTroco));
				if(valorRec < valorfinal){
					JOptionPane.showMessageDialog(this, "Valor Recebido � Menor que Valor do Ingressos!");
				}
				JOptionPane.showMessageDialog(this, "o Valor de 'Troco' � R$: " +valorTroco+" !");
				qtdpoldisp = 0;
				qtdpoldisp = sessao.getQtdpoldis();
				qtdpoldisp = qtdpoldisp - 1;
						if(qtdpoldisp <0 ){
							JOptionPane.showMessageDialog(this, "N�o h� Poltrona dispon�veis!");
						}
				JOptionPane.showMessageDialog(this, "Quantidade de Poltrona Restantes � " + qtdpoldisp+"!");
				sessaodao = new SessaoDao();
				sessao = new Sessao();
				
				String item = String.valueOf(cbcodSessao.getSelectedItem());
				item = item.substring(0, item.indexOf("-")).trim();
				
				int codSessao = Integer.parseInt(item);
				sessao = this.sessaodao.buscarPorId(codSessao);
				
				sessao.setQtdpoldis(qtdpoldisp);
				sessao.setQtdpolres(qtdpolres);
				sessao.setQtdpolesp(qtdpolres);
				
				sessaodao.salvar(sessao);
				
				
				
				
				vendadao = new VendaDao();
				venda = new Venda();
				
				venda.setNomesessao(cbcodSessao.getSelectedItem().toString());
				venda.setNomefilme(txtnomeFilme.getText());
				venda.setNomedesc(txtnomedesc.getText());
				venda.setValordesc(tfvalor_desc.getText());
				venda.setQtdpoldisp(qtdpoldisp);
				venda.setQtdpolres(qtdpolres);
				venda.setQtdpolesp(qtdpolesp);
				venda.setValorfilme(tfvalorf.getText());
				venda.setValorrec(tfvalor_rec.getText());
				venda.setTroco(tftroco.getText());
				venda.setValorfinal(txtValorRs.getText());
				venda.setCartao(cartao);
	
				vendadao.criar(venda);
				JOptionPane.showMessageDialog(this, "Venda Efetuada com Sucesso!");
				tfvalor_desc.setText("");
				tftroco.setText("");
					}
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
