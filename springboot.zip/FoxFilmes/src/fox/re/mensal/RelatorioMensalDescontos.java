package fox.re.mensal;

import java.awt.HeadlessException;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import fox.re.diario.RelatorioDiarioDescontos;


public class RelatorioMensalDescontos extends JFrame {
	
	private JLabel lbnomepromo;
	private JTextField tfnomefilme;
	private JLabel lbdatainicial;
	private MaskFormatter maskfdatainicial;
	private JFormattedTextField tfdatainicial;
	private JLabel lbdatafinal;
	private MaskFormatter maskfdatafinal;
	private JFormattedTextField tfdatafinal;
	private JComboBox lstcodpromo;
	private JLabel lbcodpromo;
	private JButton btbuscar;
	private JButton btcancelar;
	private JScrollPane scrolTabela;
	private JTable tabela;

	public RelatorioMensalDescontos ()throws HeadlessException{
		
		//Cria��o de Objetos
		setTitle("Relat�rio Mensal de Descontos");
		lbnomepromo = new JLabel("Nome");
		tfnomefilme = new JTextField();
		lbdatainicial = new JLabel("Data Inical");
		maskfdatainicial = null;
		try {
			maskfdatainicial = new MaskFormatter("  ##/##/####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfdatainicial = new JFormattedTextField (maskfdatainicial);
		lbdatafinal = new JLabel("Data Final");
		maskfdatafinal = null;
		try {
			maskfdatafinal = new MaskFormatter("  ##/##/####");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfdatafinal = new JFormattedTextField (maskfdatafinal);
		String[] codpromo = {};
		lstcodpromo = new JComboBox(codpromo);
		lbcodpromo = new JLabel("C�digo Descontos");
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		tabela = new JTable();
		
		Object[][] conteudoTabela = 
			new Object[][] {
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null}
				};
		
		
		String[] titulos = new String[] { "C�digo Desconto", "Nome Conv�nio", "Valor Conv�nio", "Nome Promo��o", "Valor Promo��o", "Nome Sindicato", "Valor Sindicato", "C�digo Funcion�rio","Nome Funcion�rio", "Hora", "Data" };
		tabela.setModel(
				new DefaultTableModel(
						conteudoTabela,
						titulos)
				);
		
		tabela.setName("Relat�rio Di�rio de Descontos");
		scrolTabela = new JScrollPane(tabela);
		
		//Coordenadas
		setBounds(0,0,800,600);
		lbnomepromo.setBounds(20,30,85,20);
		tfnomefilme.setBounds(55,30,200,20);
		lbdatainicial.setBounds(20,50,85,20);
		tfdatainicial.setBounds(85,50,80,20);
		lbdatafinal.setBounds(180,50,85,20);
		tfdatafinal.setBounds(240,50,80,20);
		lbcodpromo.setBounds(340,50,120,20);
		lstcodpromo.setBounds(450,50,100,20);
		btbuscar.setBounds(565,50,85,25);
		btcancelar.setBounds(1175,50,85,25);
		scrolTabela.setBounds(20,90,750,450);
		
		//Execu��o na Tela
		add(lbnomepromo);
		add(tfnomefilme);
		add(lbdatainicial);
		add(tfdatainicial);
		add(lbdatafinal);
		add(tfdatafinal);
		add(lbcodpromo);
		add(lstcodpromo);
		add(btbuscar);
		add(btcancelar);
		add(scrolTabela);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);

	}
}
