package fox.re.diario;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;


public class RelatorioDiarioDescontos extends JFrame implements ActionListener {

	private JLabel lbnomepromo;
	private JTextField tfnomefilme;
	private JLabel lbhorainicial;
	private MaskFormatter maskfhorainicial;
	private JFormattedTextField tfhorainicial;
	private JLabel lbhorafinal;
	private MaskFormatter maskfhorafinal;
	private JFormattedTextField tfhorafinal;
	private	JComboBox lstcodpromo;
	private JLabel lbcodpromo;
	private JButton btbuscar;
	private JButton btcancelar;
	private JScrollPane scrolTabela;
	private JTable tabela;
	
	public RelatorioDiarioDescontos () throws HeadlessException{
	
		
		//Cria��o de Objetos
		setTitle("Relat�rio Di�rio de Descontos");
		lbnomepromo = new JLabel("Nome");
		tfnomefilme = new JTextField();
		lbhorainicial = new JLabel("Hora Inical");
		maskfhorainicial = null;
		try {
			maskfhorainicial = new MaskFormatter("  ##hs##min");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfhorainicial = new JFormattedTextField (maskfhorainicial);
		lbhorafinal = new JLabel("Hora Final");
		maskfhorafinal = null;
		try {
			maskfhorafinal = new MaskFormatter("  ##hs##min");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfhorafinal = new JFormattedTextField (maskfhorafinal);
		String[] codpromo = {};
		lstcodpromo = new JComboBox(codpromo);
		lbcodpromo = new JLabel("C�digo Descontos");
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		tabela = new JTable();
		
		Object[][] conteudoTabela = 
			new Object[][] {
				  {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null}
				};
		
		
		String[] titulos = new String[] { "C�digo Desconto", "Nome Conv�nio", "Valor Conv�nio", "Nome Promo��o", "Valor Promo��o", "Nome Sindicato", "Valor Sindicato", "C�digo Funcion�rio", "Nome Funcion�rio", "Hora" };
		tabela.setModel(
				new DefaultTableModel(
						conteudoTabela,
						titulos)
				);
		
		tabela.setName("Relat�rio Di�rio de Descontos");
		scrolTabela = new JScrollPane(tabela);
		
		
		//Coordenadas
		setBounds(0,0,800,600);
		lbnomepromo.setBounds(20,50,85,20);
		tfnomefilme.setBounds(55,50,200,20);
		lbhorainicial.setBounds(20,70,85,20);
		tfhorainicial.setBounds(85,70,80,20);
		lbhorafinal.setBounds(180,70,85,20);
		tfhorafinal.setBounds(240,70,80,20);
		lbcodpromo.setBounds(260,50,120,20);
		lstcodpromo.setBounds(365,50,100,20);
		scrolTabela.setBounds(20,90,750,450);
		btbuscar.setBounds(495,50,85,25);
		btcancelar.setBounds(1175,50,85,25);
		
		//Execu��o na Tela
		add(lbnomepromo);
		add(tfnomefilme);
		add(lbhorainicial);
		add(tfhorainicial);
		add(lbhorafinal);
		add(tfhorafinal);
		add(lbcodpromo);
		add(lstcodpromo);
		add(btbuscar);
		add(btcancelar);
		add(scrolTabela);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		

	}
	@Override
	public void actionPerformed(ActionEvent event) {
		
	}
	
}
