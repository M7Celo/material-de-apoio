package fox.re.diario;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import fox.bean.Funcionario;
import fox.dao.FuncionarioDao;
import fox.exception.DaoException;


public class RelatorioDiarioFuncionario extends JFrame implements ActionListener {

	private JLabel lbnomefunc;
	private JTextField tfnomefunc;
	private JLabel lbhorainicial;
	private MaskFormatter maskfhorainicial;
	private JFormattedTextField tfhorainicial;
	private JLabel lbhorafinal;
	private MaskFormatter maskfhorafinal;
	private JFormattedTextField tfhorafinal;
	private JComboBox lstcodfunc;
	private JLabel lbcodfunc;
	private JButton btbuscar;
	private JButton btcancelar;
	private JScrollPane scrolTabela;
	private JTable tabela;
	
	public RelatorioDiarioFuncionario ()throws HeadlessException, DaoException{
		
		//Cria��o de Objetos
		setTitle("Relat�rio Di�rio de Funcionario");
		lbnomefunc = new JLabel("Nome");
		tfnomefunc = new JTextField();
		lbhorainicial = new JLabel("Hora Inical");
		maskfhorainicial = null;
		try {
			maskfhorainicial = new MaskFormatter("  ##hs##min");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfhorainicial = new JFormattedTextField (maskfhorainicial);
		lbhorafinal = new JLabel("Hora Final");
		maskfhorafinal = null;
		try {
			maskfhorafinal = new MaskFormatter("  ##hs##min");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfhorafinal = new JFormattedTextField (maskfhorafinal);
		String[] codfunc = {};
		lstcodfunc = new JComboBox(codfunc);
		lbcodfunc = new JLabel("C�digo Funcion�rio");
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		tabela = new JTable();
		
		Object[][] conteudoTabela = 
			new Object[][] {
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null}, 
				{ null, null, null, null, null},
				{ null, null, null, null, null}, 
				{ null, null, null, null, null} 
				};
		
		
		String[] titulos = new String[] { "C�digo Funcion�rio", "Nome Funcion�rio", "N�vel de Acesso", "Atividade", "Hora"};
		tabela.setModel(
				new DefaultTableModel(
						conteudoTabela,
						titulos)
				);
		
		tabela.setName("Relat�rio Di�rio de Funcionario");
		scrolTabela = new JScrollPane(tabela);
		
		//Coordenadas
		setBounds(0,0,800,600);
		lbnomefunc.setBounds(20,50,85,20);
		tfnomefunc.setBounds(55,50,200,20);
		lbhorainicial.setBounds(20,70,85,20);
		tfhorainicial.setBounds(85,70,80,20);
		lbhorafinal.setBounds(180,70,85,20);
		tfhorafinal.setBounds(240,70,80,20);
		lbcodfunc.setBounds(260,50,120,20);
		lstcodfunc.setBounds(370,50,100,20);
		scrolTabela.setBounds(20,90,750,450);
		btbuscar.setBounds(495,50,85,25);
		btcancelar.setBounds(1175,50,85,25);
		
		
		//Execu��o na Tela
		add(lbnomefunc);
		add(tfnomefunc);
		add(lbhorainicial);
		add(tfhorainicial);
		add(lbhorafinal);
		add(tfhorafinal);
		add(lbcodfunc);
		add(lstcodfunc);
		add(scrolTabela);
		add(btbuscar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
	}
	@Override
	public void actionPerformed(ActionEvent event) {
		
	}
}
