package fox.re.diario;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;


public class RelatorioDiarioFilmes extends JFrame implements ActionListener {
	
	private JLabel lbnomef;
	private JTextField tfnomefilme;
	private JLabel lbhorainicial;
	private MaskFormatter maskfhorainicial;
	private JFormattedTextField tfhorainicial;
	private JLabel lbhorafinal;
	private MaskFormatter maskfhorafinal;
	private JFormattedTextField tfhorafinal;
	private JComboBox lstcodfilme;
	private JLabel lbcodfilme;
	private JButton btbuscar;
	private JButton btcancelar;
	private JScrollPane scrolTabela;
	private JTable tabela;
	

	public RelatorioDiarioFilmes ()throws HeadlessException{
		
		//Cria��o de Objetos
		setTitle("Relat�rio Di�rio de Filmes");
		lbnomef = new JLabel("Nome");
		tfnomefilme = new JTextField();
		lbhorainicial = new JLabel("Hora Inical");
		maskfhorainicial = null;
		try {
			maskfhorainicial = new MaskFormatter("  ##hs##min");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfhorainicial = new JFormattedTextField (maskfhorainicial);
		lbhorafinal = new JLabel("Hora Final");
		maskfhorafinal = null;
		try {
			maskfhorafinal = new MaskFormatter("  ##hs##min");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfhorafinal = new JFormattedTextField (maskfhorafinal);
		String[] codfilme = {};
		lstcodfilme = new JComboBox(codfilme);
		lbcodfilme = new JLabel("C�digo Filme");
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		tabela = new JTable();
		
		Object[][] conteudoTabela = 
			new Object[][] {
				  {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	    		  {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
	              {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
				};
		
		
		String[] titulos = new String[] { "C�digo Filme", "Nome Filme", "Categoria Filme", "Produtora Filme", "Data Lan�amento", "Exibi��o At�", "Pa�s de Origem", "Idioma Filme", "Classifica��o Et�ria", "Dublado", "Legendado", "Fora de Exibi��o", "C�digo Funcion�rio", "Nome Funcion�rio", "Hora"};
		tabela.setModel(
				new DefaultTableModel(
						conteudoTabela,
						titulos)
				);
		
		tabela.setName("Relat�rio Di�rio de Filme");
		scrolTabela = new JScrollPane(tabela);
		
		//Coordenadas
		setBounds(0,0,800,600);
		lbnomef.setBounds(20,50,85,20);
		tfnomefilme.setBounds(55,50,200,20);
		lbhorainicial.setBounds(20,70,85,20);
		tfhorainicial.setBounds(85,70,80,20);
		lbhorafinal.setBounds(180,70,85,20);
		tfhorafinal.setBounds(240,70,80,20);
		lbcodfilme.setBounds(260,50,85,20);
		lstcodfilme.setBounds(335,50,100,20);
		scrolTabela.setBounds(20,90,750,450);
		btbuscar.setBounds(445,50,85,25);
		btcancelar.setBounds(1175,50,85,25);
		
		//Execu��o na Tela
		add(lbnomef);
		add(tfnomefilme);
		add(lbhorainicial);
		add(tfhorainicial);
		add(lbhorafinal);
		add(tfhorafinal);
		add(lbcodfilme);
		add(lstcodfilme);
		add(scrolTabela);
		add(btbuscar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);

	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
