package fox.utilitarios.visual;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JLabel;

public class TelaUtil {

	public static void centralizar(Window window) {
		
		Dimension windowDim = Toolkit.getDefaultToolkit().getScreenSize();
		int y = ((int)windowDim.getHeight()/2) - window.getHeight()/2;
		int x = ((int)windowDim.getWidth()/2) - window.getWidth()/2;
		window.setLocation(x, y);
		
	}
	
	public static String dateToString(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return date==null?"":sdf.format(date);
	}
	
	public static JButton criaBotao(ActionListener listener, String textoBotao) {
		JButton botao = new JButton(textoBotao);
		botao.addActionListener(listener);
		return botao;
	}
	
	public static JLabel criaLabel(String textoLabel, Font font) {
		JLabel lblNome = new JLabel(textoLabel);
		lblNome.setFont(font);
		return lblNome;
	}

	public static JLabel criaLabel(String textoLabel) {
		JLabel lblNome = new JLabel(textoLabel);
		return lblNome;
	}
	
	public static String formataDinheiro(double valor00) {
		return formataDinheiro((int)(valor00*100)); 
	}
	
	public static String formataDinheiro(int valor00) {
		String val = Integer.toString(valor00);
		int max = Math.max(0, val.length() - 2);
		val = 
			val.substring(0, max) + 
				"." + 
				val.substring(max);
		return "R$ " + val.toString();
	}
}
