package fox.exception;

public class PessoaNaoEncontradaException extends Exception {

	public PessoaNaoEncontradaException() {
	}

	public PessoaNaoEncontradaException(String arg0) {
		super(arg0);
	}

	public PessoaNaoEncontradaException(Throwable arg0) {
		super(arg0);
	}

	public PessoaNaoEncontradaException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
