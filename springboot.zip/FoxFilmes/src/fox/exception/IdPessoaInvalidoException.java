package fox.exception;

public class IdPessoaInvalidoException extends Exception {

	public IdPessoaInvalidoException() {
	}

	public IdPessoaInvalidoException(String message) {
		super(message);
	}

	public IdPessoaInvalidoException(Throwable cause) {
		super(cause);
	}

	public IdPessoaInvalidoException(String message, Throwable cause) {
		super(message, cause);
	}
}
