package fox.sobre;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Contato extends JFrame {
	private JPanel painel;
	JLabel contatoDes;
	JLabel contatoNome;
	JLabel contatoCels;
	JLabel contatoCels2;
	JLabel contatoEmail;
	
	public Contato(){
		setTitle("Contato");
		setBounds(0,0,440,155);
		
		contatoDes = new JLabel("Programdor do Software:");
		contatoNome = new JLabel("Marcelo Correia de Lima");
		contatoCels = new JLabel("Celulares: 0(XX)11 8481-3903 - TIM, 0(XX)11 6282-5491 - OI");
		contatoCels2 = new JLabel("Celulares: 0(XX)11 8984-2261 - CLARO");
		contatoEmail = new JLabel("e-mail: marcelo.c_lima@hotmail.com");
		this.painel = new JPanel();
		
		painel.setBounds(20, 20, 390, 65);
		painel.setBackground(new Color(255,255,255));		
		contatoDes.setBounds(40, 40, 400, 20);
		contatoDes.setForeground(new Color(255,0,0));
		contatoNome.setBounds(80, 80, 400, 20);
		contatoNome.setForeground(new Color(0,0,255));
		contatoCels.setBounds(40, 100, 100, 20);
		contatoCels2.setBounds(40,120,100,20);
		contatoEmail.setBounds(40, 140, 100, 20);
		
		add(painel);
		painel.add(contatoDes);
		painel.add(contatoNome);
		painel.add(contatoCels);
		painel.add(contatoCels2);
		painel.add(contatoEmail);
		
		setLayout(null);
		setResizable(false);
		setVisible(true);
		
	}

}
