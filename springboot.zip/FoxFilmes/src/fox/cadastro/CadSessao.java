package fox.cadastro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import fox.bean.Filme;
import fox.bean.Sala;
import fox.bean.Sessao;
import fox.bean.Valor;
import fox.dao.FilmeDao;
import fox.dao.SalaDao;
import fox.dao.SessaoDao;
import fox.dao.ValorDao;
import fox.exception.DaoException;

public class CadSessao extends JFrame implements ActionListener {

	private JLabel lbnomesessao;
	private JTextField tfnomesessao;
	private JLabel lbhorsessao;
	private JLabel lbhorsessaoinicial;
	private MaskFormatter maskfsessaoinicial;	
	private JFormattedTextField tfhorsessaoinicial;
	private JLabel lbhorsessaofinal;
	private MaskFormatter maskfsessaofinal;	
	private JFormattedTextField tfhorsessaofinal;
	private JLabel lbcod_sala;
	private JComboBox cbcodSala;
	private JTextField tfnomef;
	private JLabel lbnomef;
	private JLabel lbcod_filme;
	private JComboBox cbcodFilme;
	private JTextField tfnumsala;
	private JTextField tfcod_filme;
	private JTextField tfcod_sala;
	private JButton btsalvar;
	private JButton btapagar;
	private JButton btcancelar;
	private SalaDao saladao;
	private Sala sala;
	private SessaoDao sessaodao;
	private Sessao sessao;
	private JLabel lbnumsala;
	private ValorDao valordao;
	private Valor valor;
	
	public CadSessao () {
	
		/* Cria��o de Objetos */
		setTitle("Cadastro Sess�o");
		lbnomesessao = new JLabel("Nome Sess�o");
		tfnomesessao = new JTextField ();
		lbhorsessao = new JLabel("Hor�rio Sess�o");
		lbhorsessaoinicial = new JLabel("In�cio");
		maskfsessaoinicial = null;
		try {
			maskfsessaoinicial = new MaskFormatter("   ##hs##min");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfhorsessaoinicial = new JFormattedTextField (maskfsessaoinicial);
		lbhorsessaofinal = new JLabel("T�rmino");
		maskfsessaofinal = null;
		try {
			maskfsessaofinal = new MaskFormatter("   ##hs##min");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		tfhorsessaofinal = new JFormattedTextField (maskfsessaofinal);
		lbcod_sala = new JLabel("Selecione Sala");
		tfcod_sala = new JTextField();
		cbcodSala = new JComboBox();
		tfnumsala = new JTextField ();
		lbnumsala = new JLabel("Num Sala");
		lbnomef = new JLabel("Nome Filme");
		tfcod_filme = new JTextField();
		lbcod_filme = new JLabel("Selecione Filme");
		cbcodFilme = new JComboBox();
		tfnomef = new JTextField ();
		btsalvar = new JButton("Salvar");
		btapagar = new JButton("Limpar");
		btcancelar = new JButton("Cancelar");
		
		/* Coordenadas */
		setBounds(0, 0, 560, 200);
		lbnomesessao.setBounds(20, 10, 130, 20);
		tfnomesessao.setBounds(105, 10, 200, 20);
		lbhorsessao.setBounds(20, 35, 100, 20);
		lbhorsessaoinicial.setBounds(130, 35, 100, 20);
		tfhorsessaoinicial.setBounds(165, 35, 70, 20);
		lbhorsessaofinal.setBounds(250, 35, 100, 20);
		tfhorsessaofinal.setBounds(300, 35, 70, 20);
		lbcod_sala.setBounds(20, 60, 150, 20);
		cbcodFilme.setBounds(310, 60, 80,20);
		lbcod_filme.setBounds(215, 60, 150, 20);
		lbnumsala.setBounds(20, 85, 60, 20);
		cbcodSala.setBounds(110, 60, 80, 20);
		tfnumsala.setBounds(90, 85, 50, 20);
		lbnomef.setBounds(215, 85, 70, 20);
		tfnomef.setBounds(290, 85, 245, 20);
		btsalvar.setBounds(20,  120, 90, 25);
		btapagar.setBounds(235, 120, 90, 25);
		btcancelar.setBounds(420, 120, 90, 25);

		/* Execu��o na Tela */
		add(lbnomesessao);
		add(tfnomesessao);
		add(lbhorsessao);
		add(lbhorsessaoinicial);
		add(tfhorsessaoinicial);
		add(lbhorsessaofinal);
		add(tfhorsessaofinal);
		add(lbcod_sala);
		add(cbcodSala);
		add(tfnumsala);
		add(lbcod_filme);
		add(cbcodFilme);
		add(tfnomef);
		add(lbnomef);
		add(lbnumsala);
		add(btsalvar);
		add(btapagar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		this.valordao = new ValorDao();
		this.valor = new Valor();
		this.saladao = new SalaDao();
		this.sala = new Sala();
		
		btsalvar.addActionListener(this);
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodFilme.addActionListener(this);
		cbcodSala.addActionListener(this);
		
		try {
			List<Valor> valorList = this.valordao.buscarTodos();

			for (Valor v : valorList) {
				cbcodFilme.addItem(v.getCodValor());
			}

			List<Sala> salaList = this.saladao.buscarTodos();

			for (Sala sala : salaList) {
				cbcodSala.addItem(sala.getCodSala());
			}
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar a base de dados");
			e.printStackTrace();
		}	
			
	}
	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			
			if(event.getSource() == this.cbcodFilme){
				String item = String.valueOf(cbcodFilme.getSelectedItem());
				int codFilme = Integer.parseInt(item);
				valor = valordao.buscarPorId(codFilme);	
				
				tfnomef.setText(valor.getNomeFilme());
			}
			if(event.getSource() == this.cbcodSala){
				String item = String.valueOf(cbcodSala.getSelectedItem());
				int codSala = Integer.parseInt(item);
				sala = saladao.buscarPorId(codSala);	
				
				tfnumsala.setText(String.valueOf(sala.getNumSala()));
				
				
			}
			if(event.getSource() == this.btsalvar){
				sessaodao = new SessaoDao();
				sessao = new Sessao();
				sessao.setNomeSessao(tfnomesessao.getText());
				String horaInicio = tfhorsessaoinicial.getText();
				horaInicio = horaInicio.replaceAll("hs", ":").replaceAll("min", ":").trim();
				sessao.setHorarioInicial(horaInicio);
				String horaFinal = tfhorsessaofinal.getText();
				horaFinal = horaFinal.replaceAll("hs", ":").replaceAll("min", ":").trim();
				sessao.setHorarioFinal(horaFinal);
				sessao.setCodigoSala((Integer)cbcodSala.getSelectedItem());
				sessao.setNumSala(Integer.parseInt(tfnumsala.getText()));
				sessao.setCodigoFilme((Integer)cbcodFilme.getSelectedItem());
				sessao.setNomeFilme(tfnomef.getText());
				sessao.setValorFilme(valor.getValorFilme());				
				
				int qtdpoldis = sala.getQtdPoltronaDis();
				int qtdpolesp = sala.getQtdPoltronaEsp();
				int qtdpolres = sala.getQtdPoltronaRes();
				
				sessao.setQtdpoldis(qtdpoldis);
				sessao.setQtdpolesp(qtdpolesp);
				sessao.setQtdpolres(qtdpolres);
				
				sessaodao.criar(sessao);
				
				JOptionPane.showMessageDialog(this, "Sess�o Cadastrada com sucesso!");
				
				setValoresIniciais();
			}
			else if (btapagar == event.getSource()) {
				setValoresIniciais();
			} else if (btcancelar == event.getSource()) {
				this.dispose();
			}
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}	
	}
	private void setValoresIniciais() {
		tfnomesessao.setText("");
		tfhorsessaoinicial.setText("");
		tfhorsessaofinal.setText("");
	}
}
