package fox.cadastro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Funcionario;
import fox.bean.Sala;
import fox.dao.FuncionarioDao;
import fox.dao.SalaDao;
import fox.exception.CampoObrigatorioException;
import fox.exception.DaoException;
import fox.util.db.Conexao;


public class CadSalas extends JFrame implements ActionListener {
		
	private JLabel lbnomesala;
	private JTextField tfnomesala;
	private JLabel lbqtdpol;
	private JTextField tfqtdpol;
	private JLabel lbqtdpoldis;
	private JTextField tfqtdpoldis;
	private JLabel lbqtdpolres;
	private JTextField tfqtdpolres;
	private JLabel lbpolesp;
	private JTextField tfpolesp;
	private JButton btsalvar;
	private JButton btapagar;
	private JButton btcancelar;
	private SalaDao saladao;
	private Sala sala;
	
	public CadSalas () {
		
		/* Cria��o de Objetos */
		setTitle("Cadastro Salas");
		lbnomesala = new JLabel("N�mero Sala");
		tfnomesala = new JTextField ();
		lbqtdpol = new JLabel("Qtd Poltrona");
		tfqtdpol = new JTextField ();
		lbqtdpoldis = new JLabel("Qtd Poltrona Dispon�veis");
		tfqtdpoldis = new JTextField ();
		lbqtdpolres = new JLabel("Qtd Poltrona Reservadas");
		tfqtdpolres = new JTextField ();
		lbpolesp = new JLabel("Poltrona Especiais");
		tfpolesp = new JTextField ();
		btsalvar = new JButton("Salvar");
		btapagar = new JButton("Limpar");
		btcancelar = new JButton("Cancelar");
		
		/* Coordenadas */
		setBounds(0, 0, 300, 210);
		lbnomesala.setBounds(20, 10, 130, 25);
		tfnomesala.setBounds(100, 10, 50, 20);
		lbqtdpol.setBounds(20, 35, 100, 25);
		tfqtdpol.setBounds(98, 35, 70, 20);
		lbqtdpoldis.setBounds(20, 60, 150, 25);
		tfqtdpoldis.setBounds(165, 60, 70, 20);
		lbqtdpolres.setBounds(20, 85, 150, 25);
		tfqtdpolres.setBounds(168, 85, 70, 20);
		lbpolesp.setBounds(20, 110, 150, 25);
		tfpolesp.setBounds(135, 110, 70, 20);
		btsalvar.setBounds(20, 140, 90, 25);
		btcancelar.setBounds(180, 140, 90, 25);
		
		/* Execu��o na Tela */
		add(lbnomesala);
		add(tfnomesala);
		add(lbqtdpol);
		add(tfqtdpol);
		add(lbqtdpoldis);
		add(tfqtdpoldis);
		add(lbqtdpolres);
		add(tfqtdpolres);
		add(lbpolesp);
		add(tfpolesp);
		add(btsalvar);
		add(btapagar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		btsalvar.addActionListener(this);
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}
	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.btsalvar) {
				if ("".equals(tfnomesala.getText().trim())) {
					throw new CampoObrigatorioException("N�mero de Sala");
				}
	
				if ("".equals(tfqtdpol.getText().trim())) {
					throw new CampoObrigatorioException("Quantidade de Poltrona");
				}
				
				if ("".equals(tfqtdpoldis.getText().trim())) {
					throw new CampoObrigatorioException("Quantidade de Poltrona Dispon�vel");
				}
				
				saladao = new SalaDao();
				sala = new Sala();
				sala.setNumSala(Integer.parseInt(tfnomesala.getText()));
				sala.setQtdPoltrona(Integer.parseInt(tfqtdpol.getText()));
				sala.setQtdPoltronaDis(Integer.parseInt(tfqtdpoldis.getText()));
				sala.setQtdPoltronaRes(Integer.parseInt(tfqtdpolres.getText()));
				sala.setQtdPoltronaRes(Integer.parseInt(tfpolesp.getText()));
				saladao.criar(sala);
			
				JOptionPane.showMessageDialog(this, "Sala cadastrada com sucesso");
				
				setValoresIniciais();
				
			} else if (btapagar == event.getSource()) {
				setValoresIniciais();
			} else if (btcancelar == event.getSource()) {
				this.dispose();
			}
		} catch (CampoObrigatorioException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Erro de digita��o", JOptionPane.ERROR_MESSAGE);
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar a base, contactar o Marcelo ou o Vinicius", "Erro de banco de dados", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	private void setValoresIniciais() {
		tfnomesala.setText("");
		tfqtdpol.setText("");
		tfqtdpoldis.setText("");
		tfqtdpolres.setText("");
		tfpolesp.setText("");
			}
}
