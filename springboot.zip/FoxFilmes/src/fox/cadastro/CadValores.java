package fox.cadastro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import fox.bean.Filme;
import fox.bean.Valor;
import fox.dao.FilmeDao;
import fox.dao.ValorDao;
import fox.exception.DaoException;

public class CadValores extends JFrame implements ActionListener {
	
	private JLabel lbcod_filme;
	private JComboBox cbcodFilme;
	private JLabel lbnomef;
	private JTextField tfnomef;
	private JButton btsalvar;
	private JButton btapagar;
	private JButton btcancelar;
	private JLabel lbvalorPreco;
	private FilmeDao filmeDao;
	private ValorDao valordao;
	private Valor valor;
	private MaskFormatter maskvalorf;	
	private JFormattedTextField tfvalorPreco;
	
	public CadValores () {
		
			/* Cria��o de Objetos */
			setTitle("Cadastro de Valores");
			lbcod_filme = new JLabel("C�digo Filme");
			cbcodFilme = new JComboBox();
			lbnomef = new JLabel("Nome do Filme");
			tfnomef = new JTextField();
			btsalvar = new JButton("Salvar");
			btapagar = new JButton("Apagar");
			btcancelar = new JButton("Cancelar");
			lbvalorPreco = new JLabel("Valor R$:");
			maskvalorf = null;
			try {
				maskvalorf = new MaskFormatter("##.##");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			tfvalorPreco = new JFormattedTextField (maskvalorf);
			
			/* Coordenadas */
			setBounds(0, 0, 440, 170);
			lbvalorPreco.setBounds(20, 60, 100, 20);
			tfvalorPreco.setBounds(80, 60, 40, 20);
			lbcod_filme.setBounds(20, 10, 150, 20);
			cbcodFilme.setBounds(100, 10, 310, 20);
			lbnomef.setBounds(20, 35, 100, 20);
			tfnomef.setBounds(110, 35, 300, 20);
			btsalvar.setBounds(20, 95, 90, 25);
			btapagar.setBounds(170, 95, 90, 25);
			btcancelar.setBounds(320, 95, 90, 25);
			
			filmeDao = new FilmeDao();
			
			cbcodFilme.addActionListener(this);
			btsalvar.addActionListener(this);
			btapagar.addActionListener(this);
			btcancelar.addActionListener(this);
			
			try {
				List<Filme> lista = filmeDao.buscarTodos();
			
				for (Filme f : lista) {
					cbcodFilme.addItem(f.getCodFilme() + " - " + f.getNomeFilme()); 
				}
			
			/* Execu��o na Tela */
			add(lbvalorPreco);
			add(tfvalorPreco);
			add(lbcod_filme);
			add(cbcodFilme);
			add(lbnomef);
			add(tfnomef);
			add(btsalvar);
			add(btapagar);
			add(btcancelar);
			
			setLayout(null);
			setVisible(true);
			setResizable(false);
			
			} catch (DaoException e) {
				JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
				this.dispose();
				e.printStackTrace();
			}				
	}


	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.cbcodFilme) {
				String item = (String)this.cbcodFilme.getSelectedItem();
				item = item.substring(0, item.indexOf("-")).trim();
			
				int codFilme = Integer.parseInt(item);
				Filme filme = this.filmeDao.buscarPorId(codFilme);
				
				this.tfnomef.setText(filme.getNomeFilme());
			}
			if(event.getSource() == this.btsalvar){
				valordao = new ValorDao();
				valor = new Valor();
				valor.setNomeFilme(tfnomef.getText());
				valor.setValorFilme(tfvalorPreco.getText());
				
				valordao.criar(valor);
				
				JOptionPane.showMessageDialog(this, "Valor do Filme Cadastrado com Sucesso!");
				tfvalorPreco.setText("");
				
			} if (btapagar == event.getSource()) {
				tfvalorPreco.setText("");
			} if (btcancelar == event.getSource()) {
				this.dispose();
			}
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor","Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
