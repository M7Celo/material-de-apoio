package fox.tela.login;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import fox.bean.Funcionario;
import fox.dao.FuncionarioDao;
import fox.exception.DaoException;
import fox.utilitarios.visual.TemaInicial;

public class SemCadastro extends JFrame implements ActionListener {
	
	static TemaInicial tema = new TemaInicial();
	private static FuncionarioDao funcionariodao;
	private static Funcionario funcionario;
	 private JButton btOK;
	 private JButton btcancelar;
	 private JButton btnovo;
	 private JLabel lbLogin;
	 private JLabel lbSenha;
	 private final JTextField tfLogin;
	 private final JPasswordField pfSenha;
	 private String usuario;
	 private String senha;
	 private int nAcesso;
	 private String senhaFunc;
	 private int codFunc;
	 private int login;
	 
	 public SemCadastro(){
			tema.LookAndFeelInicial();
			
			setTitle("Login");
			btOK = new JButton("OK");
			btcancelar = new JButton("Cancelar");
			btnovo = new JButton("Novo");
			lbLogin = new JLabel("Login");
			lbSenha = new JLabel("Senha");
			tfLogin = new JTextField(5);
			pfSenha = new JPasswordField(5);
			btOK.addActionListener(this);
			btcancelar.addActionListener(this);
			btnovo.addActionListener(this);
			
			/*Coordenadas*/
			setBounds(500, 200, 230, 230);
			btOK.setBounds(20,120,90,25);
			btcancelar.setBounds(120,120,90,25);
			lbLogin.setBounds(20, 30, 100, 25);
			tfLogin.setBounds(60, 30, 150, 25);
			lbSenha.setBounds(20, 70, 100, 25);
			pfSenha.setBounds(60, 70, 150, 25);
			btnovo.setBounds(75,160,90,25);
			
			/* Execu��o da Tela */
			add(btOK);
			add(btcancelar);
			add(lbLogin);
			add(tfLogin);
			add(lbSenha);
			add(pfSenha);
			add(btnovo);
			
			setLayout(null);
			setVisible(true);
			setResizable(false);
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		@Override
		public void actionPerformed(ActionEvent event) {
			try {
				funcionariodao = new FuncionarioDao();
				funcionario = new Funcionario();
				
				usuario = tfLogin.getText();
				senha = pfSenha.getText();
				login = 0;
				
				if(event.getSource() == this.btOK){
						
					
					funcionariodao.buscarTodos();
					
					login = Integer.parseInt(usuario);
					
					codFunc = 0;
					codFunc = Integer.parseInt(usuario);
					funcionario = funcionariodao.buscarPorId(codFunc);
					
					senhaFunc = funcionario.getSenha();
					nAcesso = 0;
					nAcesso = funcionario.getNivelAcesso();
										
						if(senha.equals(senhaFunc) && nAcesso == 1){
							JOptionPane.showMessageDialog(null, "Usu�rio e senha corretos");
							MenuNU objmenu1 = new MenuNU();
							this.dispose();
						}
						if(senha.equals(senhaFunc) && nAcesso == 2){
							JOptionPane.showMessageDialog(null, "Usu�rio e senha corretos");
								MenuND objmenu2 = new MenuND();
								this.dispose();
						}
						if(senha.equals(senhaFunc) && nAcesso == 3){
							JOptionPane.showMessageDialog(null, "Usu�rio e senha corretos");
								MenuNT objmenu3 = new MenuNT();
								this.dispose();
						}
						if(senha.equals(senhaFunc) && nAcesso == 4){
							JOptionPane.showMessageDialog(null, "Usu�rio e senha corretos");
								MenuNQ objmenu4 = new MenuNQ();
								this.dispose();
						}
						if(senha.equals(senhaFunc) && nAcesso == 5){
							JOptionPane.showMessageDialog(null, "Usu�rio e senha corretos");
								MenuPrincipal objmenu5 = new MenuPrincipal();
								this.dispose();
								}else{
									JOptionPane.showMessageDialog(this, "Digite Usu�rio e Senha Corretamente!");
								}
					}
				if (btcancelar == event.getSource()) {
						this.dispose();
					}
				if(btnovo == event.getSource()){
					JOptionPane.showMessageDialog(this, "Bem vindo!");
					JOptionPane.showMessageDialog(this, "Agradecemos Por Adquirir Nossos Produtos!");
					JOptionPane.showMessageDialog(this, "Obs: Cadastre um Funcion�rio N�vel '5'. Para Utilizar o Software 'Fox Filmes' Novamente!");
					MenuPrincipal objmenu5 = new MenuPrincipal();
					this.dispose();
					}
			} catch (DaoException e) {
				JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		public static void main(String[] args) {
			new SemCadastro();
		}
}
