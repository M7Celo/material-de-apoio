package fox.apagar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


import fox.bean.Descontos;
import fox.dao.DescontosDao;
import fox.exception.DaoException;

public class ApagaDescontos extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private JLabel lbcodDesc;
	private JComboBox cbcodDesco;
	private JButton btapagar;
	private JButton btcancelar;
	private JTextField txtnomeDesc;
	private DescontosDao descontosDao;	
	
	public ApagaDescontos(){
		
		setTitle("Apagar Descontos");
		lbcodDesc = new JLabel("C�digo Descontos");
		cbcodDesco = new JComboBox();
		txtnomeDesc = new JTextField();
		btapagar = new JButton("Apagar");
		btcancelar = new JButton("Cancelar");
		
		setBounds( 0, 0, 300, 130);
		lbcodDesc.setBounds(20,10,200,20);
		cbcodDesco.setBounds(130,10,80,20);
		txtnomeDesc.setBounds(20, 40, 250, 20);
		btapagar.setBounds(20,70,90,20);
		btcancelar.setBounds(180,70,90,20);
		
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodDesco.addActionListener(this);
		
		descontosDao = new DescontosDao();
		
		try {
			List<Descontos> lista = descontosDao.buscarTodos();
		
			for (Descontos d : lista) {
				cbcodDesco.addItem(d.getCodDescontos()); 
			}
			
			add(lbcodDesc);
			add(cbcodDesco);
			add(txtnomeDesc);
			add(btapagar);
			add(btcancelar);
			
			setLayout(null);
			setVisible(true);
			setResizable(false);
			
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
		
	}
	

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.cbcodDesco) {
				String item = String.valueOf(cbcodDesco.getSelectedItem());
				int codDesconto = Integer.parseInt(item);
				Descontos descontos = this.descontosDao.buscarPorId(codDesconto);
				
				txtnomeDesc.setText(descontos.getNomeSind());
			}
			
			if(event.getSource() == this.btapagar){
				String item = String.valueOf(cbcodDesco.getSelectedItem());
				int opcao = 
					JOptionPane.showConfirmDialog(
						this, "Deseja realmente apagar '" + this.txtnomeDesc.getText() + "'?", 
						"Apagar Descontos", 
						JOptionPane.YES_NO_OPTION);
				int codApagar = Integer.parseInt(item);
					if (opcao == JOptionPane.YES_OPTION) {
						descontosDao.apagar(codApagar);
						txtnomeDesc.setText("");
						JOptionPane.showMessageDialog(null, "Descontos Apagado com Sucesso!");
					}
				}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
