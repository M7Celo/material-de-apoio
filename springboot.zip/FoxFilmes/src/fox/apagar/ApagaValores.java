package fox.apagar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Sessao;
import fox.bean.Valor;
import fox.dao.ValorDao;
import fox.exception.DaoException;

public class ApagaValores extends JFrame implements ActionListener{
	
	private JLabel lbcodValores;
	private JComboBox cbcodValor;
	private JButton btapagar;
	private JButton btcancelar;
	private JTextField txtnomeF;
	private ValorDao valordao;	
	
	public ApagaValores(){
		
		setTitle("Apagar Valores");
		lbcodValores = new JLabel("C�digo Valores");
		cbcodValor = new JComboBox();
		txtnomeF = new JTextField();
		btapagar = new JButton("Apagar");
		btcancelar = new JButton("Cancelar");
		
		setBounds( 0, 0, 300, 130);
		lbcodValores.setBounds(20,10,200,20);
		cbcodValor.setBounds(130,10,80,20);
		txtnomeF.setBounds(20, 30, 250, 20);
		btapagar.setBounds(20,70,90,20);
		btcancelar.setBounds(180,70,90,20);
		
		btapagar.addActionListener(this);
		btcancelar.addActionListener(this);
		cbcodValor.addActionListener(this);
		
		valordao = new ValorDao();
		
		try {
			List<Valor> lista = valordao.buscarTodos();
		
			for (Valor v : lista) {
				cbcodValor.addItem(v.getCodValor()); 
			}
		
		add(lbcodValores);
		add(cbcodValor);
		add(txtnomeF);
		add(btapagar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if (event.getSource() == this.cbcodValor) {
				String item = String.valueOf(cbcodValor.getSelectedItem());
				int codValor = Integer.parseInt(item);
				Valor valor = this.valordao.buscarPorId(codValor);
				
				txtnomeF.setText(valor.getNomeFilme());
				
			}
			
			if(event.getSource() == this.btapagar){
				String item = String.valueOf(cbcodValor.getSelectedItem());
				int opcao = 
					JOptionPane.showConfirmDialog(
						this, "Deseja realmente apagar '" + this.txtnomeF.getText() + "'?", 
						"Apagar Valor", 
						JOptionPane.YES_NO_OPTION);
				int codApagar = Integer.parseInt(item);
					if (opcao == JOptionPane.YES_OPTION) {
						valordao.apagar(codApagar);
						txtnomeF.setText("");
						JOptionPane.showMessageDialog(null, "Valor Apagado com Sucesso!");
					}
				}
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
