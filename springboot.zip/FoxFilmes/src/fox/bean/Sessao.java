package fox.bean;

public class Sessao {
	
	private int codigoSessao;
	private String nomeSessao;
	private String horarioInicial;
	private String horarioFinal;
	private int codigoSala;
	private int numSala;
	private String nomeFilme;
	private int codigoFilme;
	private int qtdpoldis;
	private int qtdpolesp;
	private int qtdpolres;
	private String valorFilme;
	
	public int getCodigoSessao() {
		return codigoSessao;
	}
	public void setCodigoSessao(int codigoSessao) {
		this.codigoSessao = codigoSessao;
	}
	public String getNomeSessao() {
		return nomeSessao;
	}
	public void setNomeSessao(String nomeSessao) {
		this.nomeSessao = nomeSessao;
	}
	public String getHorarioInicial() {
		return horarioInicial;
	}
	public void setHorarioInicial(String horarioInicial) {
		this.horarioInicial = horarioInicial;
	}
	public String getHorarioFinal() {
		return horarioFinal;
	}
	public void setHorarioFinal(String horarioFinal) {
		this.horarioFinal = horarioFinal;
	}
	public int getCodigoSala() {
		return codigoSala;
	}
	public void setCodigoSala(int codigoSala) {
		this.codigoSala = codigoSala;
	}
	public int getNumSala() {
		return numSala;
	}
	public void setNumSala(int numSala) {
		this.numSala = numSala;
	}
	public String getNomeFilme() {
		return nomeFilme;
	}
	public void setNomeFilme(String nomeFilme) {
		this.nomeFilme = nomeFilme;
	}
	public int getCodigoFilme() {
		return codigoFilme;
	}
	public void setCodigoFilme(int codigoFilme) {
		this.codigoFilme = codigoFilme;
	}
	public int getQtdpoldis() {
		return qtdpoldis;
	}
	public void setQtdpoldis(int qtdpoldis) {
		this.qtdpoldis = qtdpoldis;
	}
	public int getQtdpolesp() {
		return qtdpolesp;
	}
	public void setQtdpolesp(int qtdpolesp) {
		this.qtdpolesp = qtdpolesp;
	}
	public int getQtdpolres() {
		return qtdpolres;
	}
	public void setQtdpolres(int qtdpolres) {
		this.qtdpolres = qtdpolres;
	}
	public String getValorFilme() {
		return valorFilme;
	}
	public void setValorFilme(String valorFilme) {
		this.valorFilme = valorFilme;
	}
	@Override
	public String toString() {
		return "Sessao [codigoSessao=" + codigoSessao + ", nomeSessao="
				+ nomeSessao + ", horarioInicial=" + horarioInicial
				+ ", horarioFinal=" + horarioFinal + ", codigoSala="
				+ codigoSala + ", numSala=" + numSala + ", nomeFilme="
				+ nomeFilme + ", codigoFilme=" + codigoFilme + ", qtdpoldis="
				+ qtdpoldis + ", qtdpolesp=" + qtdpolesp + ", qtdpolres="
				+ qtdpolres + ", valorFilme=" + valorFilme + "]";
	}	
}
