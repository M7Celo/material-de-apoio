package fox.bean;

public class Verifica {
	
	private int codVerif;
	private int verif;
	
	public int getCodVerif() {
		return codVerif;
	}
	public void setCodVerif(int codVerif) {
		this.codVerif = codVerif;
	}
	public int getVerif() {
		return verif;
	}
	public void setVerif(int verif) {
		this.verif = verif;
	}
	
	@Override
	public String toString() {
		return "verifica [codVerif=" + codVerif + ", verif=" + verif + "]";
	}

}
