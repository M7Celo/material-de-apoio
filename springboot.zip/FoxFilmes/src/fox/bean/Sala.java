package fox.bean;

public class Sala {
	
	private int codSala;
	private int numSala;
	private int qtdPoltrona;
	private int qtdPoltronaDis;
	private int qtdPoltronaRes;
	private int qtdPoltronaEsp;
	
	public int getCodSala() {
		return codSala;
	}
	public void setCodSala(int codSalas) {
		this.codSala = codSalas;
	}
	public int getNumSala() {
		return numSala;
	}
	public void setNumSala(int numSala) {
		this.numSala = numSala;
	}
	public int getQtdPoltrona() {
		return qtdPoltrona;
	}
	public void setQtdPoltrona(int qtdPoltrona) {
		this.qtdPoltrona = qtdPoltrona;
	}
	public int getQtdPoltronaDis() {
		return qtdPoltronaDis;
	}
	public void setQtdPoltronaDis(int qtdPoltronaDis) {
		this.qtdPoltronaDis = qtdPoltronaDis;
	}
	public int getQtdPoltronaRes() {
		return qtdPoltronaRes;
	}
	public void setQtdPoltronaRes(int qtdPoltronaRes) {
		this.qtdPoltronaRes = qtdPoltronaRes;
	}
	public int getQtdPoltronaEsp() {
		return qtdPoltronaEsp;
	}
	public void setQtdPoltronaEsp(int qtdPoltronaEsp) {
		this.qtdPoltronaEsp = qtdPoltronaEsp;
	}
	@Override
	public String toString() {
		return "Sala [codSala=" + codSala + ", numSala=" + numSala
				+ ", qtdPoltrona=" + qtdPoltrona + ", qtdPoltronaDis="
				+ qtdPoltronaDis + ", qtdPoltronaRes=" + qtdPoltronaRes
				+ ", qtdPoltronaEsp=" + qtdPoltronaEsp + "]";
	}
}
