package fox.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fox.exception.DaoException;
import fox.util.db.DbUtil;

public abstract class DaoBase <T> {

	private String nomeSequence;
	private String queryBuscarPorId;
	private String queryBuscarTodos;
	private String querySalvar;
	private String queryApagar;
	private String queryCriar;
	
	public DaoBase(String nomeSequence, String queryBuscarPorId,
			String queryBuscarTodos, String querySalvar, String queryApagar,
			String queryCriar) {
		super();
		this.nomeSequence = nomeSequence;
		this.queryBuscarPorId = queryBuscarPorId;
		this.queryBuscarTodos = queryBuscarTodos;
		this.querySalvar = querySalvar;
		this.queryApagar = queryApagar;
		this.queryCriar = queryCriar;
	}
	
	private int getProximoValorSequence() throws DaoException {
		Connection conn = DbUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;
		int novoIdPessoa = 0;
		try {
			
			String select = "select " + this.nomeSequence + ".nextval as NOVO_ID from dual";
			
			System.out.println("Query : " + select);
			
			statement = conn.prepareStatement(select);
			result = statement.executeQuery();
			if (result.next()) {

				novoIdPessoa = result.getInt("NOVO_ID");
			}
		} catch (SQLException e) {
			throw new DaoException(e);
		} finally {
			DbUtil.close(conn, statement, result);
		}
		return novoIdPessoa;
	}
	
	public List<T> buscarTodos() throws DaoException {
		Connection conn = DbUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;
		List<T> listaTodos = new ArrayList<T>();
		try {
			
			statement = conn.prepareStatement(this.queryBuscarTodos);
			
			System.out.println("Query : " + this.queryBuscarTodos);
			
			result = statement.executeQuery();
			while (result.next()) {
				
				T bean = getBean(result);
				
				listaTodos.add(bean);
			}
		} catch (SQLException e) {
			throw new DaoException(e);
		} finally {
			DbUtil.close(conn, statement, result);
		}
		return listaTodos;
	}


	
	protected abstract T getBean(ResultSet result) throws SQLException;

	public T buscarPorId(Object ... ids) throws DaoException {
		Connection conn = DbUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;
		T bean = null;
		try {

			System.out.println("Query : " + this.queryBuscarPorId);
			
			statement = conn.prepareStatement(this.queryBuscarPorId);
			
			Object val = null;
			int i = 1;
			for (;i <= ids.length; i++) {
				val = ids[i - 1];
				setParametro(statement, val, i);
			}
			
			result = statement.executeQuery();
			if (result.next()) {
				bean = getBean(result);
			}
		} catch (SQLException e) {
			throw new DaoException(e);
		} finally {
			DbUtil.close(conn, statement, result);
		}
		return bean;
	}
	
	private void setParametro(PreparedStatement statement, Object val, int i)
			throws SQLException {
		if (val instanceof Integer) {
			statement.setInt(i, (Integer)val);
		} else if (val instanceof String) {
			statement.setString(i, (String)val);
		} else if (val instanceof java.util.Date) {
			statement.setDate(i, DbUtil.getSqlDate((java.util.Date)val));
		}
	}
	
	
	public void apagar(Object ... ids) throws DaoException {
		Connection conn = DbUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;
		try {

			System.out.println("Query : " + this.queryApagar);
					
			statement = conn.prepareStatement(this.queryApagar);
	
			Object val = null;
			int i = 1;
			for (;i <= ids.length; i++) {
				val = ids[i - 1];
				setParametro(statement, val, i);
			}
	
			statement.execute();
			
		} catch (SQLException e) {
			throw new DaoException(e);
		} finally {
			DbUtil.close(conn, statement, result);
		}
	}	
	
	
	public void salvar(T bean) throws DaoException {
		Connection conn = DbUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;
		try {

			System.out.println("Query : " + this.querySalvar);
			
			statement = conn.prepareStatement(this.querySalvar);
			
			setParametrosUpdate(statement, bean);
			
			statement.executeUpdate();
			
		} catch (SQLException e) {
			throw new DaoException(e);
		} finally {
			DbUtil.close(conn, statement, result);
		}
	}
	

	
	public void criar(T bean) throws DaoException {
		int novoId = getProximoValorSequence();

		Connection conn = DbUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet result = null;
		try {

			System.out.println("Query : " + this.queryCriar);
						
			statement = conn.prepareStatement(this.queryCriar);
			
//			ISSO EH ERRADO!!!!!!RETIRAR A TRIGGER PARA A SEQUENCE
			int novoId2 = novoId - 1;
			setParametrosInsert(statement, bean, novoId2);
			
			statement.executeUpdate();
			
			
		} catch (SQLException e) {
			throw new DaoException(e);
		} finally {
			DbUtil.close(conn, statement, result);
		}
	}
	
	protected abstract void setParametrosUpdate(PreparedStatement statement, T bean)  throws SQLException ;
	
	protected abstract void setParametrosInsert(PreparedStatement statement, T bean, int novoId)  throws SQLException ;
	
}
