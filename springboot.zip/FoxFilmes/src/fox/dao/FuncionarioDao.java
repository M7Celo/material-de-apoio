package fox.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import fox.bean.Funcionario;
import fox.exception.DaoException;

public class FuncionarioDao extends DaoBase<Funcionario> {
	
	private static final String SEQUENCE = "CAD_FUNCIONARIO_SEQ";
	
	private static final String BUSCAR_POR_ID = "SELECT COD_FUNCIONARIO, NOME_FUNCIONARIO, SENHA_FUNCIONARIO, NIVEL_ACESSO FROM CAD_FUNCIONARIO WHERE COD_FUNCIONARIO = ? ";
	
	private static final String BUSCAR_TODOS = "SELECT COD_FUNCIONARIO, NOME_FUNCIONARIO, SENHA_FUNCIONARIO, NIVEL_ACESSO FROM CAD_FUNCIONARIO ";
	
	private static final String SALVAR = "UPDATE CAD_FUNCIONARIO SET NOME_FUNCIONARIO = ?, SENHA_FUNCIONARIO = ?, NIVEL_ACESSO = ? WHERE COD_FUNCIONARIO = ? ";
	
	private static final String APAGAR = "DELETE FROM CAD_FUNCIONARIO WHERE COD_FUNCIONARIO = ? ";
	
	private static final String CRIAR = "insert into CAD_FUNCIONARIO(COD_FUNCIONARIO, NOME_FUNCIONARIO, SENHA_FUNCIONARIO, NIVEL_ACESSO) values( ?, ?, ?, ?)";

	public FuncionarioDao() {
		
		super(
//				NOME SEQUENCE
				SEQUENCE, 
				
//				SELECT POR ID'S(BUSCAR POR ID'S)
				BUSCAR_POR_ID, 

//				BUSCAR TODOS
				BUSCAR_TODOS,
				
//				SALVAR
				SALVAR,
				
//				APAGAR
				APAGAR, 
				
//				CRIAR
				CRIAR);
	}

	@Override
	protected Funcionario getBean(ResultSet result) throws SQLException {
		Funcionario bean = new Funcionario();
		bean.setCodFuncionario(result.getInt("COD_FUNCIONARIO"));
		bean.setNomeFuncionario(result.getString("NOME_FUNCIONARIO"));
		bean.setSenha(result.getString("SENHA_FUNCIONARIO"));
		bean.setNivelAcesso(result.getInt("NIVEL_ACESSO"));
		return bean;
	}

	@Override
	protected void setParametrosUpdate(
			PreparedStatement statement,
			Funcionario bean) throws SQLException {
		
		statement.setString(1, bean.getNomeFuncionario());
		statement.setString(2, bean.getSenha());
		statement.setInt(3, bean.getNivelAcesso());
		statement.setInt(4, bean.getCodFuncionario());
	}

	@Override
	protected void setParametrosInsert(
			PreparedStatement statement,
			Funcionario bean, 
			int novoId) throws SQLException {
		bean.setCodFuncionario(novoId);
		
		statement.setInt(1, bean.getCodFuncionario());
		statement.setString(2, bean.getNomeFuncionario());
		statement.setString(3, bean.getSenha());
		statement.setInt(4, bean.getNivelAcesso());
	}
}
