package fox.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fox.bean.Filme;
import fox.util.db.DbUtil;

public class FilmeDao extends DaoBase<Filme> {
	
	private static final String SEQUNCE = "CAD_FILME_SEQ";
	
	private static final String BUSCAR_POR_ID = "SELECT COD_FILME," +
				"NOME_FILME, " +
				"CATEGORIA_FILME, " +
				"PRODUTORA_FILME, " +
				"DATA_LANCAMENTO, " +
				"EXIBICAO_ATE, " + 
				"PAIS_ORIGEM, " +
				"IDIOMA_FILME, " + 
				"CLASSIFICACAO_ETARIA, " +  
				"DUBLADO, " +
				"LEGENDADO, "  +
				"FORA_EXIBICAO " +
				"FROM CAD_FILME WHERE COD_FILME = ? ";
	
	private static final String BUSCAR_TODOS = "SELECT COD_FILME, " +
				"NOME_FILME, " +
				"CATEGORIA_FILME, " +
				"PRODUTORA_FILME," +
				"DATA_LANCAMENTO, " +
				"EXIBICAO_ATE, " +
				"PAIS_ORIGEM, " +
				"IDIOMA_FILME, " + 
				"CLASSIFICACAO_ETARIA, " +  
				"DUBLADO, " +
				"LEGENDADO, "  +
				"FORA_EXIBICAO " + 
				"FROM CAD_FILME ";
	
	private static final String SALVAR = "UPDATE CAD_FILME SET " +
				"NOME_FILME = ?, " +
				"CATEGORIA_FILME = ? ," +
				"PRODUTORA_FILME = ?, " +
				"DATA_LANCAMENTO = ?, " +
				"EXIBICAO_ATE = ?, " + 
				"PAIS_ORIGEM = ?, " +
				"IDIOMA_FILME = ?, " + 
				"CLASSIFICACAO_ETARIA = ?, " +  
				"DUBLADO = ?, " +
				"LEGENDADO = ?, "  +
				"FORA_EXIBICAO = ? " +
				"WHERE COD_FILME = ? ";
	
	private static final String APAGAR = "DELETE FROM CAD_FILME WHERE COD_FILME = ? ";
	
	private static final String CRIAR = "" +
			"insert into CAD_FILME(" +
			"COD_FILME, " +
			"NOME_FILME, " +
			"CATEGORIA_FILME, " +
			"PRODUTORA_FILME, " +
			"DATA_LANCAMENTO, " +
			"EXIBICAO_ATE, " + 
			"PAIS_ORIGEM, " +
			"IDIOMA_FILME, " + 
			"CLASSIFICACAO_ETARIA," +  
			"DUBLADO, " +
			"LEGENDADO, "  +
			"FORA_EXIBICAO) " +
			"values( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";

	public FilmeDao() {
		super(
//				NOME SEQUENCE
				SEQUNCE, 
				
//				SELECT POR ID'S(BUSCAR POR ID'S)
				BUSCAR_POR_ID, 

//				BUSCAR TODOS
				BUSCAR_TODOS,
				
//				SALVAR
				SALVAR,
				
//				APAGAR
				APAGAR, 
				
//				CRIAR
				CRIAR);
	}

	@Override
	protected Filme getBean(ResultSet result) throws SQLException {
		Filme bean = new Filme();
		bean.setCodFilme(result.getInt("COD_FILME"));
		bean.setNomeFilme(result.getString("NOME_FILME"));
		bean.setCategoriaFilme(result.getString("CATEGORIA_FILME"));
		bean.setProdutoraFilme(result.getString("PRODUTORA_FILME"));
		bean.setDataLancamento(result.getDate("DATA_LANCAMENTO"));
		bean.setExibicaoAte(result.getDate("EXIBICAO_ATE"));
		bean.setPaisOrigem(result.getString("PAIS_ORIGEM"));
		bean.setIdiomaFilme(result.getString("IDIOMA_FILME"));
		bean.setClassificacaoEtaria(result.getString("CLASSIFICACAO_ETARIA"));
		bean.setDublado(result.getString("DUBLADO"));
		bean.setLegendado(result.getString("LEGENDADO"));
		bean.setForaExibicao(result.getString("FORA_EXIBICAO"));
		return bean;
	}

	@Override
	protected void setParametrosUpdate(
			PreparedStatement statement,
			Filme bean)
			throws SQLException {
		
		statement.setString(1, bean.getNomeFilme());
		statement.setString(2, bean.getCategoriaFilme());
		statement.setString(3, bean.getProdutoraFilme());
		statement.setDate(4, DbUtil.getSqlDate(bean.getDataLancamento()));
		statement.setDate(5, DbUtil.getSqlDate(bean.getExibicaoAte()));
		statement.setString(6, bean.getPaisOrigem());
		statement.setString(7, bean.getIdiomaFilme());
		statement.setString(8, bean.getClassificacaoEtaria());
		statement.setString(9, bean.getDublado());
		statement.setString(10, bean.getLegendado());
		statement.setString(11, bean.getForaExibicao());
		statement.setInt(12, bean.getCodFilme());		
	}

	@Override
	protected void setParametrosInsert(
			PreparedStatement statement,
			Filme bean,
			int novoId) throws SQLException {
		
		statement.setInt(1, bean.getCodFilme());
		statement.setString(2, bean.getNomeFilme());
		statement.setString(3, bean.getCategoriaFilme());
		statement.setString(4, bean.getProdutoraFilme());
		statement.setDate(5, DbUtil.getSqlDate(bean.getDataLancamento()));
		statement.setDate(6, DbUtil.getSqlDate(bean.getExibicaoAte()));
		statement.setString(7, bean.getPaisOrigem());
		statement.setString(8, bean.getIdiomaFilme());
		statement.setString(9, bean.getClassificacaoEtaria());
		statement.setString(10, bean.getDublado());
		statement.setString(11, bean.getLegendado());
		statement.setString(12, bean.getForaExibicao());
	}

}
