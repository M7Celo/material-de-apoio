package fox.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fox.bean.Valor;

public class ValorDao extends DaoBase<Valor> {
	
	private static final String SEQUENCE = "CAD_VALORES_SEQ";
	
	private static final String BUSCAR_POR_ID = "SELECT " +
			"COD_VALORES, " +
			"NOME_FILME, " +
			"VALOR_FILME " +
			"FROM CAD_VALORES " +
			"WHERE COD_VALORES = ? ";
	
	private static final String BUSCAR_TODOS = "SELECT " +
			"COD_VALORES, " +
			"NOME_FILME, " +
			"VALOR_FILME " +
			"FROM CAD_VALORES ";
	
	private static final String SALVAR = "UPDATE CAD_VALORES SET " +
			"NOME_FILME = ?, " +
			"VALOR_FILME = ? " +
			"WHERE COD_VALORES = ? ";

	private static final String APAGAR = "DELETE FROM CAD_VALORES WHERE COD_VALORES = ? ";
	
	private static final String CRIAR = "insert into CAD_VALORES(" +
			"COD_VALORES, " +
			"NOME_FILME, " +
			"VALOR_FILME ) values(?, ?, ?)";
	
	public ValorDao() {

		super(
//				NOME SEQUENCE
				SEQUENCE, 
				
//				SELECT POR ID'S(BUSCAR POR ID'S)
				BUSCAR_POR_ID, 

//				BUSCAR TODOS
				BUSCAR_TODOS,
				
//				SALVAR
				SALVAR,
				
//				APAGAR
				APAGAR, 
				
//				CRIAR
				CRIAR);
	}

	@Override
	protected Valor getBean(ResultSet result) throws SQLException {
		Valor bean = new Valor();
		bean.setCodValor(result.getInt("COD_VALORES"));
		bean.setNomeFilme(result.getString("NOME_FILME"));
		bean.setValorFilme(result.getString("VALOR_FILME"));
		return bean;
	}

	@Override
	protected void setParametrosUpdate(
			PreparedStatement statement,
			Valor bean)
			throws SQLException {
		
		statement.setString(1, bean.getNomeFilme());
		statement.setString(2, bean.getValorFilme());
		statement.setInt(3, bean.getCodValor());
		
	}

	@Override
	protected void setParametrosInsert(
			PreparedStatement statement,
			Valor bean,
			int novoId) throws SQLException {
		
		statement.setInt(1, bean.getCodValor());
		statement.setString(2, bean.getNomeFilme());
		statement.setString(3, bean.getValorFilme());
		
	}	

}
