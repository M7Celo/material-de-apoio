package fox.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fox.bean.Sessao;
import fox.util.db.DbUtil;

public class SessaoDao extends DaoBase<Sessao> {
	
	private static final String SEQUENCE = "CAD_SESSAO_SEQ";
	
	private static final String BUSCAR_POR_ID = "SELECT " +
			"COD_SESSAO ,"+ 
			"NOME_SESSAO, " + 
			"HORARIO_INICIAL, " +
			"HORARIO_FINAL, "+ 
			"COD_SALA, " +
			"COD_FILME, " +
			"NUM_SALA, " +
			"NOME_FILME, " +
			"QTDPOLDISP, " +
			"QTDPOLESP, " +
			"QTDPOLRES, " +
			"VALOR_FILME "+
			"FROM CAD_SESSAO WHERE COD_SESSAO = ? ";
	
	private static final String BUSCAR_TODOS = "SELECT COD_SESSAO, "+ 
			"NOME_SESSAO, " + 
			"HORARIO_INICIAL, " +
			"HORARIO_FINAL, "+ 
			"COD_SALA, " +
			"COD_FILME, " +
			"NUM_SALA, " +
			"NOME_FILME, " +
			"QTDPOLDISP, " +
			"QTDPOLESP, " +
			"QTDPOLRES, " +
			"VALOR_FILME "+
			"FROM CAD_SESSAO ";
	
	private static final String SALVAR = "UPDATE CAD_SESSAO " +
			"SET " +
			" NOME_SESSAO = ? , " +
			" HORARIO_INICIAL = ?," +
			" HORARIO_FINAL = ? , " +
			" COD_SALA = ?, " +
			" COD_FILME = ?, " +
			" NUM_SALA = ?, " +
			" NOME_FILME = ?, " +
			"QTDPOLDISP = ?, " +
			"QTDPOLESP = ?, "+
			"QTDPOLRES = ?, " +
			"VALOR_FILME = ? "+
			"WHERE COD_SESSAO = ? ";
	
	private static final String APAGAR = "DELETE FROM CAD_SESSAO WHERE COD_SESSAO = ? ";
	
	private static final String CRIAR = "insert into CAD_SESSAO(" +
			" COD_SESSAO, " +
			" NOME_SESSAO, " +
			" HORARIO_INICIAL, " +
			" HORARIO_FINAL, " +
			" COD_SALA, " +
			" COD_FILME, " +
			" NUM_SALA, " +
			" NOME_FILME," +
			"QTDPOLDISP, " +
			"QTDPOLESP, " +
			"QTDPOLRES, "+
			"VALOR_FILME) values( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	public SessaoDao() {
		
		super(
//				NOME SEQUENCE
				SEQUENCE, 
				
//				SELECT POR ID'S(BUSCAR POR ID'S)
				BUSCAR_POR_ID, 

//				BUSCAR TODOS
				BUSCAR_TODOS,
				
//				SALVAR
				SALVAR,
				
//				APAGAR
				APAGAR, 
				
//				CRIAR
				CRIAR);
	}

	@Override
	protected Sessao getBean(ResultSet result) throws SQLException {
		Sessao bean = new Sessao();
		bean.setCodigoSessao(result.getInt("COD_SESSAO"));
		bean.setNomeSessao(result.getString("NOME_SESSAO"));
		bean.setHorarioInicial(result.getString("HORARIO_INICIAL"));
		bean.setHorarioFinal(result.getString("HORARIO_FINAL"));
		bean.setCodigoSala(result.getInt("COD_SALA"));
		bean.setCodigoFilme(result.getInt("COD_FILME"));
		bean.setNumSala(result.getInt("NUM_SALA"));
		bean.setNomeFilme(result.getString("NOME_FILME"));
		bean.setQtdpoldis(result.getInt("QTDPOLDISP"));
		bean.setQtdpolesp(result.getInt("QTDPOLESP"));
		bean.setQtdpolres(result.getInt("QTDPOLRES"));
		bean.setValorFilme(result.getString("VALOR_FILME"));
		return bean;	}

	@Override
	protected void setParametrosUpdate(
			PreparedStatement statement,
			Sessao bean)
			throws SQLException {
			
		statement.setString(1, bean.getNomeSessao());
		statement.setString(2, bean.getHorarioInicial());
		statement.setString(3, bean.getHorarioFinal());
		statement.setInt(4, bean.getCodigoSala());
		statement.setInt(5, bean.getCodigoFilme());
		statement.setInt(6, bean.getNumSala());
		statement.setString(7, bean.getNomeFilme());
		statement.setInt(8, bean.getQtdpoldis());
		statement.setInt(9, bean.getQtdpolesp());
		statement.setInt(10, bean.getQtdpolres());
		statement.setString(11, bean.getValorFilme());
		statement.setInt(12, bean.getCodigoSessao());
	}

	@Override
	protected void setParametrosInsert(
			PreparedStatement statement,
			Sessao bean,
			int novoId) throws SQLException {
		
		statement.setInt(1, bean.getCodigoSessao());
		statement.setString(2, bean.getNomeSessao());
		statement.setString(3, bean.getHorarioInicial());
		statement.setString(4, bean.getHorarioFinal());
		statement.setInt(5, bean.getCodigoSala());
		statement.setInt(6, bean.getCodigoFilme());
		statement.setInt(7, bean.getNumSala());
		statement.setString(8, bean.getNomeFilme());
		statement.setInt(9, bean.getQtdpoldis());
		statement.setInt(10, bean.getQtdpolesp());
		statement.setInt(11, bean.getQtdpolres());
		statement.setString(12, bean.getValorFilme());
		
	}

}
