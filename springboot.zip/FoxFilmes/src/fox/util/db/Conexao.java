package fox.util.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;
//import javax.swing.JOptionPane;


public class Conexao{
    
    private static final String URL_DATABASE = "jdbc:oracle:thin:@localhost:1521";
    private static final String DRIVER_JDBC = "oracle.jdbc.driver.OracleDriver";
	
	private static final String USUARIO_DB = "M7Celo";
	private static final String SENHA_USUARIO_DB = "830925";
        
        private Connection conexao;
        public Statement statement = null;
	public ResultSet resultset = null;
        
        public boolean Conecta() {
            
            boolean result = true;
            
            try{
                Class.forName(DRIVER_JDBC);
		conexao = DriverManager.getConnection(URL_DATABASE, USUARIO_DB, SENHA_USUARIO_DB);
               // JOptionPane.showMessageDialog(null,"conectou");
                
            }catch(ClassNotFoundException Driver){
               // JOptionPane.showMessageDialog(null,"Driver não localizado: "+Driver);
                result = false; 
                
            }catch(SQLException Fonte){
               // JOptionPane.showMessageDialog(null,"Erro na conexão "
                //        +"com a fonte de dados"+Fonte);
                result = false; 
            }
            return result;
        }
        
        public void Desconecta(){
            
            boolean result = true;
            
            try{
                conexao.close();
                //JOptionPane.showMessageDialog(null,"Conex�o Encerrada");
            }catch(SQLException ErroSQL){
                /*JOptionPane.showMessageDialog(null,"N�o foi poss�vel"+
                        "encerrar a conex�o"+ErroSQL.getMessage()); */
                result = false;
            }
            
        }
        public void ExecuteSQL(String sql){
            try{
                statement = conexao.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
                resultset = statement.executeQuery(sql);
                
            }catch(SQLException sqlex){
                //JOptionPane.showMessageDialog(null,sqlex.getMessage()); 
            }
        }
}