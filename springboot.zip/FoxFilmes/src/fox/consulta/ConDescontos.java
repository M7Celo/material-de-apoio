package fox.consulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Descontos;
import fox.dao.DescontosDao;
import fox.exception.DaoException;
public class ConDescontos extends JFrame implements ActionListener {
	
	private JLabel lbcod_promo;
	private JComboBox cbcodDesc;
	private JLabel lbconv;
	private JTextField tfconv;
	private JLabel lbsind;
	private JTextField tfsind;
	private JLabel lbpromo;
	private JTextField tfpromo;
	private JLabel lbvaldescconv;
	private JTextField tfvaldescconv;
	private JLabel lbvaldescsind;
	private JTextField tfvaldescsind;
	private JLabel lbvaldescpromo;
	private JTextField tfvaldescpromo;
	private JLabel lbdescfixo;
	private JTextField tfdescfixo;
	private JButton btbuscar;
	private JButton btcancelar;
	private DescontosDao descontosDao;
	private Descontos descontos;
	
	public ConDescontos (){
		
		/* Cria��o de Objetos */
		setTitle("Consulta Descontos");
		lbcod_promo = new JLabel("C�digo Descontos");
		cbcodDesc = new JComboBox();
		lbconv = new JLabel("Conv�nios");
		tfconv = new JTextField ();
		lbsind = new JLabel("Sindicatos");
		tfsind = new JTextField (5);
		lbpromo = new JLabel("Promocional");
		tfpromo = new JTextField (5);
		lbvaldescconv = new JLabel("Valor de Descontos");
		tfvaldescconv = new JTextField (5);
		lbvaldescsind = new JLabel("Valor de Descontos");
		tfvaldescsind = new JTextField (5);
		lbvaldescpromo = new JLabel("Valor de Descontos");
		tfvaldescpromo = new JTextField (5);
		lbdescfixo = new JLabel("Descontos Fixo");
		tfdescfixo = new JTextField (5);
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		
		btbuscar.addActionListener(this);
		cbcodDesc.addActionListener(this);
		btcancelar.addActionListener(this);
		
		descontosDao = new DescontosDao();
		descontos = new Descontos();
		
		try {
			List<Descontos> lista = descontosDao.buscarTodos();
		
			for (Descontos d : lista) {
				cbcodDesc.addItem(d.getCodDescontos()); 
			}
	
		/* Coordenadas */
		setBounds(0, 0, 400, 300);
		lbcod_promo.setBounds(20, 10, 150, 20);
		cbcodDesc.setBounds(130, 10, 80, 20);
		lbconv.setBounds(20, 40, 100, 25);
		tfconv.setBounds(85, 40, 300, 20);
		lbvaldescconv.setBounds(20, 65, 150, 25);
		tfvaldescconv.setBounds(135, 65, 100, 20);
		lbsind.setBounds(20, 90, 100, 25);
		tfsind.setBounds(85, 90, 300, 20);
		lbvaldescsind.setBounds(20, 115, 150, 25);
		tfvaldescsind.setBounds(135, 115, 100, 20);
		lbpromo.setBounds(20, 140, 100, 25);
		tfpromo.setBounds(95, 140, 290, 20);
		lbvaldescpromo.setBounds(20, 165, 150, 25);
		tfvaldescpromo.setBounds(135, 165, 100, 20);
		lbdescfixo.setBounds(20, 190, 150, 25);
		tfdescfixo.setBounds(115, 190, 120, 20);
		btbuscar.setBounds(20, 230, 90, 25);
		btcancelar.setBounds(280, 230, 90, 25);
		
		/* Execu��o da Tela */
		add(lbcod_promo);
		add(cbcodDesc);
		add(lbconv);
		add(tfconv);
		add(lbvaldescconv);
		add(tfvaldescconv);
		add(lbsind);
		add(tfsind);
		add(lbvaldescsind);
		add(tfvaldescsind);
		add(lbpromo);
		add(tfpromo);
		add(lbvaldescpromo);
		add(tfvaldescpromo);
		add(lbdescfixo);
		add(tfdescfixo);
		add(btbuscar);
		add(btcancelar);
		
		setLayout(null);
		setVisible(true);
		setResizable(false);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodDesc.getSelectedItem());
				int codDesconto = Integer.parseInt(item);
				descontos = descontosDao.buscarPorId(codDesconto);	
				
				tfconv.setText(descontos.getNomeConvenio());
				tfvaldescconv.setText(descontos.getValorConvenio());
				tfsind.setText(descontos.getNomeSind());
				tfvaldescsind.setText(descontos.getValorSind());
				tfpromo.setText(descontos.getNomePromo());
				tfvaldescpromo.setText(descontos.getValorPromo());
				tfdescfixo.setText(descontos.getDescontosFixo());
					JOptionPane.showMessageDialog(null, "Descontos Consultado com Sucesso!");
				}if (btcancelar == event.getSource()) {
					this.dispose();
				}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
}