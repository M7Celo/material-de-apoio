package fox.consulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import fox.bean.Filme;
import fox.dao.FilmeDao;
import fox.exception.DaoException;


public class ConFilmes extends JFrame implements ActionListener {
	
	private JLabel lbcod_filme;
	private JComboBox cbcodFilme;
	private JLabel lbnomef;
	private JTextField tfnomef;
	private JLabel lbcateg;
	private JTextField tfcateg;
	private JLabel lbprodf;
	private JTextField tfprodf;
	private JLabel lbdatal;
	private JTextField tfdatal;
	private JLabel lbtempoe;
	private JTextField tftempoe;
	private JLabel lbporig;
	private JTextField tfporig;
	private JLabel lbidioma;
	private JTextField tfidioma;
	private JLabel lbCetaria;
	private JTextField tfCetaria;
	private JButton btbuscar;
	private JButton btcancelar;
	private JLabel lbdublado;
	private JLabel lblegendado;
	private JLabel lbforaex;
	private JTextField tfdublado;
	private JTextField tflegendado;
	private JTextField tfforaex;
	private FilmeDao filmedao;
	private Filme filme;
	
	public ConFilmes () {	
		
		/* Cria��o de Objetos */		
		setTitle("Consulta Filmes");
		lbcod_filme = new JLabel("Cod_Filme");
		cbcodFilme = new JComboBox();
		lbnomef = new JLabel("Nome");
		tfnomef = new JTextField ();
		lbcateg = new JLabel("Categoria");
		tfcateg = new JTextField ();
		lbprodf = new JLabel("Produtora");
		tfprodf = new JTextField ();
		lbdatal = new JLabel("Data de Lan�amento");
		tfdatal = new JTextField ();
		lbtempoe = new JLabel("Exebi��o at�:");
		tftempoe = new JTextField ();
		lbporig = new JLabel("Pa�s de Origem");
		tfporig = new JTextField ();
		lbidioma = new JLabel("Idioma");
		tfidioma = new JTextField ();
		lbCetaria = new JLabel("Classifica��o Et�ria");
		tfCetaria = new JTextField ();
		btbuscar = new JButton("Buscar");
		btcancelar = new JButton("Cancelar");
		lbdublado = new JLabel("Dublado");
		lblegendado = new JLabel("legendado");
		lbforaex = new JLabel("Fora de Exibi��o");
		tfdublado = new JTextField();
		tflegendado = new JTextField();
		tfforaex = new JTextField();
		
		cbcodFilme.addActionListener(this);
		btbuscar.addActionListener(this);
		btcancelar.addActionListener(this);
		
		filmedao = new FilmeDao();
		filme = new Filme();
		
		try {
			List<Filme> lista = filmedao.buscarTodos();
		
			for (Filme f : lista) {
				cbcodFilme.addItem(f.getCodFilme()); 
			}
		
		/* Coordenadas */
		setBounds(0, 0, 560, 290);
		lbcod_filme.setBounds(20, 20, 80, 25);
		cbcodFilme.setBounds(85, 20, 80, 20);
		lbnomef.setBounds(20, 50, 100, 25);
		tfnomef.setBounds(60, 50, 300, 20);
		lbcateg.setBounds(20, 70, 100, 25);
		tfcateg.setBounds(85, 70, 150, 20);
		lbprodf.setBounds(20, 110, 100, 25);
		tfprodf.setBounds(80, 110, 300, 20);
		lbdatal.setBounds(20, 110, 150, 25);
		tfdatal.setBounds(142, 110, 100, 20);
		lbporig.setBounds(20, 130, 100, 25);
		tfporig.setBounds(112, 130, 200, 20);
		lbidioma.setBounds(20, 150, 150, 25);
		tfidioma.setBounds(60, 150, 251, 20);
		lbCetaria.setBounds(20, 170, 150, 25);
		tfCetaria.setBounds(140, 170, 80, 20);
		lbdublado.setBounds(20, 190, 75, 20);
		lblegendado.setBounds(120, 190, 90, 20);
		lbforaex.setBounds(280, 190, 130, 20);
		tfdublado.setBounds(70, 190, 40, 20);
		tflegendado.setBounds(180, 190, 40, 20);
		tfforaex.setBounds(375, 190, 40, 20);
		lbnomef.setBounds(20, 50, 100, 20);
		tfnomef.setBounds(62, 50, 300, 20);
		lbprodf.setBounds(20, 90, 100, 20);
		tfprodf.setBounds(80, 90, 300, 20);
		lbtempoe.setBounds(246, 110, 150, 20);
		tftempoe.setBounds(332, 110, 100, 20);
		btbuscar.setBounds(20,  220, 90, 20);
		btcancelar.setBounds(440,  220, 90, 20);
		
		
		/* Execu��o da Tela */
		add(lbcod_filme);
		add(cbcodFilme);
		add(lbnomef);
		add(tfnomef);
		add(lbcateg);
		add(tfcateg);
		add(lbprodf);
		add(tfprodf);
		add(lbdatal);
		add(tfdatal);
		add(lbtempoe);
		add(tftempoe);
		add(lbporig);
		add(tfporig);
		add(lbidioma);
		add(tfidioma);
		add(lbCetaria);
		add(tfCetaria);
		add(btbuscar);
		add(btcancelar);
		add(tfdublado);
		add(lbdublado);
		add(lblegendado);
		add(lbforaex);
		add(tflegendado);
		add(tfforaex);
				
		setLayout(null);
		setResizable(false);
		setVisible(true);
		
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
			this.dispose();
			e.printStackTrace();
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodFilme.getSelectedItem());
				int codFilme = Integer.parseInt(item);
				filme = filmedao.buscarPorId(codFilme);	
				
				tfnomef.setText(filme.getNomeFilme());
				tfcateg.setText(filme.getCategoriaFilme());
				tfprodf.setText(filme.getProdutoraFilme());
				String datal = String.valueOf(filme.getDataLancamento());
				tfdatal.setText(datal);
				String exibi = String.valueOf(filme.getExibicaoAte());
				tftempoe.setText(exibi);
				tfporig.setText(filme.getPaisOrigem());
				tfidioma.setText(filme.getIdiomaFilme());
				tfCetaria.setText(filme.getClassificacaoEtaria());
				tfdublado.setText(filme.getDublado());
				tflegendado.setText(filme.getLegendado());
				tfforaex.setText(filme.getForaExibicao());				
					JOptionPane.showMessageDialog(null, "Filme Consultado com Sucesso!");
				}if (btcancelar == event.getSource()) {
					this.dispose();
				}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}		
	}
}