package fox.consulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import fox.bean.Descontos;
import fox.bean.Sessao;
import fox.dao.DescontosDao;
import fox.dao.SessaoDao;
import fox.exception.DaoException;


public class ConSessao extends JFrame implements ActionListener {
	
	private JLabel lbcod_sessao;
	private JComboBox cbcodSessao;
	private JLabel lbcod_sala;
	private JTextField tfcod_sala;
	private JTextField tfnumsala;
	private JLabel lbcod_filme;
	private JTextField tfcod_filme;
	private JTextField tfnomef;
	private JButton btbuscar;
	private JButton btcancelar;
	private JLabel lbnomesessao;
	private JTextField tfnomesessao;
	private JLabel lbhorsessao;
	private JLabel lbhorsessaoinicial;
	private JTextField tfhorsessaoinicial;
	private JLabel lbhorsessaofinal;
	private JTextField tfhorsessaofinal;
	private JLabel lbnumsala;
	private JLabel lbnomef;
	private SessaoDao sessaodao;
	private Sessao sessao;
	
	public ConSessao () {
		
			/* Cria��o de Objetos */
			setTitle("Consulta Sess�o");
			lbcod_sessao = new JLabel("Cod_Sess�o");
			cbcodSessao = new JComboBox();
			lbcod_sala = new JLabel("Cod_sala");
			tfcod_sala = new JTextField ();
			tfnumsala = new JTextField();
			lbcod_filme = new JLabel("Cod_Filme");
			tfcod_filme = new JTextField();
			tfnomef = new JTextField();
			btbuscar = new JButton("Buscar");
			btcancelar = new JButton("Cancelar");
			lbnomesessao = new JLabel("Nome Sess�o");
			tfnomesessao = new JTextField ();
			lbhorsessao = new JLabel("Hor�rio Sess�o");
			lbhorsessaoinicial = new JLabel("In�cio");
			tfhorsessaoinicial = new JTextField ();
			lbhorsessaofinal = new JLabel("T�rmino");
			tfhorsessaofinal = new JTextField ();
			lbnumsala = new JLabel("Num Sala");
			lbnomef = new JLabel("Nome Filme");
			
			btbuscar.addActionListener(this);
			cbcodSessao.addActionListener(this);
			btcancelar.addActionListener(this);
			
			sessaodao = new SessaoDao();
			sessao = new Sessao();
			
			try {
				List<Sessao> lista = sessaodao.buscarTodos();
			
				for (Sessao sessao : lista) {
					cbcodSessao.addItem(sessao.getCodigoSessao()); 
				}
			
			/* Coordenadas */
			setBounds(0, 0, 480, 220);
			lbcod_sessao.setBounds(20, 10, 75, 25);
			cbcodSessao.setBounds(95, 10, 80, 20);
			lbnomesessao.setBounds(20, 40, 130, 20);
			tfnomesessao.setBounds(105, 40, 200, 20);
			lbhorsessao.setBounds(20, 65, 100, 20);
			lbhorsessaoinicial.setBounds(160, 65, 100, 20);
			tfhorsessaoinicial.setBounds(195, 65, 70, 20);
			lbhorsessaofinal.setBounds(300, 65, 100, 20);
			tfhorsessaofinal.setBounds(350, 65, 70, 20);
			lbcod_sala.setBounds(20, 90, 150, 20);
			tfcod_sala.setBounds(82, 90, 70, 20);
			lbcod_filme.setBounds(165, 90, 150, 20);
			tfcod_filme.setBounds(230, 90, 70, 20);
			btbuscar.setBounds(20,  150, 90, 25);
			btcancelar.setBounds(320,  150, 90, 25);
			lbnumsala.setBounds(20, 115, 80, 20);
			tfnumsala.setBounds(80, 115, 50, 20);
			lbnomef.setBounds(145, 115, 80, 20);
			tfnomef.setBounds(215, 115, 245, 20);
			
			/* Execu��o na Tela */
			add(lbcod_sessao);
			add(cbcodSessao);
			add(lbnomesessao);
			add(tfnomesessao);
			add(lbhorsessao);
			add(lbhorsessaoinicial);
			add(tfhorsessaoinicial);
			add(lbhorsessaofinal);
			add(tfhorsessaofinal);
			add(lbcod_sala);
			add(tfcod_sala);
			add(lbcod_filme);
			add(tfcod_filme);
			add(tfnumsala);
			add(tfnomef);
			add(btbuscar);
			add(btcancelar);
			add(lbnumsala);
			add(lbnomef);
			
			setLayout(null);
			setVisible(true);
			setResizable(false);
			
			} catch (DaoException e) {
				JOptionPane.showMessageDialog(this, "Erro ao acessar o banco de dados");
				this.dispose();
				e.printStackTrace();
			}
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		try {
			if(event.getSource() == this.btbuscar){
				String item = String.valueOf(cbcodSessao.getSelectedItem());
				int codSessao = Integer.parseInt(item);
				sessao = sessaodao.buscarPorId(codSessao);	
				
				tfnomesessao.setText(sessao.getNomeSessao());
				tfhorsessaoinicial.setText(sessao.getHorarioInicial());
				tfhorsessaofinal.setText(sessao.getHorarioFinal());
				tfcod_sala.setText(String.valueOf(sessao.getCodigoSala()));
				tfnumsala.setText(String.valueOf(sessao.getNumSala()));
				tfcod_filme.setText(String.valueOf(sessao.getCodigoFilme()));
				tfnomef.setText(sessao.getNomeFilme());
					JOptionPane.showMessageDialog(null, "Sess�o Consultada com Sucesso!");
				}if (btcancelar == event.getSource()) {
					this.dispose();
				}
			 
		} catch (DaoException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao acessar a base, contate seu fornecedor", "Erro", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
}
