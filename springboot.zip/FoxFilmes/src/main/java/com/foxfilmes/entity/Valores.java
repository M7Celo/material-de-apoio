package com.foxfilmes.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "valores")
public class Valores implements Serializable{

	private static final long serialVersionUID = -3608840533114410078L;
	
	@Id
	@NotNull
	@NotEmpty
	@Column(name="id_valores")
	private Long idValores;
	
	@NotNull
	@NotEmpty
	@Column(name="filme")
	private Filmes filme;
	
	@NotNull
	@NotEmpty
	@Column(name="valor_filme")
	private BigDecimal valorFilme;

	public Valores() {
		super();
	}

	public Valores(Long idValores, @NotNull @NotEmpty Filmes filme, @NotNull @NotEmpty BigDecimal valorFilme) {
		super();
		this.idValores = idValores;
		this.filme = filme;
		this.valorFilme = valorFilme;
	}

	public Long getIdValores() {
		return idValores;
	}

	public void setIdValores(Long idValores) {
		this.idValores = idValores;
	}

	public Filmes getFilme() {
		return filme;
	}

	public void setFilme(Filmes filme) {
		this.filme = filme;
	}

	public BigDecimal getValorFilme() {
		return valorFilme;
	}

	public void setValorFilme(BigDecimal valorFilme) {
		this.valorFilme = valorFilme;
	}

	@Override
	public String toString() {
		return "Valores [idValores=" + idValores + ", filme=" + filme + ", valorFilme=" + valorFilme + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idValores == null) ? 0 : idValores.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Valores other = (Valores) obj;
		if (idValores == null) {
			if (other.idValores != null)
				return false;
		} else if (!idValores.equals(other.idValores))
			return false;
		return true;
	}

}
