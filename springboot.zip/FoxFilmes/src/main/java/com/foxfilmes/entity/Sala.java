package com.foxfilmes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "sala")
public class Sala implements Serializable{

	private static final long serialVersionUID = -5566185806998459830L;
	
	@Id
	@NotNull
	@NotEmpty
	@Column(name = "id_sala")
	private Long idSala;
	
	@NotNull
	@NotEmpty
	@Column(name = "nome_sala")
	private String nomeSala;
	
	@NotNull
	@NotEmpty
	@Column(name = "qtd_poltrona")
	private Integer qtdPoltrona;
	
	@NotNull
	@NotEmpty
	@Column(name = "qtd_poltrona_disp")
	private Integer qtdPoltronaDisp;
	
	@Column(name = "qtd_poltrona_reser")
	private Integer qtdPoltronaReser;
	
	@Column(name = "qtd_poltrona_esp")
	private Integer qtdPoltronaEspecial;

	public Sala() {
		super();
	}


	public Sala(Long idSala, @NotNull @NotEmpty String nomeSala, @NotNull @NotEmpty Integer qtdPoltrona,
			Integer qtdPoltronaDisp, Integer qtdPoltronaReser, Integer qtdPoltronaEspecial) {
		super();
		this.idSala = idSala;
		this.nomeSala = nomeSala;
		this.qtdPoltrona = qtdPoltrona;
		this.qtdPoltronaDisp = qtdPoltronaDisp;
		this.qtdPoltronaReser = qtdPoltronaReser;
		this.qtdPoltronaEspecial = qtdPoltronaEspecial;
	}
	
	public Long getIdSala() {
		return idSala;
	}


	public void setIdSala(Long idSala) {
		this.idSala = idSala;
	}


	public String getNomeSala() {
		return nomeSala;
	}


	public void setNomeSala(String nomeSala) {
		this.nomeSala = nomeSala;
	}


	public Integer getQtdPoltrona() {
		return qtdPoltrona;
	}


	public void setQtdPoltrona(Integer qtdPoltrona) {
		this.qtdPoltrona = qtdPoltrona;
	}


	public Integer getQtdPoltronaDisp() {
		return qtdPoltronaDisp;
	}


	public void setQtdPoltronaDisp(Integer qtdPoltronaDisp) {
		this.qtdPoltronaDisp = qtdPoltronaDisp;
	}


	public Integer getQtdPoltronaReser() {
		return qtdPoltronaReser;
	}


	public void setQtdPoltronaReser(Integer qtdPoltronaReser) {
		this.qtdPoltronaReser = qtdPoltronaReser;
	}


	public Integer getQtdPoltronaEspecial() {
		return qtdPoltronaEspecial;
	}


	public void setQtdPoltronaEspecial(Integer qtdPoltronaEspecial) {
		this.qtdPoltronaEspecial = qtdPoltronaEspecial;
	}


	@Override
	public String toString() {
		return "Sala [idSala=" + idSala + ", nomeSala=" + nomeSala + ", qtdPoltrona=" + qtdPoltrona
				+ ", qtdPoltronaDisp=" + qtdPoltronaDisp + ", qtdPoltronaReser=" + qtdPoltronaReser
				+ ", qtdPoltronaEspecial=" + qtdPoltronaEspecial + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idSala == null) ? 0 : idSala.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sala other = (Sala) obj;
		if (idSala == null) {
			if (other.idSala != null)
				return false;
		} else if (!idSala.equals(other.idSala))
			return false;
		return true;
	}

}
