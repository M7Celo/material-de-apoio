package com.foxfilmes.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class VendaIngressos implements Serializable{
	
	private static final long serialVersionUID = -5914567062065914206L;
	
	@Id
	@NotNull
	@NotEmpty
	@Column(name="id_venda")
	private Long idVenda;
	
	@NotNull
	@NotEmpty
	@Column(name="numero_ingresso")
	private Integer numeroIngresso;
	
	@NotNull
	@NotEmpty
	@Column(name="sessao")
	private Sessao sessao;
	
	@NotNull
	@NotEmpty
	@Column(name="filmes")
	private Filmes filmes;
	
	@NotNull
	@NotEmpty
	@Column(name="descontos")
	private Descontos descontos;
	
	@NotNull
	@NotEmpty
	@Column(name="sala")
	private Sala sala;
	
	@NotNull
	@NotEmpty
	@Column(name="valores")
	private Valores valores;
	
	@NotNull
	@NotEmpty
	@Column(name="valor_recebido")
	private BigDecimal valorRecebido;
	
	@NotNull
	@NotEmpty
	@Column(name="troco")
	private BigDecimal troco;
	
	@NotNull
	@NotEmpty
	@Column(name="valor_entregue")
	private BigDecimal valorEntregue;
	
	@NotNull
	@NotEmpty
	@Column(name="data_hora_venda")
	private LocalDateTime dataHoraVenda;

	public VendaIngressos() {
		super();
	}

	public VendaIngressos(Long idVenda, @NotNull @NotEmpty Integer numeroIngresso, @NotNull @NotEmpty Sessao sessao,
			@NotNull @NotEmpty Filmes filmes, @NotNull @NotEmpty Descontos descontos, @NotNull @NotEmpty Sala sala,
			@NotNull @NotEmpty Valores valores, @NotNull @NotEmpty BigDecimal valorRecebido,
			@NotNull @NotEmpty BigDecimal troco, @NotNull @NotEmpty BigDecimal valorEntregue,
			@NotNull @NotEmpty LocalDateTime dataHoraVenda) {
		super();
		this.idVenda = idVenda;
		this.numeroIngresso = numeroIngresso;
		this.sessao = sessao;
		this.filmes = filmes;
		this.descontos = descontos;
		this.sala = sala;
		this.valores = valores;
		this.valorRecebido = valorRecebido;
		this.troco = troco;
		this.valorEntregue = valorEntregue;
		this.dataHoraVenda = dataHoraVenda;
	}

	public Long getIdVenda() {
		return idVenda;
	}

	public void setIdVenda(Long idVenda) {
		this.idVenda = idVenda;
	}

	public Integer getNumeroIngresso() {
		return numeroIngresso;
	}

	public void setNumeroIngresso(Integer numeroIngresso) {
		this.numeroIngresso = numeroIngresso;
	}

	public Sessao getSessao() {
		return sessao;
	}

	public void setSessao(Sessao sessao) {
		this.sessao = sessao;
	}

	public Filmes getFilmes() {
		return filmes;
	}

	public void setFilmes(Filmes filmes) {
		this.filmes = filmes;
	}

	public Descontos getDescontos() {
		return descontos;
	}

	public void setDescontos(Descontos descontos) {
		this.descontos = descontos;
	}

	public Sala getSala() {
		return sala;
	}

	public void setSala(Sala sala) {
		this.sala = sala;
	}

	public Valores getValores() {
		return valores;
	}

	public void setValores(Valores valores) {
		this.valores = valores;
	}

	public BigDecimal getValorRecebido() {
		return valorRecebido;
	}

	public void setValorRecebido(BigDecimal valorRecebido) {
		this.valorRecebido = valorRecebido;
	}

	public BigDecimal getTroco() {
		return troco;
	}

	public void setTroco(BigDecimal troco) {
		this.troco = troco;
	}

	public BigDecimal getValorEntregue() {
		return valorEntregue;
	}

	public void setValorEntregue(BigDecimal valorEntregue) {
		this.valorEntregue = valorEntregue;
	}

	public LocalDateTime getDataHoraVenda() {
		return dataHoraVenda;
	}

	public void setDataHoraVenda(LocalDateTime dataHoraVenda) {
		this.dataHoraVenda = dataHoraVenda;
	}

	@Override
	public String toString() {
		return "VendaIngressos [idVenda=" + idVenda + ", numeroIngresso=" + numeroIngresso + ", sessao=" + sessao
				+ ", filmes=" + filmes + ", descontos=" + descontos + ", sala=" + sala + ", valores=" + valores
				+ ", valorRecebido=" + valorRecebido + ", troco=" + troco + ", valorEntregue=" + valorEntregue
				+ ", dataHoraVenda=" + dataHoraVenda + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idVenda == null) ? 0 : idVenda.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VendaIngressos other = (VendaIngressos) obj;
		if (idVenda == null) {
			if (other.idVenda != null)
				return false;
		} else if (!idVenda.equals(other.idVenda))
			return false;
		return true;
	}
	
}
