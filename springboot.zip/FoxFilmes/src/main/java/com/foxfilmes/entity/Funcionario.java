package com.foxfilmes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "funcionario")
public class Funcionario implements Serializable{

	private static final long serialVersionUID = 5899462874843384293L;
	
	@Id
	@NotNull
	@NotEmpty
	@Column(name="id_funcionario")
	private Long idFuncionario;
	
	@NotNull
	@NotEmpty
	@Column(name="nome_funcionario")
	private String nomeFuncionario;
	
	@NotNull
	@NotEmpty
	@Column(name="login")
	private String login;
	
	@NotNull
	@NotEmpty
	@Size(min=8, max=16)
	@Column(name="senha")
	private String password;
	
	@NotNull
	@NotEmpty
	@Column(name="nivel_acesso")
	private String nivelAcesso;

	public Funcionario() {
		super();
	}

	public Funcionario(Long idFuncionario, String nomeFuncionario, String login, String password, String nivelAcesso) {
		super();
		this.idFuncionario = idFuncionario;
		this.nomeFuncionario = nomeFuncionario;
		this.login = login;
		this.password = password;
		this.nivelAcesso = nivelAcesso;
	}

	public Long getIdFuncionario() {
		return idFuncionario;
	}

	public void setIdFuncionario(Long idFuncionario) {
		this.idFuncionario = idFuncionario;
	}

	public String getNomeFuncionario() {
		return nomeFuncionario;
	}

	public void setNomeFuncionario(String nomeFuncionario) {
		this.nomeFuncionario = nomeFuncionario;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNivelAcesso() {
		return nivelAcesso;
	}

	public void setNivelAcesso(String nivelAcesso) {
		this.nivelAcesso = nivelAcesso;
	}

	@Override
	public String toString() {
		return "Funcionario [IdFuncionario=" + idFuncionario + ", nomeFuncionario=" + nomeFuncionario + ", login="
				+ login + ", password=" + password + ", nivelAcesso=" + nivelAcesso + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idFuncionario == null) ? 0 : idFuncionario.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Funcionario other = (Funcionario) obj;
		if (idFuncionario == null) {
			if (other.idFuncionario != null)
				return false;
		} else if (!idFuncionario.equals(other.idFuncionario))
			return false;
		return true;
	}
	
}
