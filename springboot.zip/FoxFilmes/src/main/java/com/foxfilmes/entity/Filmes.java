package com.foxfilmes.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "filmes")
public class Filmes implements Serializable{

	private static final long serialVersionUID = 8407686865182911393L;
	
	@Id
	@NotNull
	@NotEmpty
	@Column(name="id_filme")
	private Long idFilme;
	
	@NotNull
	@NotEmpty
	@Column(name="nome_filme")
	private String nomeFilme;
	
	@NotNull
	@NotEmpty
	@Column(name="categoria_filme")
	private String categoriaFilme;
	
	@NotNull
	@NotEmpty
	@Column(name="produtora_filme")
	private String produtoraFilme;
	
	@NotNull
	@NotEmpty
	@Column(name="data_lancamento")
	private Date dataLancamento;
	
	@NotNull
	@NotEmpty
	@Column(name="exibicao_ate")
	private Date exibicaoAte;
	
	@NotNull
	@NotEmpty
	@Column(name="pais_origem")
	private String paisOrigem;
	
	@NotNull
	@NotEmpty
	@Column(name="idioma")
	private String idioma;
	
	@NotNull
	@NotEmpty
	@Column(name="classificao_etaria")
	private String classificaoEtaria;
	
	@NotNull
	@NotEmpty
	@Column(name="dublado")
	private String dublado;
	
	@NotNull
	@NotEmpty
	@Column(name="legendado")
	private String legendado;
	
	@NotNull
	@NotEmpty
	@Column(name="fora_exibicao")
	private String foraExibicao;

	public Filmes() {
		super();
	}

	public Filmes(Long idFilme, String nomeFilme, String categoriaFilme, String produtoraFilme, Date dataLancamento,
			Date exibicaoAte, String paisOrigem, String idioma, String classificaoEtaria, String dublado,
			String legendado, String foraExibicao) {
		super();
		this.idFilme = idFilme;
		this.nomeFilme = nomeFilme;
		this.categoriaFilme = categoriaFilme;
		this.produtoraFilme = produtoraFilme;
		this.dataLancamento = dataLancamento;
		this.exibicaoAte = exibicaoAte;
		this.paisOrigem = paisOrigem;
		this.idioma = idioma;
		this.classificaoEtaria = classificaoEtaria;
		this.dublado = dublado;
		this.legendado = legendado;
		this.foraExibicao = foraExibicao;
	}
	
	public Long getIdFilme() {
		return idFilme;
	}

	public void setIdFilme(Long idFilme) {
		this.idFilme = idFilme;
	}

	public String getNomeFilme() {
		return nomeFilme;
	}

	public void setNomeFilme(String nomeFilme) {
		this.nomeFilme = nomeFilme;
	}

	public String getCategoriaFilme() {
		return categoriaFilme;
	}

	public void setCategoriaFilme(String categoriaFilme) {
		this.categoriaFilme = categoriaFilme;
	}

	public String getProdutoraFilme() {
		return produtoraFilme;
	}

	public void setProdutoraFilme(String produtoraFilme) {
		this.produtoraFilme = produtoraFilme;
	}

	public Date getDataLancamento() {
		return dataLancamento;
	}

	public void setDataLancamento(Date dataLancamento) {
		this.dataLancamento = dataLancamento;
	}

	public Date getExibicaoAte() {
		return exibicaoAte;
	}

	public void setExibicaoAte(Date exibicaoAte) {
		this.exibicaoAte = exibicaoAte;
	}

	public String getPaisOrigem() {
		return paisOrigem;
	}

	public void setPaisOrigem(String paisOrigem) {
		this.paisOrigem = paisOrigem;
	}

	public String getIdioma() {
		return idioma;
	}

	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}

	public String getClassificaoEtaria() {
		return classificaoEtaria;
	}

	public void setClassificaoEtaria(String classificaoEtaria) {
		this.classificaoEtaria = classificaoEtaria;
	}

	public String isDublado() {
		return dublado;
	}

	public void setDublado(String dublado) {
		this.dublado = dublado;
	}

	public String isLegendado() {
		return legendado;
	}

	public void setLegendado(String legendado) {
		this.legendado = legendado;
	}

	public String isForaExibicao() {
		return foraExibicao;
	}

	public void setForaExibicao(String foraExibicao) {
		this.foraExibicao = foraExibicao;
	}

	@Override
	public String toString() {
		return "Filmes [idFilme=" + idFilme + ", nomeFilme=" + nomeFilme + ", categoriaFilme=" + categoriaFilme
				+ ", produtoraFilme=" + produtoraFilme + ", dataLancamento=" + dataLancamento + ", exibicaoAte="
				+ exibicaoAte + ", paisOrigem=" + paisOrigem + ", idioma=" + idioma + ", classificaoEtaria="
				+ classificaoEtaria + ", dublado=" + dublado + ", legendado=" + legendado + ", foraExibicao="
				+ foraExibicao + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idFilme == null) ? 0 : idFilme.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Filmes other = (Filmes) obj;
		if (idFilme == null) {
			if (other.idFilme != null)
				return false;
		} else if (!idFilme.equals(other.idFilme))
			return false;
		return true;
	}
	
}
