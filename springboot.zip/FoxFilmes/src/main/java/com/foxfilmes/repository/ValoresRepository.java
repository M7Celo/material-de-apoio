package com.foxfilmes.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.foxfilmes.entity.Valores;

@Repository
@Transactional
public interface ValoresRepository extends CrudRepository<Valores, Long>{

}