package com.foxfilmes.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.foxfilmes.entity.Filmes;

@Repository
@Transactional
public interface FilmesRepository extends CrudRepository<Filmes, Long>{

}
