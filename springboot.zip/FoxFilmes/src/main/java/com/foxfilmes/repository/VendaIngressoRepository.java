package com.foxfilmes.repository;

import org.springframework.data.repository.CrudRepository;

import com.foxfilmes.entity.VendaIngressos;

public interface VendaIngressoRepository extends CrudRepository<VendaIngressos, Long>{

}
