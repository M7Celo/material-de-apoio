package treinamento.apache.camel.bean;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;

import treinamento.apache.camel.model.Pessoa;

public class PessoaBean {
	
	public void gerarSaida(Exchange exchange) {
		Pessoa pessoa1 = new Pessoa();
		pessoa1.setNome("Marcelo");
		pessoa1.setCPF("328.107.528-26");
		
		Pessoa pessoa2 = new Pessoa();
		pessoa2.setNome("Renan");
		pessoa2.setCPF("123.456.789-12");
		
		List<Pessoa> listaPessoa = new ArrayList<Pessoa>();
		
		listaPessoa.add(pessoa1);
		listaPessoa.add(pessoa2);
		
		exchange.getOut().setBody(listaPessoa);
			
	}

}
