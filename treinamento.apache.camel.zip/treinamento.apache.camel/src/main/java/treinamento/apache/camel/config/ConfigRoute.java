package treinamento.apache.camel.config;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.apache.camel.core.xml.CamelServiceExporterDefinition;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@SuppressWarnings("unused")
@Component
public class ConfigRoute extends RouteBuilder {

	@Bean
	public ServletRegistrationBean<CamelHttpTransportServlet> camelServletRegistrationBean() {
		ServletRegistrationBean<CamelHttpTransportServlet> registrationBean =
				new ServletRegistrationBean<CamelHttpTransportServlet>(new CamelHttpTransportServlet(),
				"/api/v1/*");
		registrationBean.setName("CamelServlet");
		return registrationBean;
	}

	@Override
	public void configure() throws Exception {
//		restConfiguration()
//		.dataFormatProperty("prettyPrint", "true")
//		.component("servlet")
//		.bindingMode(RestBindingMode.off)
//		.apiContextIdPattern("/api-doc")
//		.apiProperty("api.title", "CamelTeste-Main-App")
//		.apiProperty("api.version", "1.0.0")
//		.apiProperty("cors", "true");

	}

}
